<?php
/**
 * WP-CLI command registration and output helpers.
 *
 * @package Titanworks\BaznaCijena\Cli
 */

namespace Titanworks\BaznaCijena\Cli;

defined( 'ABSPATH' ) || exit;

/**
 * Registers `wp bazna-cijena` subcommands and buffers output for tests.
 */
final class Cli {

	/**
	 * Buffered output lines for tests: each entry is [method, message].
	 *
	 * @var array<int,array{0:string,1:string}>
	 */
	private static $buffer = array();

	/**
	 * Register all subcommands with WP-CLI.
	 *
	 * @return void
	 */
	public static function register() {
		if ( ! class_exists( 'WP_CLI' ) ) {
			return;
		}

		$commands = array(
			'status'         => StatusCommand::class,
			'validate'       => ValidateCommand::class,
			'generate'       => GenerateCommand::class,
			'history'        => HistoryCommand::class,
			'import'         => ImportCommand::class,
			'cleanup'        => CleanupCommand::class,
			'seed-test-data' => SeedTestDataCommand::class,
		);

		// The pre-2.0.44 command name stays as an alias so existing server
		// crontabs keep running the statutory daily generation.
		foreach ( array( 'bazna-cijena', 'sidrena-cijena' ) as $root ) {
			foreach ( $commands as $name => $class ) {
				\WP_CLI::add_command( $root . ' ' . $name, array( $class, 'run' ) );
			}
		}
	}

	/**
	 * Print a message via WP-CLI when available and always buffer it.
	 *
	 * @param string $message Message.
	 * @param string $method  One of log, success, warning, error, line.
	 * @return void
	 */
	public static function out( $message, $method = 'log' ) {
		$message = (string) $message;

		self::$buffer[] = array( $method, $message );

		if ( ! class_exists( 'WP_CLI' ) ) {
			return;
		}

		switch ( $method ) {
			case 'success':
				\WP_CLI::success( $message );
				break;
			case 'warning':
				\WP_CLI::warning( $message );
				break;
			case 'error':
				\WP_CLI::error( $message );
				break;
			case 'line':
				\WP_CLI::line( $message );
				break;
			default:
				\WP_CLI::log( $message );
				break;
		}
	}

	/**
	 * Buffered output.
	 *
	 * @return array<int,array{0:string,1:string}>
	 */
	public static function buffer() {
		return self::$buffer;
	}

	/**
	 * Clear the output buffer.
	 *
	 * @return void
	 */
	public static function reset_buffer() {
		self::$buffer = array();
	}

	/**
	 * Encode data as JSON.
	 *
	 * @param mixed $data Data.
	 * @return string
	 */
	public static function as_json( $data ) {
		if ( function_exists( 'wp_json_encode' ) ) {
			$json = wp_json_encode( $data );
		} else {
			// phpcs:ignore WordPress.WP.AlternativeFunctions.json_encode_json_encode -- Fallback when WordPress is not loaded.
			$json = json_encode( $data );
		}

		return is_string( $json ) ? $json : '{}';
	}
}
