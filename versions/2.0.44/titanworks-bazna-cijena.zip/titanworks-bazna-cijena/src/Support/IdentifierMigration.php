<?php
/**
 * Upgrade storage identifiers from the pre-directory development builds.
 *
 * @package Titanworks\BaznaCijena\Support
 */

namespace Titanworks\BaznaCijena\Support;

use Titanworks\BaznaCijena\Admin\Capabilities;
use Titanworks\BaznaCijena\Cron\Scheduler;

defined( 'ABSPATH' ) || exit;

/**
 * Preserves existing site data when adopting the unique TWBCE prefix.
 */
final class IdentifierMigration {

	const OPTION = 'twbce_identifiers_migrated';

	const TABLES_OPTION = 'twbce_tables_renamed';

	const CONFLICTS_OPTION = 'twbce_table_rename_conflicts';

	/**
	 * Legacy table suffix => current table suffix.
	 *
	 * @return array<string,string>
	 */
	public static function legacy_tables() {
		return array(
			'sidrena_price_history' => 'twbce_price_history',
			'sidrena_special_sales' => 'twbce_special_sales',
			'sidrena_locations'     => 'twbce_locations',
			'sidrena_publications'  => 'twbce_publications',
			'sidrena_logs'          => 'twbce_logs',
		);
	}

	/**
	 * Rename legacy tables in place. RENAME TABLE keeps every row, index and
	 * auto-increment value, so the append-only price ledger is moved, never
	 * rewritten. A populated table under the new name is never touched.
	 *
	 * @return bool True when no legacy table is left to rename. On false the
	 *              schema must not be created, or empty new tables would be
	 *              seeded and shadow the legacy data.
	 */
	public static function rename_tables() {
		if ( get_option( self::TABLES_OPTION, false ) ) {
			return true;
		}

		global $wpdb;

		$conflicts = array();

		foreach ( self::legacy_tables() as $legacy_suffix => $suffix ) {
			$legacy = $wpdb->prefix . $legacy_suffix;
			$table  = $wpdb->prefix . $suffix;

			// phpcs:ignore WordPress.DB.DirectDatabaseQuery -- One-time schema inspection.
			if ( $legacy !== $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $wpdb->esc_like( $legacy ) ) ) ) {
				continue;
			}

			// phpcs:ignore WordPress.DB.DirectDatabaseQuery -- One-time schema inspection.
			if ( $table !== $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $wpdb->esc_like( $table ) ) ) ) {
				// phpcs:ignore WordPress.DB.DirectDatabaseQuery, WordPress.DB.DirectDatabaseQuery.SchemaChange -- One-time in-place table rename.
				if ( false === $wpdb->query( $wpdb->prepare( 'RENAME TABLE %i TO %i', $legacy, $table ) ) ) {
					return false;
				}
				continue;
			}

			// phpcs:ignore WordPress.DB.DirectDatabaseQuery -- One-time schema inspection.
			$rows = (int) $wpdb->get_var( $wpdb->prepare( 'SELECT COUNT(*) FROM %i', $table ) );
			if ( $rows > 0 ) {
				// Both tables hold data: never merge or drop either. Record the
				// conflict so the legacy rows can be reconciled by hand.
				$conflicts[] = $legacy;
				continue;
			}

			// The new table is an empty dbDelta copy. Swap both names in one
			// atomic statement so a concurrent request can never drop the ledger.
			$backup = $table . '_pre_rename';
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery, WordPress.DB.DirectDatabaseQuery.SchemaChange -- One-time atomic table swap.
			if ( false === $wpdb->query( $wpdb->prepare( 'RENAME TABLE %i TO %i, %i TO %i', $table, $backup, $legacy, $table ) ) ) {
				return false;
			}
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery -- One-time schema inspection.
			if ( 0 === (int) $wpdb->get_var( $wpdb->prepare( 'SELECT COUNT(*) FROM %i', $backup ) ) ) {
				// phpcs:ignore WordPress.DB.DirectDatabaseQuery, WordPress.DB.DirectDatabaseQuery.SchemaChange -- Drops the empty plugin-owned copy.
				$wpdb->query( $wpdb->prepare( 'DROP TABLE %i', $backup ) );
			}
		}

		if ( ! empty( $conflicts ) ) {
			update_option( self::CONFLICTS_OPTION, $conflicts, false );
		}

		update_option( self::TABLES_OPTION, 1, false );

		return true;
	}

	/**
	 * Copy options without overwriting any values already saved under new keys.
	 * Legal history tables are renamed in place, never rewritten.
	 *
	 * @return void
	 */
	public static function run() {
		self::rename_tables();

		if ( get_option( self::OPTION, false ) ) {
			return;
		}

		if ( null === get_option( 'sidrena_cijena_db_version', null ) && null === get_option( 'sidrena_cijena_settings', null ) ) {
			update_option( self::OPTION, 1, false );
			return;
		}

		foreach ( Uninstaller::options() as $option ) {
			$legacy = preg_replace( '/^twbce_/', 'sidrena_', $option );
			if ( $legacy === $option ) {
				continue;
			}
			$value = get_option( $legacy, null );
			if ( null !== $value && null === get_option( $option, null ) ) {
				add_option( $option, $value, '', false );
			}
		}

		global $wpdb;

		// Fixed, plugin-owned metadata keys only; do not change unrelated metadata.
		$keys = array(
			'_twbce_availability',
			'_twbce_barcode',
			'_twbce_cijena_show_in_cards',
			'_twbce_currency',
			'_twbce_first_offer_eligible',
			'_twbce_first_offer_observation',
			'_twbce_first_seen',
			'_twbce_item_type',
			'_twbce_regular_price',
			'_twbce_sale_price',
			'_twbce_sku',
			'_twbce_tax_inclusive',
			'_twbce_unit',
			'_twbce_unit_price',
		);
		foreach ( $keys as $key ) {
			$legacy = str_replace( '_twbce_', '_sidrena_', $key );
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery -- One-time indexed storage migration.
			$result = $wpdb->query( $wpdb->prepare( 'UPDATE %i SET meta_key = %s WHERE meta_key = %s', $wpdb->postmeta, $key, $legacy ) );
			if ( false === $result ) {
				return;
			}
		}

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery -- One-time standalone catalog migration.
		$result = $wpdb->query( $wpdb->prepare( 'UPDATE %i SET post_type = %s WHERE post_type = %s', $wpdb->posts, 'twbce_item', 'sidrena_item' ) );
		if ( false === $result ) {
			return;
		}
		foreach ( array( 'brand', 'item_type' ) as $taxonomy ) {
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery -- One-time taxonomy migration.
			$result = $wpdb->query( $wpdb->prepare( 'UPDATE %i SET taxonomy = %s WHERE taxonomy = %s', $wpdb->term_taxonomy, 'twbce_' . $taxonomy, 'sidrena_' . $taxonomy ) );
			if ( false === $result ) {
				return;
			}
		}

		// Preserve custom role grants and user-specific grants as well as administrators.
		foreach ( wp_roles()->role_objects as $role ) {
			if ( array_key_exists( 'manage_sidrena_cijena', $role->capabilities ) ) {
				$role->add_cap( Capabilities::CAPABILITY, (bool) $role->capabilities['manage_sidrena_cijena'] );
			}
		}
		// Direct grants and denials must retain their original boolean value.
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery -- One-time user capability migration.
		$user_ids = $wpdb->get_col(
			$wpdb->prepare(
				'SELECT user_id FROM %i WHERE meta_key = %s AND meta_value LIKE %s',
				$wpdb->usermeta,
				$wpdb->get_blog_prefix() . 'capabilities',
				'%' . $wpdb->esc_like( '"manage_sidrena_cijena";' ) . '%'
			)
		);
		foreach ( $user_ids as $user_id ) {
			$user = new \WP_User( $user_id );
			if ( array_key_exists( 'manage_sidrena_cijena', $user->caps ) ) {
				$user->add_cap( Capabilities::CAPABILITY, (bool) $user->caps['manage_sidrena_cijena'] );
			}
		}

		Capabilities::grant();

		foreach ( array( 'daily_generation', 'service_regeneration', 'daily_cleanup', 'catchup_generation' ) as $event ) {
			wp_clear_scheduled_hook( 'sidrena_cijena_' . $event );
			if ( function_exists( 'as_unschedule_all_actions' ) ) {
				as_unschedule_all_actions( 'sidrena_cijena_' . $event, array(), 'sidrena-cijena' );
			}
		}

		Settings::reset_cache();
		Scheduler::schedule_all();
		// Rebuild with the new query variables on init, after all rules register.
		add_action( 'init', 'flush_rewrite_rules', 99 );
		wp_cache_flush();
		update_option( self::OPTION, 1, false );
	}
}
