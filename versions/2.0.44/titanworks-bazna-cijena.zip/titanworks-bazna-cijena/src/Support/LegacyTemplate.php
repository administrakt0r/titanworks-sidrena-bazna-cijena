<?php
/**
 * Compatibility for theme template overrides copied from releases before 2.0.44.
 *
 * @package Titanworks\BaznaCijena\Support
 */

namespace Titanworks\BaznaCijena\Support;

defined( 'ABSPATH' ) || exit;

/**
 * Rewrites the old class, data-attribute and CSS-variable prefixes emitted by
 * legacy overrides so the current CSS and JavaScript still find the markup.
 */
final class LegacyTemplate {

	/**
	 * Theme folder that held overrides before 2.0.44.
	 */
	const LEGACY_DIR = 'sidrena-cijena/';

	/**
	 * Normalize rendered output when it came from a legacy override.
	 *
	 * @param string $html     Rendered template output.
	 * @param string $template Absolute template path that produced it.
	 * @return string
	 */
	public static function normalize( $html, $template ) {
		$path = str_replace( '\\', '/', (string) $template );

		if ( false === strpos( $path, '/' . self::LEGACY_DIR ) ) {
			return (string) $html;
		}

		// Only bare prefixes (class names, data-*, --vars). Path and domain
		// occurrences such as "/sidrena-cijena.xml" or "sidrenacijena.eu" stay.
		return (string) preg_replace( '/(?<![\w.\/])sidrena-/', 'bazna-', (string) $html );
	}
}
