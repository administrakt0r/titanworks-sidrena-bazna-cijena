<?php
/**
 * Minimal PSR-4 autoloader for the BaznaCijena namespace.
 *
 * The plugin ships no runtime Composer dependencies, so this autoloader is the
 * only class-loading mechanism in production.
 *
 * @package Titanworks\BaznaCijena\Support
 */

namespace Titanworks\BaznaCijena\Support;

defined( 'ABSPATH' ) || exit;

/**
 * Maps `Titanworks\BaznaCijena\` to the plugin `src/` directory.
 */
final class Autoloader {

	/**
	 * Namespace prefix handled by this autoloader.
	 */
	const PREFIX = 'Titanworks\\BaznaCijena\\';

	/**
	 * Namespace used before 2.0.44. Theme template overrides copied from older
	 * releases still reference it, so it resolves to an alias of the new class.
	 */
	const LEGACY_PREFIX = 'Titanworks\\SidrenaCijena\\';

	/**
	 * Directory (relative to the plugin root) that mirrors the namespace.
	 */
	const BASE_DIR = 'src/';

	/**
	 * Whether the autoloader has already been registered.
	 *
	 * @var bool
	 */
	private static $registered = false;

	/**
	 * Register the autoloader with the SPL stack.
	 *
	 * @return void
	 */
	public static function register() {
		if ( self::$registered ) {
			return;
		}

		spl_autoload_register( array( __CLASS__, 'autoload' ) );
		self::$registered = true;
	}

	/**
	 * Load a class file when it belongs to the plugin namespace.
	 *
	 * @param string $class Fully qualified class name.
	 * @return void
	 */
	public static function autoload( $class ) {
		if ( 0 === strpos( $class, self::LEGACY_PREFIX ) ) {
			$current = self::PREFIX . substr( $class, strlen( self::LEGACY_PREFIX ) );
			if ( class_exists( $current ) || interface_exists( $current ) || trait_exists( $current ) ) {
				class_alias( $current, $class );
			}
			return;
		}

		if ( 0 !== strpos( $class, self::PREFIX ) ) {
			return;
		}

		$relative = substr( $class, strlen( self::PREFIX ) );
		$relative = str_replace( '\\', '/', $relative );

		$base = defined( 'TWBCE_CIJENA_DIR' ) ? TWBCE_CIJENA_DIR : dirname( __DIR__, 2 ) . '/';
		$file = $base . self::BASE_DIR . $relative . '.php';

		if ( is_readable( $file ) ) {
			require_once $file;
		}
	}
}
