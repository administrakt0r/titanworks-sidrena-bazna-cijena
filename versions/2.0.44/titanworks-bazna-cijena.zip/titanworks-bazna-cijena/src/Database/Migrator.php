<?php
/**
 * Versioned schema migrations.
 *
 * @package Titanworks\BaznaCijena\Database
 */

namespace Titanworks\BaznaCijena\Database;

use Titanworks\BaznaCijena\Support\IdentifierMigration;
use Titanworks\BaznaCijena\Support\Install;
use Titanworks\BaznaCijena\Support\Settings;

defined( 'ABSPATH' ) || exit;

/**
 * Runs dbDelta() migrations when the stored schema version is behind.
 */
final class Migrator {

	/**
	 * Option holding the installed schema version.
	 */
	const OPTION = 'twbce_cijena_db_version';

	/**
	 * Run the upgrade check on admin requests.
	 *
	 * @return void
	 */
	public static function maybe_upgrade() {
		if ( self::installed_version() !== Schema::DB_VERSION || false === get_option( Settings::OPTION, false ) ) {
			self::migrate();
		}
	}

	/**
	 * Installed schema version.
	 *
	 * @return string
	 */
	public static function installed_version() {
		return (string) get_option( self::OPTION, '' );
	}

	/**
	 * Run migrations up to the current schema version.
	 *
	 * @return string The version now installed.
	 */
	public static function migrate() {
		$from = self::installed_version();
		$to   = Schema::DB_VERSION;

		if ( $from === $to && false !== get_option( Settings::OPTION, false ) ) {
			return $to;
		}

		// Never create or seed new tables while legacy tables still wait to be
		// renamed: a seeded empty copy would hide the legacy rows for good.
		if ( ! IdentifierMigration::rename_tables() ) {
			return $from;
		}

		Schema::create_tables();
		Install::seed_options();

		$locations = new LocationRepository();
		$locations->ensure_default_webshop();

		update_option( self::OPTION, $to, false );

		if ( function_exists( 'flush_rewrite_rules' ) ) {
			flush_rewrite_rules( false );
		}

		/**
		 * Fires after the schema has been migrated.
		 *
		 * @param string $from Previous version.
		 * @param string $to   New version.
		 */
		do_action( 'twbce_cijena_migrated', $from, $to );

		return $to;
	}
}
