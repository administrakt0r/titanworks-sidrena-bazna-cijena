<?php
/**
 * Frontend display settings tab.
 *
 * @package Titanworks\BaznaCijena\Admin
 */

namespace Titanworks\BaznaCijena\Admin;

use Titanworks\BaznaCijena\Support\Settings;

defined( 'ABSPATH' ) || exit;

/**
 * Display settings.
 */
final class DisplaySettingsPage {

	/**
	 * Settings page slug used by do_settings_sections().
	 */
	const PAGE = 'bazna-cijena-settings-display';

	/**
	 * Register sections and fields.
	 *
	 * @return void
	 */
	public static function register_settings() {
		add_settings_section(
			'twbce_cijena_display',
			__( 'Anchor price display', 'titanworks-bazna-cijena' ),
			array( __CLASS__, 'section_intro' ),
			self::PAGE
		);

		$fields = array(
			'display_enabled'       => array(
				'label'       => __( 'Enable frontend display', 'titanworks-bazna-cijena' ),
				'type'        => 'checkbox',
				'description' => __( 'Show anchor price and 30-day lowest price on the public storefront.', 'titanworks-bazna-cijena' ),
			),
			'anchor_label'          => array(
				'label'       => __( 'Anchor price label', 'titanworks-bazna-cijena' ),
				'type'        => 'anchor_label_preset',
				'description' => __( 'Statutory label describing the anchor price. Choose a preset or specify a custom label with dynamic tokens ({datum}, {datum_iso}).', 'titanworks-bazna-cijena' ),
			),
			'thirty_day_label'      => array(
				'label'       => __( 'Lowest 30-day price label', 'titanworks-bazna-cijena' ),
				'type'        => 'text',
				'description' => __( 'Statutory label for the lowest price applied in the 30 days before a promotion.', 'titanworks-bazna-cijena' ),
			),
			'currency_display'      => array(
				'label'       => __( 'Currency display', 'titanworks-bazna-cijena' ),
				'type'        => 'select',
				'description' => __( 'Format used to display currency alongside the anchor price.', 'titanworks-bazna-cijena' ),
			),
			'display_location'      => array(
				'label'       => __( 'Display position', 'titanworks-bazna-cijena' ),
				'type'        => 'select',
				'description' => __( 'Placement of the anchor price relative to the regular product price HTML.', 'titanworks-bazna-cijena' ),
			),
			'display_priority'      => array(
				'label'       => __( 'Display priority', 'titanworks-bazna-cijena' ),
				'type'        => 'number',
				'description' => __( 'Action hook priority (default 15; lower values render earlier).', 'titanworks-bazna-cijena' ),
			),
			'display_product_pages' => array(
				'label'       => __( 'Product pages', 'titanworks-bazna-cijena' ),
				'type'        => 'checkbox',
				'description' => __( 'Render anchor price information on single product pages.', 'titanworks-bazna-cijena' ),
			),
			'display_archives'      => array(
				'label'       => __( 'Product cards and archives', 'titanworks-bazna-cijena' ),
				'type'        => 'checkbox',
				'description' => __( 'Render anchor price information on shop loops, category archives, search results, related products, and minicards.', 'titanworks-bazna-cijena' ),
			),
			'card_display_default'  => array(
				'label'       => __( 'Show on cards by default', 'titanworks-bazna-cijena' ),
				'type'        => 'checkbox',
				'description' => __( 'Display the anchor price on all product cards by default. Can be unchecked on individual products in the product editor.', 'titanworks-bazna-cijena' ),
			),
			'display_variations'    => array(
				'label'       => __( 'Variations', 'titanworks-bazna-cijena' ),
				'type'        => 'checkbox',
				'description' => __( 'Dynamically update the anchor price when a variation is selected.', 'titanworks-bazna-cijena' ),
			),
			'display_cart_checkout' => array(
				'label'       => __( 'Cart and checkout', 'titanworks-bazna-cijena' ),
				'type'        => 'checkbox',
				'description' => __( 'Also show the reference price lines next to cart, mini-cart and checkout item prices, using the label chosen above. Off by default: the cited regulations do not expressly require a cart or checkout line.', 'titanworks-bazna-cijena' ),
			),
			'only_when_different'   => array(
				'label'       => __( 'Only when the anchor differs', 'titanworks-bazna-cijena' ),
				'type'        => 'checkbox',
				'description' => __( 'Hide the anchor price if it equals the current selling price.', 'titanworks-bazna-cijena' ),
			),
			'disclaimer'            => array(
				'label'       => __( 'Administrative disclaimer', 'titanworks-bazna-cijena' ),
				'type'        => 'textarea',
				'description' => __( 'Optional text displayed alongside anchor prices informing buyers of statutory direct price controls.', 'titanworks-bazna-cijena' ),
			),
		);

		foreach ( $fields as $key => $field ) {
			add_settings_field(
				'twbce_cijena_' . $key,
				$field['label'],
				array( __CLASS__, 'render_field' ),
				self::PAGE,
				'twbce_cijena_display',
				array(
					'key'         => $key,
					'type'        => $field['type'],
					'description' => $field['description'],
					'label_for'   => $key,
				)
			);
		}
	}

	/**
	 * Section introduction.
	 *
	 * @return void
	 */
	public static function section_intro() {
		echo '<p>' . esc_html__( 'Choose where and how the anchor price ("Sidrena cijena") is shown next to current prices.', 'titanworks-bazna-cijena' ) . '</p>';
	}

	/**
	 * Render one field.
	 *
	 * @param array<mixed> $args Field arguments.
	 * @return void
	 */
	public static function render_field( $args ) {
		$key    = $args['key'];
		$fields = new SettingsFields( Settings::OPTION );
		$value  = Settings::get( $key );

		switch ( $args['type'] ) {
			case 'anchor_label_preset':
				self::render_anchor_label_field( $key, $value );
				break;
			case 'checkbox':
				$fields->checkbox( $key, $value );
				break;
			case 'number':
				$fields->number(
					$key,
					$value,
					array(
						'min' => 1,
						'max' => 100,
					)
				);
				break;
			case 'select':
				if ( 'currency_display' === $key ) {
					$choices = array(
						'symbol' => __( 'Currency symbol (6,99 EUR)', 'titanworks-bazna-cijena' ),
						'code'   => __( 'Currency code (6,99 EUR)', 'titanworks-bazna-cijena' ),
						'none'   => __( 'Amount only (6,99)', 'titanworks-bazna-cijena' ),
					);
				} else {
					$choices = array(
						'price_html' => __( 'Inline, next to the price', 'titanworks-bazna-cijena' ),
						'summary'    => __( 'Separate block below the price', 'titanworks-bazna-cijena' ),
					);
				}

				$fields->select( $key, $value, $choices );
				break;
			case 'textarea':
				$fields->textarea( $key, $value );
				break;
			default:
				$fields->text( $key, $value );
				break;
		}

		if ( ! empty( $args['description'] ) ) {
			echo '<p class="description">' . esc_html( $args['description'] ) . '</p>';
		}
	}

	/**
	 * Renders the anchor price label field with presets and live preview.
	 *
	 * @param string $key   Field key.
	 * @param mixed  $value Stored value.
	 * @return void
	 */
	public static function render_anchor_label_field( $key, $value ) {
		$value   = (string) ( null !== $value && '' !== $value ? $value : __( 'Sidrena cijena', 'titanworks-bazna-cijena' ) );
		$presets = Settings::anchor_label_presets();
		$option  = Settings::OPTION;

		echo '<div class="bazna-label-presets-wrap">';
		echo '<p class="bazna-label-presets-heading">' . esc_html__( 'Choose a suggested name or enter your own:', 'titanworks-bazna-cijena' ) . '</p>';
		echo '<div class="bazna-label-presets">';

		foreach ( $presets as $preset_key => $preset_label ) {
			$active_class = ( $value === $preset_label ) ? ' is-active' : '';
			echo '<button type="button" class="button bazna-preset-btn' . esc_attr( $active_class ) . '" data-preset="' . esc_attr( $preset_label ) . '">' . esc_html( $preset_label ) . '</button>';
		}

		echo '</div>';

		echo '<div class="bazna-label-input-row">';
		echo '<input type="text" id="' . esc_attr( $key ) . '" name="' . esc_attr( $option . '[' . $key . ']' ) . '" value="' . esc_attr( $value ) . '" class="regular-text" placeholder="' . esc_attr__( 'Sidrena cijena', 'titanworks-bazna-cijena' ) . '" />';
		echo '<button type="button" class="button button-secondary bazna-token-btn" data-token="{datum}" title="' . esc_attr__( 'Umetni oznaku za datum', 'titanworks-bazna-cijena' ) . '">+ {datum}</button>';
		echo '</div>';

		echo '<div class="bazna-label-preview-box">';
		echo '<p class="bazna-label-preview-title">' . esc_html__( 'Storefront preview (live):', 'titanworks-bazna-cijena' ) . '</p>';
		echo '<div class="bazna-label-preview-row"><strong>' . esc_html__( 'Food / drink / household:', 'titanworks-bazna-cijena' ) . '</strong> <span id="bazna-preview-food" class="bazna-label-preview-val"></span>: 12,49 €</div>';
		echo '<div class="bazna-label-preview-row"><strong>' . esc_html__( 'Clothing / electronics / services:', 'titanworks-bazna-cijena' ) . '</strong> <span id="bazna-preview-general" class="bazna-label-preview-val"></span>: 17,99 €</div>';
		echo '</div>';

		echo '<p class="description bazna-label-presets-help">' . esc_html__( 'According to the Ministry of Economy\'s clarification, retailers may use terms such as "Bazna cijena", "Referentna cijena" or "Cijena na [datum]". The {datum} placeholder is automatically replaced with the exact legal date for each product (02.05.2025 for food, 10.09.2026 for other goods and services).', 'titanworks-bazna-cijena' ) . '</p>';
		echo '</div>';
	}

	/**
	 * Render the tab fields.
	 *
	 * @return void
	 */
	public static function render_fields() {
		do_settings_sections( self::PAGE );
	}
}
