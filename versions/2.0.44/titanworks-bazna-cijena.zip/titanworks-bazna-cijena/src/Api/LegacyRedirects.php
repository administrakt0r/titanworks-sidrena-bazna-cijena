<?php
/**
 * Permanent redirects from public URLs used before 2.0.44.
 *
 * @package Titanworks\BaznaCijena\Api
 */

namespace Titanworks\BaznaCijena\Api;

defined( 'ABSPATH' ) || exit;

/**
 * Keeps old feed and price-list links working after the URL rename.
 */
final class LegacyRedirects {

	/**
	 * Map an old request path to its current path.
	 *
	 * @param string $request Request path relative to the home URL, without slashes at either end.
	 * @return string|null Current path, or null when the request is not a legacy URL.
	 */
	public static function target( $request ) {
		$legacy = 'sidrena';
		$map    = array(
			$legacy . '-cijena.xml' => PublicFeed::STEM . '.xml',
			$legacy . '-cijena.csv' => PublicFeed::STEM . '.csv',
			$legacy . 'cijena.xml'  => PublicFeed::STEM_COMPACT . '.xml',
			$legacy . 'cijena.csv'  => PublicFeed::STEM_COMPACT . '.csv',
			$legacy . '-cjenik'     => PublicPage::STEM_LIST . '/',
			$legacy . '-cijena'     => PublicPage::STEM_LIST . '/',
			$legacy . 'cijena'      => PublicPage::STEM_LIST . '/',
			'arhiva-sidrene-cijene' => PublicPage::STEM_ARCHIVE . '/',
		);

		$request = strtolower( trim( (string) $request, '/' ) );

		return isset( $map[ $request ] ) ? $map[ $request ] : null;
	}

	/**
	 * Register the redirect hook.
	 *
	 * @return void
	 */
	public function register() {
		add_action( 'parse_request', array( $this, 'maybe_redirect' ), 0 );
	}

	/**
	 * Send a 301 for legacy public URLs.
	 *
	 * @param \WP $wp WordPress environment.
	 * @return void
	 */
	public function maybe_redirect( $wp ) {
		$request = trim( (string) $wp->request, '/' );
		$query   = '';
		if ( isset( $_SERVER['REQUEST_URI'] ) ) {
			$raw_uri = esc_url_raw( wp_unslash( $_SERVER['REQUEST_URI'] ) );
			$query   = (string) wp_parse_url( $raw_uri, PHP_URL_QUERY );
			if ( '' === $request ) {
				$request = trim( (string) wp_parse_url( $raw_uri, PHP_URL_PATH ), '/' );
				$home    = trim( (string) wp_parse_url( home_url(), PHP_URL_PATH ), '/' );
				if ( '' !== $home && 0 === strpos( $request, $home ) ) {
					$request = trim( (string) substr( $request, strlen( $home ) ), '/' );
				}
			}
		}

		$target = self::target( $request );
		if ( null === $target ) {
			return;
		}

		$url = home_url( '/' . $target );
		if ( '' !== $query ) {
			$url .= '?' . $query;
		}

		wp_safe_redirect( $url, 301, 'Titanworks Bazna Cijena' );
		exit;
	}
}
