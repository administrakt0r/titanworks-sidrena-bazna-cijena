( function () {
	// Reference strings the server supplied through the checkout filters. The enhancer
	// only touches text nodes that exactly match one, so any merchant label works.
	var knownReferences = {};

	// Dates (dd.mm.yyyy. and yyyy-mm-dd, the only formats the label tokens emit) are masked with digit-free placeholders while parsing so a
	// date in a merchant label can never be mistaken for a price amount.
	function parseCartReferenceParts( rawText ) {
		var dates = [];
		var text = rawText.trim().replace( /\d{4}-\d{1,2}-\d{1,2}|\d{1,2}\.\d{1,2}\.\d{2,4}\.?/g, function ( match ) {
			dates.push( match );
			return '\uE000' + String.fromCharCode( 0xE100 + dates.length - 1 );
		} );
		var parts = [];

		var unmask = function ( value ) {
			return value.replace( /\uE000([\uE100-\uE1FF])/g, function ( m, code ) {
				return dates[ code.charCodeAt( 0 ) - 0xE100 ];
			} );
		};

		// The label is merchant-defined and may itself contain a date, so the price is
		// the first amount that is followed by a currency; fall back to any amount.
		var anchorRegex = /^(.+?)\s+([\d.,]+\s*(?:[€$£]|EUR|HRK|kn|[A-Z]{3}))(?:\s*(\(\uE000[\uE100-\uE1FF]\)))?/;
		var looseRegex = /^([^\d]+?)\s+([\d.,]+)(?:\s*(\(\uE000[\uE100-\uE1FF]\)))?/;
		var anchorMatch = text.match( anchorRegex ) || text.match( looseRegex );

		if ( anchorMatch ) {
			var bLabel = unmask( anchorMatch[ 1 ].trim() );
			var bValue = anchorMatch[ 2 ].trim();
			var bDate  = anchorMatch[ 3 ] ? unmask( anchorMatch[ 3 ].trim() ) : '';

			parts.push( {
				type: 'anchor',
				label: bLabel + ':',
				value: bValue,
				date: bDate,
			} );

			var remainder = text.slice( anchorMatch[ 0 ].length ).trim();
			remainder = remainder.replace( /Promotion[^\d]*/i, '' ).trim();

			if ( remainder.length > 0 ) {
				var remPriceMatch = remainder.match( /([\d.,]+\s*(?:[€$£]|EUR|HRK|kn|[A-Z]{3})?)$/ );
				if ( remPriceMatch ) {
					var remLabel = unmask( remainder.slice( 0, remPriceMatch.index ).trim() );
					var remValue = remPriceMatch[ 1 ].trim();
					remLabel = remLabel.replace( /[:\-—]+$/, '' ).trim();

					parts.push( {
						type: 'lowest',
						label: remLabel + ':',
						value: remValue,
						date: '',
					} );
				} else {
					parts.push( {
						type: 'lowest',
						label: unmask( remainder ),
						value: '',
						date: '',
					} );
				}
			}
		} else {
			parts.push( {
				type: 'generic',
				label: unmask( text ),
				value: '',
				date: '',
			} );
		}

		return parts;
	}

	function buildCartLineElement( rawText ) {
		var parts = parseCartReferenceParts( rawText );
		if ( parts.length === 0 ) {
			return null;
		}

		var wrap = document.createElement( 'div' );
		wrap.className = 'bazna-cijena-cart-line';
		wrap.setAttribute( 'aria-hidden', 'true' );

		for ( var i = 0; i < parts.length; i++ ) {
			var part = parts[ i ];
			var item = document.createElement( 'div' );
			item.className = 'bazna-cijena-cart-line__item' + ( 'lowest' === part.type ? ' bazna-cijena-cart-line__item--lowest' : '' );

			var lbl = document.createElement( 'span' );
			lbl.className = 'bazna-cijena-cart-line__label';
			lbl.textContent = part.label;
			item.appendChild( lbl );

			if ( part.value ) {
				item.appendChild( document.createTextNode( ' ' ) );
				var val = document.createElement( 'span' );
				val.className = 'bazna-cijena-cart-line__value';
				val.textContent = part.value;
				item.appendChild( val );
			}

			if ( part.date ) {
				item.appendChild( document.createTextNode( ' ' ) );
				var dt = document.createElement( 'span' );
				dt.className = 'bazna-cijena-cart-line__date';
				dt.textContent = part.date;
				item.appendChild( dt );
			}

			wrap.appendChild( item );
		}

		return wrap;
	}

	function enhanceCartReferences() {
		var containers = document.querySelectorAll(
			'.wc-block-cart-item__prices .wc-block-components-product-price, ' +
			'.wc-block-components-order-summary-item__description .wc-block-components-product-price'
		);

		for ( var i = 0; i < containers.length; i++ ) {
			var container = containers[ i ];
			var textNode = null;

			// Look for the React-owned text node containing reference prices.
			// Preserve this node directly in container to avoid detaching React VDOM references.
			var children = container.childNodes;
			for ( var j = 0; j < children.length; j++ ) {
				var node = children[ j ];
				if ( node.nodeType === 3 && node.nodeValue && knownReferences[ node.nodeValue.trim() ] ) {
					textNode = node;
					break;
				}
			}

			var existing = container.querySelector( '.bazna-cijena-cart-line' );

			// If no text node with reference price is present, clean up any obsolete badges and class.
			if ( ! textNode ) {
				if ( existing ) {
					existing.parentNode.removeChild( existing );
				}
				container.classList.remove( 'has-bazna-cart-line' );
				continue;
			}

			var rawText = textNode.nodeValue.trim();

			// If presentation already matches the text node, nothing to update.
			if ( existing && existing.getAttribute( 'data-source-text' ) === rawText ) {
				continue;
			}

			var wrap = buildCartLineElement( rawText );
			if ( ! wrap ) {
				if ( existing ) {
					existing.parentNode.removeChild( existing );
				}
				container.classList.remove( 'has-bazna-cart-line' );
				continue;
			}

			wrap.setAttribute( 'data-source-text', rawText );
			container.classList.add( 'has-bazna-cart-line' );

			// Replace or append only our own presentation wrapper, never detaching the React-owned text node.
			if ( existing ) {
				container.replaceChild( wrap, existing );
			} else {
				container.appendChild( wrap );
			}
		}
	}

	var enhanceQueued = false;
	function scheduleEnhance() {
		if ( enhanceQueued ) {
			return;
		}
		enhanceQueued = true;
		var run = function () {
			enhanceQueued = false;
			enhanceCartReferences();
		};
		if ( typeof window.requestAnimationFrame === 'function' ) {
			window.requestAnimationFrame( run );
		} else {
			setTimeout( run, 16 );
		}
	}

	function initObserver() {
		enhanceCartReferences();

		if ( typeof MutationObserver !== 'undefined' ) {
			var target = document.body || document.documentElement;
			if ( target ) {
				var observer = new MutationObserver( scheduleEnhance );
				observer.observe( target, {
					childList: true,
					characterData: true,
					subtree: true,
				} );
			}
		}

		if ( window.wp && window.wp.data && typeof window.wp.data.subscribe === 'function' ) {
			window.wp.data.subscribe( scheduleEnhance );
		}
	}

	if ( document.readyState === 'loading' ) {
		document.addEventListener( 'DOMContentLoaded', initObserver );
	} else {
		initObserver();
	}

	if (
		! window.wc ||
		! window.wc.blocksCheckout ||
		typeof window.wc.blocksCheckout.registerCheckoutFilters !== 'function'
	) {
		return;
	}

	function getReference( extensions ) {
		var extension = extensions && (
			extensions[ 'titanworks-bazna-cijena' ]
		);
		var reference = extension && extension.cartPriceSuffix;

		if ( typeof reference !== 'string' || reference === '' ) {
			return null;
		}

		knownReferences[ reference.trim() ] = true;

		return reference;
	}

	window.wc.blocksCheckout.registerCheckoutFilters( 'titanworks-bazna-cijena', {
		subtotalPriceFormat: function ( defaultValue, extensions ) {
			var reference = getReference( extensions );

			if ( ! reference ) {
				return defaultValue;
			}

			// Formats the per-item unit price in Cart block and Checkout OrderSummaryItem.
			return defaultValue + ' ' + reference;
		},
		cartItemPrice: function ( defaultValue ) {
			// Statutory benchmark prices are per-unit reference prices. They are displayed
			// on per-item unit prices (subtotalPriceFormat) and must not be repeated on line totals.
			return defaultValue;
		},
	} );
} )();
