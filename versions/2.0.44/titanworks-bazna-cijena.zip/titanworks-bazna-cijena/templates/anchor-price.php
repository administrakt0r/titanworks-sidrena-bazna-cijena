<?php
/**
 * Anchor price template.
 *
 * Overridable from a theme at `bazna-cijena/anchor-price.php`.
 *
 * @package BaznaCijena
 *
 * @var array $args Template arguments.
 */

defined( 'ABSPATH' ) || exit;

/* translators: %s: date of the reference price. */
$twbce_date_template   = __( 'Cijena na dan %s', 'titanworks-bazna-cijena' );
$twbce_style           = isset( $style ) && array_key_exists( $style, \Titanworks\BaznaCijena\Support\DisplayStyles::presets() ) ? $style : 'tooltip';
$twbce_date_mode       = isset( $date_mode ) ? $date_mode : (string) \Titanworks\BaznaCijena\Support\Settings::get( 'anchor_date_mode', 'tooltip' );
$twbce_font_weight     = isset( $font_weight ) ? $font_weight : (string) \Titanworks\BaznaCijena\Support\Settings::get( 'anchor_font_weight', 'normal' );
$twbce_default_tooltip = __( 'Sidrena (bazna) cijena je redovna maloprodajna cijena na propisani referentni datum prema mjerama izravne kontrole cijena.', 'titanworks-bazna-cijena' );
$twbce_tooltip_text    = isset( $tooltip_text ) && '' !== $tooltip_text
	? $tooltip_text
	: (string) \Titanworks\BaznaCijena\Support\Settings::get( 'anchor_tooltip_text', $twbce_default_tooltip );

if ( 'Sidrena cijena je najniža cijena u zadnjih 30 dana prije početka posebnog oblika prodaje.' === $twbce_tooltip_text ||
	'Sidrena cijena je najniza cijena u zadnjih 30 dana prije pocetka posebnog oblika prodaje.' === $twbce_tooltip_text ) {
	$twbce_tooltip_text = $twbce_default_tooltip;
}

$twbce_classes = 'bazna-cijena bazna-cijena--' . sanitize_html_class( $context ) . ' bazna-cijena--style-' . $twbce_style;
if ( 'bold' === $twbce_font_weight ) {
	$twbce_classes .= ' bazna-cijena--weight-bold';
} elseif ( 'semi-bold' === $twbce_font_weight ) {
	$twbce_classes .= ' bazna-cijena--weight-semibold';
} elseif ( 'normal' === $twbce_font_weight ) {
	$twbce_classes .= ' bazna-cijena--weight-normal';
}

$twbce_size = isset( $size ) ? min( 160, max( 40, (int) $size ) ) : min( 160, max( 40, (int) \Titanworks\BaznaCijena\Support\Settings::get( 'display_size', 40 ) ) );
?>
<div class="<?php echo esc_attr( $twbce_classes ); ?>"
	style="--bazna-size:<?php echo esc_attr( (string) ( $twbce_size / 100 ) ); ?>"
	title="<?php echo esc_attr( $anchor_title ); ?>"
	data-product-id="<?php echo esc_attr( (string) $product_id ); ?>"
	data-variation-id="<?php echo esc_attr( (string) $variation_id ); ?>"
	data-bazna-cijena-date-template="<?php echo esc_attr( $twbce_date_template ); ?>"
	<?php if ( isset( $label_template ) && false !== strpos( $label_template, '{' ) ) : ?>
	data-bazna-cijena-label-template="<?php echo esc_attr( $label_template ); ?>"
	<?php endif; ?>
	data-bazna-date-mode="<?php echo esc_attr( $twbce_date_mode ); ?>">
	<?php if ( $show_current && $current_display ) : ?>
		<span class="bazna-cijena__current">
			<span class="bazna-cijena__current-value"><?php echo esc_html( $current_display ); ?></span>
		</span>
	<?php endif; ?>

	<?php if ( $show_anchor ) : ?>
		<span class="bazna-cijena__anchor">
			<span class="bazna-cijena__label" data-bazna-cijena-label><?php echo esc_html( $label ); ?></span>
			<?php if ( 'cart' !== $context && ( 'tooltip' === $twbce_date_mode || 'tooltip' === $twbce_style ) ) : ?>
				<span class="bazna-cijena__tooltip-wrap">
					<span role="button" tabindex="0" class="bazna-cijena__help-trigger" aria-label="<?php esc_attr_e( 'Objašnjenje sidrene cijene', 'titanworks-bazna-cijena' ); ?>" aria-expanded="false" data-bazna-cijena-tooltip-trigger>?</span>
					<span class="bazna-cijena__tooltip-popup" role="tooltip" aria-hidden="true" data-bazna-cijena-tooltip-popup>
						<span class="bazna-cijena__tooltip-text"><?php echo esc_html( $twbce_tooltip_text ); ?></span>
						<?php if ( $reference_date_display ) : ?>
							<span class="bazna-cijena__tooltip-date" data-bazna-cijena-tooltip-date data-bazna-cijena-reference-date><?php echo esc_html( sprintf( $twbce_date_template, $reference_date_display ) ); ?></span>
						<?php else : ?>
							<span class="bazna-cijena__tooltip-date" data-bazna-cijena-tooltip-date data-bazna-cijena-reference-date hidden></span>
						<?php endif; ?>
					</span>
				</span>
			<?php endif; ?>
			<span class="bazna-cijena__anchor-value" data-bazna-cijena-anchor aria-live="polite"><?php echo esc_html( $anchor_display ); ?></span>
			<?php if ( 'cart' === $context && $reference_date_display && false === strpos( (string) $label, (string) $reference_date_display ) ) : ?>
				<span class="bazna-cijena__reference-date bazna-cijena__reference-date--cart" data-bazna-cijena-reference-date>(<?php echo esc_html( $reference_date_display ); ?>)</span>
			<?php elseif ( 'cart' !== $context && 'inline' === $twbce_date_mode && 'tooltip' !== $twbce_style && $reference_date_display ) : ?>
				<span class="bazna-cijena__reference-date" data-bazna-cijena-reference-date><?php echo esc_html( sprintf( $twbce_date_template, $reference_date_display ) ); ?></span>
			<?php elseif ( 'cart' !== $context && 'subtext' === $twbce_date_mode && 'tooltip' !== $twbce_style && $reference_date_display ) : ?>
				<span class="bazna-cijena__reference-date bazna-cijena__reference-date--subtext" data-bazna-cijena-reference-date><?php echo esc_html( sprintf( $twbce_date_template, $reference_date_display ) ); ?></span>
			<?php endif; ?>
		</span>
	<?php endif; ?>

	<?php if ( $disclaimer && 'cart' !== $context ) : ?>
		<span class="bazna-cijena__disclaimer"><?php echo esc_html( $disclaimer ); ?></span>
	<?php endif; ?>
</div>
