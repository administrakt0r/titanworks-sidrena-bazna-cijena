<?php
/**
 * Public HTML price list.
 *
 * Overridable from a theme as `bazna-cijena/public-price-list.php`.
 *
 * @package BaznaCijena
 *
 * @var array<int,array<mixed>> $rows        Canonical rows with display values.
 * @var array<mixed>            $meta        Build metadata.
 * @var array<mixed>|null       $location    Sales location.
 * @var string                  $q           Search term.
 * @var string                  $type        Type filter.
 * @var int                     $paged       Current page number.
 * @var int                     $per_page    Number of items per page.
 * @var int                     $total_items Total number of filtered items.
 * @var int                     $total_pages Total number of pages.
 * @var string                  $feed_xml    XML feed URL.
 * @var string                  $feed_csv    CSV feed URL.
 * @var string                  $archive_url Archive page URL.
 */

defined( 'ABSPATH' ) || exit;

$twbce_paged       = isset( $paged ) ? max( 1, (int) $paged ) : 1;
$twbce_per_page    = isset( $per_page ) ? max( 1, (int) $per_page ) : 50;
$twbce_total_items = isset( $total_items ) ? (int) $total_items : count( $rows );
$twbce_total_pages = isset( $total_pages ) ? (int) $total_pages : 1;
?>
<div class="bazna-cijena-cjenik">
	<?php if ( ! empty( $location ) ) : ?>
		<p class="bazna-cijena-cjenik__meta">
			<?php
			$twbce_generated_at = isset( $meta['generated_at'] ) ? \Titanworks\BaznaCijena\Support\Dates::format_datetime_display( (string) $meta['generated_at'] ) : '';
			printf(
				/* translators: 1: sales location name, 2: legal rule version, 3: generation timestamp. */
				esc_html__( 'Sales location: %1$s. Rule version: %2$s. Generated: %3$s.', 'titanworks-bazna-cijena' ),
				esc_html( (string) $location['name'] ),
				esc_html( isset( $meta['rule_version'] ) ? (string) $meta['rule_version'] : '' ),
				esc_html( $twbce_generated_at )
			);
			?>
		</p>
	<?php endif; ?>

	<form method="get" class="bazna-cijena-cjenik__search">
		<label for="bazna-cijena-q"><?php esc_html_e( 'Search', 'titanworks-bazna-cijena' ); ?></label>
		<input type="search" id="bazna-cijena-q" name="q" value="<?php echo esc_attr( $q ); ?>" placeholder="<?php echo esc_attr__( 'Search catalog items', 'titanworks-bazna-cijena' ); ?>" autocomplete="off" />
		<label for="bazna-cijena-type"><?php esc_html_e( 'Type', 'titanworks-bazna-cijena' ); ?></label>
		<select name="type" id="bazna-cijena-type">
			<option value=""><?php esc_html_e( 'All', 'titanworks-bazna-cijena' ); ?></option>
			<option value="proizvod" <?php selected( $type, 'proizvod' ); ?>><?php esc_html_e( 'Products', 'titanworks-bazna-cijena' ); ?></option>
			<option value="usluga" <?php selected( $type, 'usluga' ); ?>><?php esc_html_e( 'Services', 'titanworks-bazna-cijena' ); ?></option>
		</select>
		<button type="submit"><?php esc_html_e( 'Filter', 'titanworks-bazna-cijena' ); ?></button>
		<?php if ( '' !== $q || '' !== $type ) : ?>
			<a href="<?php echo esc_url( remove_query_arg( array( 'q', 'type', 'paged' ) ) ); ?>" class="bazna-cijena-cjenik__clear"><?php esc_html_e( 'Clear filters', 'titanworks-bazna-cijena' ); ?></a>
		<?php endif; ?>
	</form>

	<p class="bazna-cijena-cjenik__count" aria-live="polite">
		<?php if ( $twbce_total_items > 0 ) : ?>
			<?php
			$twbce_from = ( ( $twbce_paged - 1 ) * $twbce_per_page ) + 1;
			$twbce_to   = min( $twbce_total_items, $twbce_from + count( $rows ) - 1 );
			?>
			<?php
			printf(
				/* translators: 1: start row index, 2: end row index, 3: total number of rows. */
				esc_html__( 'Showing %1$d–%2$d of %3$d items.', 'titanworks-bazna-cijena' ),
				(int) $twbce_from,
				(int) $twbce_to,
				(int) $twbce_total_items
			);
			?>
		<?php else : ?>
			<?php esc_html_e( 'No items match this filter.', 'titanworks-bazna-cijena' ); ?>
		<?php endif; ?>
	</p>

	<div class="bazna-cijena-table-container">
		<table class="bazna-cijena-table">
			<caption><?php esc_html_e( 'Price list with the anchor price', 'titanworks-bazna-cijena' ); ?></caption>
			<thead>
				<tr>
					<th scope="col"><?php esc_html_e( 'Type', 'titanworks-bazna-cijena' ); ?></th>
					<th scope="col"><?php esc_html_e( 'Name', 'titanworks-bazna-cijena' ); ?></th>
					<th scope="col"><?php esc_html_e( 'SKU', 'titanworks-bazna-cijena' ); ?></th>
					<th scope="col"><?php esc_html_e( 'Brand', 'titanworks-bazna-cijena' ); ?></th>
					<th scope="col"><?php esc_html_e( 'Unit', 'titanworks-bazna-cijena' ); ?></th>
					<th scope="col"><?php esc_html_e( 'Unit price', 'titanworks-bazna-cijena' ); ?></th>
					<th scope="col"><?php esc_html_e( 'Retail price', 'titanworks-bazna-cijena' ); ?></th>
					<th scope="col"><?php esc_html_e( 'Lowest price in the last 30 days', 'titanworks-bazna-cijena' ); ?></th>
					<th scope="col"><?php esc_html_e( 'Special sale', 'titanworks-bazna-cijena' ); ?></th>
					<th scope="col"><?php esc_html_e( 'Anchor price', 'titanworks-bazna-cijena' ); ?></th>
					<th scope="col"><?php esc_html_e( 'Anchor date', 'titanworks-bazna-cijena' ); ?></th>
					<th scope="col"><?php esc_html_e( 'Barcode', 'titanworks-bazna-cijena' ); ?></th>
					<th scope="col"><?php esc_html_e( 'Availability', 'titanworks-bazna-cijena' ); ?></th>
				</tr>
			</thead>
			<tbody>
				<?php if ( empty( $rows ) ) : ?>
					<tr>
						<td colspan="13" class="bazna-cijena-table__empty">
							<span><?php esc_html_e( 'No catalog items found.', 'titanworks-bazna-cijena' ); ?></span>
							<?php if ( '' !== $q || '' !== $type ) : ?>
								<span class="bazna-cijena-cjenik__clear-wrap">
									&mdash;
									<a href="<?php echo esc_url( remove_query_arg( array( 'q', 'type', 'paged' ) ) ); ?>" class="bazna-cijena-cjenik__clear"><?php esc_html_e( 'Clear filters', 'titanworks-bazna-cijena' ); ?></a>
								</span>
							<?php endif; ?>
						</td>
					</tr>
				<?php endif; ?>
				<?php foreach ( $rows as $twbce_row ) : ?>
					<tr>
						<td><?php echo esc_html( (string) $twbce_row['type_display'] ); ?></td>
						<td><?php echo esc_html( (string) $twbce_row['naziv'] ); ?></td>
						<td><?php echo esc_html( (string) $twbce_row['sifra'] ); ?></td>
						<td><?php echo esc_html( (string) $twbce_row['marka'] ); ?></td>
						<td><?php echo esc_html( (string) $twbce_row['jedinica_mjere'] ); ?></td>
						<td><?php echo esc_html( (string) $twbce_row['unit_price_display'] ); ?></td>
						<td><?php echo esc_html( (string) $twbce_row['retail_display'] ); ?></td>
						<td><?php echo esc_html( (string) $twbce_row['lowest_30_day_display'] ); ?></td>
						<td><?php echo esc_html( (string) $twbce_row['sale_display'] ); ?></td>
						<td><?php echo esc_html( (string) $twbce_row['anchor_display'] ); ?></td>
						<td><?php echo esc_html( (string) $twbce_row['reference_display'] ); ?></td>
						<td><?php echo esc_html( (string) $twbce_row['barkod'] ); ?></td>
						<td><?php echo esc_html( (string) $twbce_row['availability_display'] ); ?></td>
					</tr>
				<?php endforeach; ?>
			</tbody>
		</table>
	</div>

	<?php if ( $twbce_total_pages > 1 ) : ?>
		<nav class="bazna-cijena-pagination" aria-label="<?php esc_attr_e( 'Price list pagination', 'titanworks-bazna-cijena' ); ?>">
			<?php
			echo wp_kses_post(
				paginate_links(
					array(
						'base'               => add_query_arg( 'paged', '%#%' ),
						'format'             => '',
						'current'            => $twbce_paged,
						'total'              => $twbce_total_pages,
						'prev_text'          => '&laquo; ' . __( 'Previous', 'titanworks-bazna-cijena' ),
						'next_text'          => __( 'Next', 'titanworks-bazna-cijena' ) . ' &raquo;',
						'before_page_number' => '<span class="screen-reader-text">' . __( 'Page', 'titanworks-bazna-cijena' ) . ' </span>',
					)
				)
			);
			?>
		</nav>
	<?php endif; ?>

	<p class="bazna-cijena-cjenik__links">
		<a href="<?php echo esc_url( $feed_xml ); ?>"><?php esc_html_e( 'XML Feed', 'titanworks-bazna-cijena' ); ?></a>
		<a href="<?php echo esc_url( $feed_csv ); ?>"><?php esc_html_e( 'CSV Feed', 'titanworks-bazna-cijena' ); ?></a>
		<a href="<?php echo esc_url( $archive_url ); ?>"><?php esc_html_e( 'Archive', 'titanworks-bazna-cijena' ); ?></a>
	</p>
</div>
