<?php
/**
 * 30-day lowest price block.
 *
 * Override this template by copying it to your theme as
 * `bazna-cijena/thirty-day-price.php`.
 *
 * @package BaznaCijena
 *
 * @var \Titanworks\BaznaCijena\Catalog\CatalogItem $item    Catalog item.
 * @var float                              $price   Lowest 30-day price.
 * @var string                             $label   Display label.
 * @var string                             $display Formatted price.
 */

defined( 'ABSPATH' ) || exit;

if ( ! isset( $display ) ) {
	return;
}

$twbce_style   = isset( $style ) && array_key_exists( $style, \Titanworks\BaznaCijena\Support\DisplayStyles::presets() ) ? $style : 'plain';
$twbce_context = isset( $context ) ? sanitize_html_class( $context ) : 'single';
$twbce_default = 'archive' === $twbce_context
	? (int) \Titanworks\BaznaCijena\Support\Settings::get( 'card_display_size', \Titanworks\BaznaCijena\Support\Settings::get( 'display_size', 40 ) )
	: (int) \Titanworks\BaznaCijena\Support\Settings::get( 'display_size', 40 );
$twbce_size    = isset( $size ) ? min( 160, max( 40, (int) $size ) ) : min( 160, max( 40, $twbce_default ) );
$twbce_classes = 'bazna-cijena bazna-cijena--30-day bazna-cijena--' . $twbce_context . ' bazna-cijena--style-' . $twbce_style;
?>
<div class="<?php echo esc_attr( $twbce_classes ); ?>" style="--bazna-size:<?php echo esc_attr( (string) ( $twbce_size / 100 ) ); ?>" data-product-id="<?php echo esc_attr( (string) $item->id ); ?>" data-variation-id="<?php echo esc_attr( (string) $item->variation_id ); ?>">
	<span class="bazna-cijena__30-day">
		<span class="bazna-cijena__label"><?php echo esc_html( $label ); ?></span>
		<span class="bazna-cijena__30-day-value" data-bazna-cijena-30-day><?php echo esc_html( $display ); ?></span>
	</span>
</div>
