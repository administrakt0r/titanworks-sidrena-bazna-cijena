=== Titanworks Bazna Cijena ===
Contributors: titanworks
Tags: croatia, price, compliance, woocommerce, price list
Requires at least: 6.8
Tested up to: 7.1
Requires PHP: 7.4
Stable tag: 2.0.50
License: GPL-2.0-or-later
License URI: https://www.gnu.org/licenses/gpl-2.0.html
Donate link: https://sidrenacijena.eu/

Croatian anchor prices, 30-day sale-price history and daily CSV/XML price lists for WooCommerce or a standalone catalog.

== Description ==

This plugin is a technical compliance aid for Croatian merchants who must
display an additional reference price ("sidrena cijena") next to the current
retail price, publish a daily machine-readable price list, and show the lowest
price of the previous 30 days during special forms of sale.

**It is not legal advice.** Merchants remain responsible for their own legal
compliance and should obtain professional legal or accounting advice.

Main features:

* Immutable anchor price records with reference dates, sources and a full audit trail.
* Frontend display of the current price and the anchor price, clearly labelled ("Sidrena cijena").
* Separate 30-day lowest-price engine for special forms of sale (akcija, sniženje, sezonsko sniženje, rasprodaja).
* Daily CSV and XML price-list generation per sales location, with a documented filename profile and at least 30-day retention.
* Public, unauthenticated machine-readable price endpoint (`/wp-json/bazna-cijena/v1/prices`).
* Compliance dashboard, validator with severity levels, CSV import with preview and rollback, price-history audit screen, structured logs and WP-CLI commands.
* WooCommerce is optional: the compliance workflow also works with the built-in standalone catalog.

== Installation ==

1. Install **Titanworks Bazna Cijena** from **Plugins → Add New Plugin**, or upload the plugin ZIP.
2. Activate the plugin through the *Plugins* screen.
3. Open *Sidrena cijena → Postavke* and review the reference dates and display settings.
4. Record or import anchor prices for your catalog.
5. Generate the price lists and confirm the public endpoints.

== Frequently Asked Questions ==

= Is this legal advice? =

No. It is a technical aid that implements documented obligations; consult a
legal or accounting professional for your specific situation.

= Does it require WooCommerce? =

No. WooCommerce integration is enabled automatically when WooCommerce is
active; otherwise the standalone catalog is used.

= Which reference dates are used? =

The general reference date is 10 September 2026. Legacy categories (food,
beverages, cosmetics, cleaning products, toiletries, household products) use
2 May 2025. Both are configurable under *Sidrena cijena → Postavke → Pravna
pravila*, and every change is recorded in the audit trail. Map your actual legacy
category slugs there before publishing; the plugin does not guess categories.

= Are the Croatian rules final? =

The obligation applies from 17 November 2026 under the Government decisions NN 101/2026 as postponed by NN 110/2026. The Ministry of Economy has drafted pravilnici on the base price and on publishing price lists, which may refine details such as exemptions. The plugin follows the decisions in force and does not implement draft rules. Check Narodne novine and your adviser for the final texts.

= Does the plugin invent historical prices? =

Never. Newly created offers witnessed at publication can receive their actual
first-offer price and observed date automatically. Existing catalog gaps and
imports require evidenced historical prices. Merchants must verify the price,
date, product identity and applicable sale classification before publishing.

== External services ==

The plugin sends no catalog data or telemetry to an external service. Price
history, validation and file generation run on your WordPress installation.
WordPress itself may contact WordPress.org for standard plugin updates.

== Privacy ==

The plugin stores catalog prices, historical evidence, shop addresses, publication
records and operational logs in your WordPress database and uploads directory.
Audit records include the acting WordPress user's ID and reasons supplied for
corrections. Do not put customer details or unnecessary personal data in these
fields. This plugin does not add tracking cookies or collect customer orders.

Published catalog fields, sales-location addresses and generated price lists are
public by design, including the REST feed and retained archive. Restrict catalog
content to information intended for publication. Deactivation and ordinary
uninstall retain data. Optional uninstall cleanup removes operational data and
files but preserves anchor and 30-day evidence, including their audit attribution.
Review retained records with your data-protection and legal advisers.

== Screenshots ==

1. Public price-list page with search, item types and downloads.
2. Administrative compliance dashboard with anchor price coverage, validator findings and publication status.
3. Price history and immutable audit log of statutory reference dates.
4. Plugin settings and legal rules configuration.

== Changelog ==

= 2.0.50 =
* Theme Compatibility: templates now use semantic HTML5 root <span> elements with display: block instead of <div>, preventing browser DOM splitting inside <p class="price"> and <span class="price"> wrappers.
* Variations: added MutationObserver and variation handler in frontend.js for themes with custom selected price summaries (e.g. .growshophr-selected-price), dynamically syncing anchor prices and 30-day lowest prices on card/pill selection.
* Tooltips: stored legal tooltip text in data-tooltip-text to prevent server-side tag stripping (e.g. search indexes, RSS feeds, recently viewed widgets) from concatenating legal explanation paragraphs into plain-text prices, with seamless CSS/JS hydration.
* Layout: standardized full-width flexbox wrapping (.price > .bazna-cijena) in modern catalog product grids to prevent staggered card heights and button misalignment.
* Tooltip Clipping: un-clipped tooltip popups on hover and active states (.product-card:has(...)) to prevent overflow: hidden card bounds from cropping tooltips.
* Mobile & Checkout: hidden compliance badges on 48px mobile sticky purchase bars to protect touch targets; added responsive wrapping for reference pricing in classic checkout order review tables.
* Extensibility: added filterable archive hooks (twbce_cijena_archive_hooks) supporting custom theme loop hooks such as growshophr_product_card_content.

= 2.0.49 =
* Accessibility: the public price table can now receive keyboard focus and scroll with the arrow keys, with a visible focus outline.
* Performance: public price-list pages format only the visible rows after pagination, reducing work on large catalogs without changing the output.
* Admin: an empty Audit operational log now distinguishes no entries from no results for a selected filter.
* Cleanup: removed unused cart unit-label CSS. No change to legal price calculations or stored history.

= 2.0.48 =
* Storefront: the public price list now shows one clear empty state when a filter has no matches; open anchor tooltips stay positioned inside the viewport after resizing.
* Admin: Logs and Price History offer a Clear filters link. An unfiltered empty Logs page now says that no entries exist.
* Performance: public price-list generation releases the runtime object cache in batches on large catalogs, reducing measured peak memory from 249.1 MiB to 147.6 MiB on 5,216 items without changing the HTML.
* Cleanup: removed unused internal helpers, an orphan CI template and unused admin CSS selectors. No change to legal price calculations or stored history.

= 2.0.47 =
* Fix: the anchor-price tooltip now closes with Esc or a second tap or Enter even while the pointer or focus is still on it (it previously stayed visible).
* Performance: the cart/checkout block script and its WooCommerce checkout dependencies load only when cart and checkout reference lines are turned on, removing about 43 scripts from every storefront page by default.
* Admin: every logged event (including generation warnings, catch-up runs and file integrity checks) now has a translated label and can be selected in the Logs and Audit filters.
* Code: removed unused internal methods. No change to price history, exports or legal display rules.

= 2.0.46 =
* Performance: daily price-list generation no longer runs per-product queries for barcodes, categories and variations. On a 4,800-item catalog this cuts queries from about 10,600 to about 600 and halves run time. Published CSV/XML output is unchanged.
* Performance: generation peak memory no longer grows with the catalog (290 MiB to 158 MiB on 4,800 items), keeping large shops under a 256M memory limit. It can be turned off with the twbce_cijena_generation_release_object_cache filter.
* Packaging: the development-only seed-test-data WP-CLI command is no longer included in the release package.

= 2.0.45 =
* Fix: the "mono" label preset is visible and legible again inside block-theme price wrappers (it had lost its dark background, leaving white text on white), and its sale-type and disclaimer lines meet 4.5:1 contrast.
* Fix: cart and checkout reference lines follow the theme text colour instead of hardcoded dark greys, so they stay readable on dark themes.

Older releases (2.0.44 and earlier) are listed in CHANGELOG.md and on the [GitHub releases page](https://github.com/administrakt0r/titanworks-sidrena-bazna-cijena/releases).
