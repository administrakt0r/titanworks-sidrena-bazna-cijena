=== Titanworks Bazna Cijena ===
Contributors: titanworks
Tags: croatia, price, compliance, woocommerce, price list
Requires at least: 6.8
Tested up to: 7.1
Requires PHP: 7.4
Stable tag: 2.1.7
License: GPL-2.0-or-later
License URI: https://www.gnu.org/licenses/gpl-2.0.html
Donate link: https://sidrenacijena.eu/

Croatian anchor prices, 30-day sale-price history and daily CSV/XML price lists for WooCommerce or a standalone catalog.

== Description ==

This plugin is a technical compliance aid for Croatian merchants who must
display the base price ("bazna cijena", NN 132/2026-1583) next to the current
retail price, publish a machine-readable price list (NN 132/2026-1584), and show
the lowest price of the previous 30 days during special forms of sale.

**It is not legal advice.** Merchants remain responsible for their own legal
compliance and should obtain professional legal or accounting advice.

Main features:

* Immutable anchor price records with reference dates, sources and a full audit trail.
* Frontend display of the current price and the anchor price, clearly labelled ("Bazna cijena").
* Separate 30-day lowest-price engine for special forms of sale (akcija, sniženje, sezonsko sniženje, rasprodaja).
* CSV and XML goods and services price lists in the NN 132/2026-1584 column order and filename format, republished after every price change before 11:00, with replaced lists archived for 15 days.
* Services price list (USLUGE) for paid delivery and other services: import WooCommerce shipping methods in one click, prices stay in sync automatically.
* Public, unauthenticated machine-readable price endpoint (`/wp-json/bazna-cijena/v1/prices`).
* Compliance dashboard, validator with severity levels, CSV import with preview and rollback, price-history audit screen, structured logs and WP-CLI commands.
* WooCommerce is optional: the compliance workflow also works with the built-in standalone catalog.

== Installation ==

1. Install **Titanworks Bazna Cijena** from **Plugins → Add New Plugin**, or upload the plugin ZIP.
2. Activate the plugin through the *Plugins* screen.
3. Open *Sidrena cijena → Postavke* and review the reference dates and display settings.
4. Record or import anchor prices for your catalog.
5. Generate the price lists and confirm the public endpoints.

== Frequently Asked Questions ==

= Is this legal advice? =

No. It is a technical aid that implements documented obligations; consult a
legal or accounting professional for your specific situation.

= Does it require WooCommerce? =

No. WooCommerce integration is enabled automatically when WooCommerce is
active; otherwise the standalone catalog is used.

= Which reference dates are used? =

The general reference date is 10 September 2026. Legacy categories (food,
beverages, cosmetics, cleaning products, toiletries, household products) use
2 May 2025. Both are configurable under *Sidrena cijena → Postavke → Pravna
pravila*, and every change is recorded in the audit trail. Map your actual legacy
category slugs there before publishing; the plugin does not guess categories.

= Are the Croatian rules final? =

Yes. Since 17 November 2026 the plugin implements the pravilnici NN 132/2026-1583 (base price) and NN 132/2026-1584 (price lists), which replace the September Government decisions. Version 2.1.0 migrates the label, deadline, retention, columns and filenames. Set the merchant OIB under Settings before generating.

= Does the plugin invent historical prices? =

Never. Newly created offers witnessed at publication can receive their actual
first-offer price and observed date automatically. Existing catalog gaps and
imports require evidenced historical prices. Merchants must verify the price,
date, product identity and applicable sale classification before publishing.

== External services ==

The plugin sends no catalog data or telemetry to an external service. Price
history, validation and file generation run on your WordPress installation.
WordPress itself may contact WordPress.org for standard plugin updates.

== Privacy ==

The plugin stores catalog prices, historical evidence, shop addresses, publication
records and operational logs in your WordPress database and uploads directory.
Audit records include the acting WordPress user's ID and reasons supplied for
corrections. Do not put customer details or unnecessary personal data in these
fields. This plugin does not add tracking cookies or collect customer orders.

Published catalog fields, sales-location addresses and generated price lists are
public by design, including the REST feed and retained archive. Restrict catalog
content to information intended for publication. Deactivation and ordinary
uninstall retain data. Optional uninstall cleanup removes operational data and
files but preserves anchor and 30-day evidence, including their audit attribution.
Review retained records with your data-protection and legal advisers.

== Screenshots ==

1. Public price-list page with search, item types and downloads.
2. Administrative compliance dashboard with anchor price coverage, validator findings and publication status.
3. Price history and immutable audit log of statutory reference dates.
4. Plugin settings and legal rules configuration.

== Changelog ==

= 2.1.7 =
* Fix: the optional author credit on the price-list pages now links to administraktor.com.

= 2.1.6 =
* New: services price list (USLUGE). Paid delivery and other services get their own list, feed and table on the price-list page. WooCommerce shipping methods can be imported and stay in sync (price, name, tax, enabled state).
* New: a new or newly published product (including older drafts) gets its base price automatically from its regular price, dated the first day it is offered. A base-price check finds missing or misdated items and repairs only those with proof.
* New: setup wizard (company and OIB, categories, prices, services, storefront, checks), a tidier admin menu and settings, and an opt-in author credit on the price-list pages. The admin now says "Bazna cijena" everywhere.
* Fix: the public price list shows the statutory columns with each item's base-price date; the dashboard no longer counts variable products as missing; old-format files no longer raise errors forever; a successful manual run clears the "failed" status; no PHP notice on product edit.

= 2.1.5 =
* Fix: price lists published by an older version (old columns and file name) are now rebuilt automatically after the upgrade, instead of waiting for the next daily run. Saving the OIB, list scope or formats also republishes the lists.

= 2.1.4 =
* Fix: variable product pages no longer show the base price twice when Display position is "Separate block below the price". The parent block hides while the selected variation shows its own base price and returns when the selection is cleared.

= 2.1.3 =
* Style: the default base-price display is now plain inline text next to the price, with no grey box or border, a muted label and a thin outlined help icon. Product cards take less space and the value no longer wraps. Boxed styles remain available in the settings.

= 2.1.2 =
* Fix: product cards no longer show the base price twice when Display position is "Separate block below the price" and the theme fires several card hooks. The block now renders once per card, below the price.

= 2.1.1 =
* Fix: the public price-list archive page no longer runs out of memory on large catalogs. Listing publications now reads only the error and warning counts instead of every stored compliance finding.

= 2.1.0 =
* Compliance: price lists follow NN 132/2026-1584. They use the new goods column order (adds neto_kolicina and ean_barkod; drops vrsta, datum_sidrene_cijene and dostupnost), and services go in a separate list.
* Compliance: filenames start with the merchant OIB and include ROBA/USLUGE, YYYYMMDD, and ZA_SVA_PRODAJNA_MJESTA when one list covers all locations. A missing OIB blocks generation.
* Compliance: the 11:00 deadline applies, any price change republishes within minutes, and replaced lists stay public for 15 days after replacement.
* Compliance: the label defaults to "Bazna cijena" and legacy labels and tooltip are migrated. Variable products show the base-price range before a variation is chosen. Sale prices are never captured as the base price.
* Fix: SKUs are no longer copied into the barcode column, and WooCommerce's GTIN field is read. Missing prices export as empty instead of 0,00.
* Fix: the public feeds disable LiteSpeed/CDN page caching and are purged after each publication.
* Fix: the base-price range on variable products no longer disappears on page load or after a variation is cleared.
* Fix: settings migrate on cron and WP-CLI too, so the first scheduled run after updating already uses the new rules. XML records always carry every field in the statutory order.
* Import: the plugin's own NN 132/2026 goods list can be re-imported. A file without a reference-date column keeps each item's existing base-price date; new items need a date. Standalone and WooCommerce products get a net quantity field.
* Fix: an identical list republishes after it was superseded or when the OIB or list scope changes, and other locations' lists are retired only after the shared list publishes.

= 2.0.51 =
* Layout & Flexbox: added flex-wrap protection and flex-shrink safeguards (.woocommerce-Price-amount, ins, del) for flex price containers in themes, preventing 100% width reference lines from compressing the main product price into a narrow column on single product pages.

Older releases (2.0.50 and earlier) are listed in CHANGELOG.md and on the [GitHub releases page](https://github.com/administrakt0r/titanworks-sidrena-bazna-cijena/releases).

