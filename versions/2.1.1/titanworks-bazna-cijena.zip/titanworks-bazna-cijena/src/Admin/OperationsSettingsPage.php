<?php
/**
 * Operational settings tab.
 *
 * @package Titanworks\BaznaCijena\Admin
 */

namespace Titanworks\BaznaCijena\Admin;

use Titanworks\BaznaCijena\Export\FilenameGenerator;
use Titanworks\BaznaCijena\Support\Settings;

defined( 'ABSPATH' ) || exit;

/**
 * Publication deadline, retention and lifecycle settings.
 */
final class OperationsSettingsPage {

	/**
	 * Settings page slug used by do_settings_sections().
	 */
	const PAGE = 'bazna-cijena-settings-operations';

	/**
	 * Register sections and fields.
	 *
	 * @return void
	 */
	public static function register_settings() {
		add_settings_section(
			'twbce_cijena_operations',
			__( 'Publication and lifecycle', 'titanworks-bazna-cijena' ),
			array( __CLASS__, 'section_intro' ),
			self::PAGE
		);

		$fields = array(
			'merchant_oib'                 => array(
				'label' => __( 'Merchant OIB', 'titanworks-bazna-cijena' ),
				'type'  => 'oib',
			),
			'merchant_id_type'             => array(
				'label' => __( 'Identifier type', 'titanworks-bazna-cijena' ),
				'type'  => 'id_type',
			),
			'price_list_scope'             => array(
				'label' => __( 'Price lists per location', 'titanworks-bazna-cijena' ),
				'type'  => 'scope',
			),
			'regenerate_on_change'         => array(
				'label' => __( 'Republish on price change', 'titanworks-bazna-cijena' ),
				'type'  => 'checkbox',
			),
			'public_archive_enabled'       => array(
				'label' => __( 'Public price-list archive', 'titanworks-bazna-cijena' ),
				'type'  => 'checkbox',
			),
			'archive_footer_link'          => array(
				'label' => __( 'Link from the site footer', 'titanworks-bazna-cijena' ),
				'type'  => 'checkbox',
			),
			'archive_sitemap_link'         => array(
				'label' => __( 'Include in the WordPress sitemap', 'titanworks-bazna-cijena' ),
				'type'  => 'checkbox',
			),
			'deadline'                     => array(
				'label' => __( 'Daily publication deadline', 'titanworks-bazna-cijena' ),
				'type'  => 'time',
			),
			'retention_days'               => array(
				'label' => __( 'Price-list retention (days)', 'titanworks-bazna-cijena' ),
				'type'  => 'number',
			),
			'log_retention_days'           => array(
				'label' => __( 'Log retention (days)', 'titanworks-bazna-cijena' ),
				'type'  => 'number',
			),
			'formats'                      => array(
				'label' => __( 'Export formats', 'titanworks-bazna-cijena' ),
				'type'  => 'formats',
			),
			'allow_generation_with_errors' => array(
				'label' => __( 'Mandatory price-list generation', 'titanworks-bazna-cijena' ),
				'type'  => 'checkbox',
			),
			'delete_data_on_uninstall'     => array(
				'label' => __( 'Delete data on uninstall', 'titanworks-bazna-cijena' ),
				'type'  => 'checkbox',
			),
		);

		foreach ( $fields as $key => $field ) {
			$field_args = array(
				'key'   => $key,
				'type'  => $field['type'],
				'label' => $field['label'],
			);

			if ( 'formats' !== $field['type'] ) {
				$field_args['label_for'] = $key;
			}

			add_settings_field(
				'twbce_cijena_' . $key,
				$field['label'],
				array( __CLASS__, 'render_field' ),
				self::PAGE,
				'twbce_cijena_operations',
				$field_args
			);
		}
	}

	/**
	 * Section introduction.
	 *
	 * @return void
	 */
	public static function section_intro() {
		echo '<p>' . esc_html__( 'Control when daily price lists are generated, how long publications and logs are kept, and what happens to compliance data when the plugin is uninstalled. Deactivation never deletes data.', 'titanworks-bazna-cijena' ) . '</p>';
	}

	/**
	 * Render one field.
	 *
	 * @param array<mixed> $args Field arguments.
	 * @return void
	 */
	public static function render_field( $args ) {
		$key    = $args['key'];
		$fields = new SettingsFields( Settings::OPTION );
		$value  = Settings::get( $key );

		switch ( $args['type'] ) {
			case 'time':
				$fields->text(
					$key,
					$value,
					array(
						'type'        => 'text',
						'class'       => 'small-text bazna-time-input',
						'placeholder' => '11:00',
						'pattern'     => '^([01]?[0-9]|2[0-3]):[0-5][0-9]$',
						'maxlength'   => 5,
						'inputmode'   => 'numeric',
						'description' => __( '24-hour format (HH:MM) in Zagreb time. The daily run starts 15 minutes earlier. The legal latest time is 11:00; later values are lowered to 11:00.', 'titanworks-bazna-cijena' ),
					)
				);
				break;
			case 'oib':
				$fields->text(
					$key,
					$value,
					array(
						'class'       => 'regular-text',
						'inputmode'   => 'numeric',
						'maxlength'   => 13,
						'description' => __( 'Required. NN 132/2026-1584 requires the OIB (legal entities) or registration number (natural persons) at the start of every price-list filename. Generation stops until a valid value is entered.', 'titanworks-bazna-cijena' ),
					)
				);
				if ( '' !== (string) $value && '' === FilenameGenerator::merchant_id() ) {
					echo '<p class="description" style="color:#b32d2e">' . esc_html__( 'This value fails the OIB check digit (ISO 7064 MOD 11,10).', 'titanworks-bazna-cijena' ) . '</p>';
				}
				break;
			case 'id_type':
				$fields->select(
					$key,
					$value,
					array(
						'oib' => __( 'OIB (legal entity, 11 digits)', 'titanworks-bazna-cijena' ),
						'mbg' => __( 'Registration number (natural person)', 'titanworks-bazna-cijena' ),
					)
				);
				break;
			case 'scope':
				$fields->select(
					$key,
					$value,
					array(
						'auto'          => __( 'Automatic: one list for all locations when their lists are identical', 'titanworks-bazna-cijena' ),
						'all_locations' => __( 'Always one list for all sales locations (ZA_SVA_PRODAJNA_MJESTA)', 'titanworks-bazna-cijena' ),
						'per_location'  => __( 'Always a separate list for every location', 'titanworks-bazna-cijena' ),
					),
					array(
						'description' => __( 'NN 132/2026-1584 requires a separate list for every sales location unless the same list applies to all of them.', 'titanworks-bazna-cijena' ),
					)
				);
				break;
			case 'number':
				$fields->number(
					$key,
					$value,
					array(
						'min'         => 'retention_days' === $key ? Settings::MIN_RETENTION_DAYS : 1,
						'description' => 'retention_days' === $key
							? __( 'A replaced price list stays publicly available for this many days after it was replaced. The legal minimum is 15; lower values are raised to 15.', 'titanworks-bazna-cijena' )
							: __( 'Operational log entries older than this are pruned by the daily cleanup.', 'titanworks-bazna-cijena' ),
					)
				);
				break;
			case 'formats':
				$fields->checkboxes(
					$key,
					(array) $value,
					array(
						'csv' => __( 'CSV', 'titanworks-bazna-cijena' ),
						'xml' => __( 'XML', 'titanworks-bazna-cijena' ),
					),
					array(
						'description' => __( 'Both formats are published for every location unless the location restricts them.', 'titanworks-bazna-cijena' ),
						'legend'      => isset( $args['label'] ) ? (string) $args['label'] : '',
					)
				);
				break;
			case 'checkbox':
				if ( 'public_archive_enabled' === $key ) {
					$label = __( 'Show the generated price-list archive at /arhiva-bazne-cijene/', 'titanworks-bazna-cijena' );
				} elseif ( 'archive_footer_link' === $key ) {
					$label = __( 'Show a link to the archive in the site footer', 'titanworks-bazna-cijena' );
				} elseif ( 'archive_sitemap_link' === $key ) {
					$label = __( 'Add the archive URL to the WordPress XML sitemap', 'titanworks-bazna-cijena' );
				} elseif ( 'regenerate_on_change' === $key ) {
					$label = __( 'Publish a new price list a few minutes after any product price changes', 'titanworks-bazna-cijena' );
				} elseif ( 'allow_generation_with_errors' === $key ) {
					$label = __( 'Generate and publish daily price lists even if catalog validation errors exist', 'titanworks-bazna-cijena' );
				} else {
					$label = __( 'Yes, delete all plugin data on uninstall', 'titanworks-bazna-cijena' );
				}

				$description = '';
				if ( 'delete_data_on_uninstall' === $key ) {
					$description = __( 'Danger: with this enabled, uninstalling deletes price history, publications and settings. Without it, uninstall keeps the historical and audit data. The anchor prices and the 30-day lowest prices are the legal evidence and are kept either way; delete the wp_twbce_price_history table by hand to remove them too. Never touches WooCommerce or WordPress data.', 'titanworks-bazna-cijena' );
				} elseif ( 'allow_generation_with_errors' === $key ) {
					$description = __( 'A changed price list must be published by 11:00 on the day of the change. When enabled, catalog errors do not block publication; affected rows are exported with empty values and remediation proposals are attached. Fix every error: an empty base price is itself a breach.', 'titanworks-bazna-cijena' );
				} elseif ( 'regenerate_on_change' === $key ) {
					$description = __( 'Recommended. NN 132/2026-1584 requires the changed list by 11:00 on the day of the change. WP-Cron only runs on site visits, so use a real server cron for wp-cron.php on low-traffic sites.', 'titanworks-bazna-cijena' );
				}

				$fields->checkbox(
					$key,
					$value,
					array(
						'label'       => $label,
						'description' => $description,
					)
				);
				break;
			default:
				$fields->text( $key, $value );
				break;
		}
	}

	/**
	 * Render the tab fields.
	 *
	 * @return void
	 */
	public static function render_fields() {
		do_settings_sections( self::PAGE );
	}
}
