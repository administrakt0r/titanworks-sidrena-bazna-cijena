<?php
/**
 * Barcode classification helpers.
 *
 * @package Titanworks\BaznaCijena
 */

namespace Titanworks\BaznaCijena\Support;

defined( 'ABSPATH' ) || exit;

/**
 * Splits a stored barcode into the two NN 132/2026-1584 price list columns.
 *
 * Članak 3. stavak 2. lists "barkod" and "EAN barkod" as separate columns. A
 * value with a valid GS1 check digit (EAN-8, UPC-A, EAN-13, GTIN-14) goes to
 * both columns (an EAN is also a barcode); any other barcode only fills the
 * generic barcode column.
 */
class Barcode {

	/**
	 * Whether a value is a GS1 code (EAN-8/UPC-A/EAN-13/GTIN-14) with a valid check digit.
	 *
	 * @param string $value Barcode.
	 * @return bool
	 */
	public static function is_ean( $value ) {
		$value = (string) $value;

		if ( ! preg_match( '/^(?:[0-9]{8}|[0-9]{12,14})$/', $value ) ) {
			return false;
		}

		$digits = array_map( 'intval', str_split( $value ) );
		$check  = array_pop( $digits );
		$sum    = 0;
		$weight = 3;

		for ( $i = count( $digits ) - 1; $i >= 0; $i-- ) {
			$sum   += $digits[ $i ] * $weight;
			$weight = 3 === $weight ? 1 : 3;
		}

		return ( ( 10 - ( $sum % 10 ) ) % 10 ) === $check;
	}

	/**
	 * Split a barcode into the generic and EAN columns.
	 *
	 * @param string $value Barcode.
	 * @return array{barkod: string, ean_barkod: string}
	 */
	public static function split( $value ) {
		$value = trim( (string) $value );
		$plain = (string) preg_replace( '/[\s-]+/', '', $value );

		if ( self::is_ean( $plain ) ) {
			return array(
				'barkod'     => $plain,
				'ean_barkod' => $plain,
			);
		}

		return array(
			'barkod'     => $value,
			'ean_barkod' => '',
		);
	}
}
