<?php
/**
 * Typed plugin settings with defaults.
 *
 * @package Titanworks\BaznaCijena\Support
 */

namespace Titanworks\BaznaCijena\Support;

use Titanworks\BaznaCijena\Logging\Logger;

defined( 'ABSPATH' ) || exit;

/**
 * Reads and writes the `twbce_cijena_settings` option.
 */
final class Settings {

	/**
	 * Option name.
	 */
	const OPTION = 'twbce_cijena_settings';

	/**
	 * NN 132/2026-1584 čl. 3. st. 5.: changed price list published by 11:00.
	 */
	const LEGAL_DEADLINE = '11:00';

	/**
	 * NN 132/2026-1584 čl. 3. st. 6.: replaced lists stay available 15 days.
	 */
	const MIN_RETENTION_DAYS = 15;

	/**
	 * Default storefront tooltip (NN 132/2026-1583 čl. 3.). Untranslated on purpose:
	 * it is statutory Croatian wording shown to Croatian consumers.
	 */
	const DEFAULT_TOOLTIP = 'Bazna cijena je maloprodajna cijena koju je trgovac primijenio na referentni datum (10. 9. 2026., odnosno 2. 5. 2025. za hranu, piće, kozmetiku, sredstva za čišćenje, toaletne potrepštine i proizvode za kućanstvo) ili na dan stavljanja proizvoda u ponudu, ako je ponuđen kasnije.';

	/**
	 * Storefront label and tooltip defaults replaced by the NN 132/2026 rules.
	 */
	const LEGACY_LABELS = array( 'Sidrena cijena', 'Dodatna cijena', 'Referentna cijena' );

	/**
	 * Former default tooltip, replaced on upgrade.
	 */
	const LEGACY_TOOLTIP = 'Sidrena (bazna) cijena je redovna maloprodajna cijena na propisani referentni datum prema mjerama izravne kontrole cijena.';

	/**
	 * Default settings.
	 *
	 * @return array<mixed>
	 */
	public static function defaults() {
		return array(
			'display_enabled'              => true,
			'anchor_label'                 => __( 'Bazna cijena', 'titanworks-bazna-cijena' ),
			'currency_display'             => 'symbol',
			'display_location'             => 'price_html',
			'product_display_style'        => 'tooltip',
			'anchor_date_mode'             => 'tooltip',
			'anchor_tooltip_text'          => self::DEFAULT_TOOLTIP,
			'anchor_font_weight'           => 'normal',
			'display_size'                 => 40,
			'card_display_default'         => true,
			'card_display_style'           => 'same_as_product',
			'card_date_mode'               => 'tooltip',
			'card_font_weight'             => 'normal',
			'card_display_size'            => 40,
			'display_priority'             => 20,
			'display_product_pages'        => true,
			'display_archives'             => true,
			'public_archive_enabled'       => true,
			'archive_footer_link'          => true,
			'archive_sitemap_link'         => true,
			'display_variations'           => true,
			'display_cart_checkout'        => false,
			'only_when_different'          => false,
			'disclaimer'                   => '',
			'formats'                      => array( 'csv', 'xml' ),
			'deadline'                     => '11:00',
			'retention_days'               => 15,
			'merchant_oib'                 => '',
			'merchant_id_type'             => 'oib',
			'price_list_scope'             => 'auto',
			'regenerate_on_change'         => true,
			'log_retention_days'           => 180,
			'delete_data_on_uninstall'     => false,
			'allow_generation_with_errors' => true,
			'sale_types'                   => array( 'akcija', 'snizenje', 'sezonsko_snizenje', 'rasprodaja' ),
			'filename_separator'           => '_',
			'filename_case'                => 'upper',
			'thirty_day_label'             => __( 'Najniža cijena u zadnjih 30 dana', 'titanworks-bazna-cijena' ),
		);
	}

	/**
	 * Presets for the storefront anchor label.
	 *
	 * Merchants may choose a preset or customize their own text.
	 * Supports dynamic tokens: {datum} / {date} for the formatted reference date,
	 * and {datum_iso} for the ISO format.
	 *
	 * @return array<string, string>
	 */
	public static function anchor_label_presets() {
		return array(
			'bazna'       => __( 'Bazna cijena', 'titanworks-bazna-cijena' ),
			'bazna_datum' => __( 'Bazna cijena ({datum})', 'titanworks-bazna-cijena' ),
			'bazna_na'    => __( 'Bazna cijena na dan {datum}', 'titanworks-bazna-cijena' ),
		);
	}

	/**
	 * Request-local memoized settings.
	 *
	 * @var array<mixed>|null
	 */
	private static $memo = null;

	/**
	 * Reset the in-memory memoized settings.
	 *
	 * @return void
	 */
	public static function reset_cache() {
		self::$memo = null;
	}

	/**
	 * Hook settings change invalidation.
	 *
	 * @return void
	 */
	public static function register() {
		$callback = array( __CLASS__, 'reset_cache' );

		if ( false === has_action( 'twbce_cijena_settings_changed', $callback ) ) {
			add_action( 'twbce_cijena_settings_changed', $callback );
		}
		if ( false === has_action( 'update_option_' . self::OPTION, $callback ) ) {
			add_action( 'update_option_' . self::OPTION, $callback );
		}
		if ( false === has_action( 'delete_option_' . self::OPTION, $callback ) ) {
			add_action( 'delete_option_' . self::OPTION, $callback );
		}
	}

	/**
	 * All settings merged over defaults.
	 *
	 * @return array<mixed>
	 */
	public static function all() {
		self::register();

		if ( null !== self::$memo ) {
			return self::$memo;
		}

		$stored = get_option( self::OPTION, array() );

		if ( ! is_array( $stored ) ) {
			$stored = array();
		}

		if ( isset( $stored['thirty_day_label'] ) && 'Lowest price in the last 30 days' === $stored['thirty_day_label'] ) {
			$stored['thirty_day_label'] = __( 'Najniža cijena u zadnjih 30 dana', 'titanworks-bazna-cijena' );
		}

		$legacy_tooltip_texts = array(
			'Sidrena cijena je najniža cijena u zadnjih 30 dana prije početka posebnog oblika prodaje.',
			'Sidrena cijena je najniza cijena u zadnjih 30 dana prije pocetka posebnog oblika prodaje.',
			'Anchor price is the lowest price in the last 30 days before the sale.',
			'Anchor price is the lowest price in the last 30 days before the start of a special form of sale.',
		);
		if ( isset( $stored['anchor_tooltip_text'] ) && in_array( trim( (string) $stored['anchor_tooltip_text'] ), $legacy_tooltip_texts, true ) ) {
			$stored['anchor_tooltip_text'] = __( 'Sidrena (bazna) cijena je redovna maloprodajna cijena na propisani referentni datum prema mjerama izravne kontrole cijena.', 'titanworks-bazna-cijena' );
		}

		self::$memo = wp_parse_args( $stored, self::defaults() );

		return self::$memo;
	}

	/**
	 * Single setting value.
	 *
	 * @param string $key     Setting key.
	 * @param mixed  $default Fallback when the key is unknown.
	 * @return mixed
	 */
	public static function get( $key, $default = null ) {
		$all = self::all();

		return array_key_exists( $key, $all ) ? $all[ $key ] : $default;
	}

	/**
	 * Update settings. Only known keys are stored.
	 *
	 * @param array    $values  Key/value pairs.
	 * @param int|null $user_id Acting user; defaults to the current user.
	 * @return array The updated settings.
	 */
	public static function update( array $values, $user_id = null ) {
		$old = self::all();
		$new = $old;

		foreach ( $values as $key => $value ) {
			if ( array_key_exists( $key, $old ) ) {
				$new[ $key ] = $value;
			}
		}

		update_option( self::OPTION, $new, false );
		self::reset_cache();

		self::log_changes( $old, $new, $user_id );

		return $new;
	}

	/**
	 * Log changed settings and fire the change action.
	 *
	 * @param array    $old     Previous settings.
	 * @param array    $new     New settings.
	 * @param int|null $user_id Acting user.
	 * @return void
	 */
	private static function log_changes( array $old, array $new, $user_id = null ) {
		$changed = array();

		foreach ( $new as $key => $value ) {
			if ( array_key_exists( $key, $old ) && $old[ $key ] === $value ) {
				continue;
			}

			$changed[ $key ] = array(
				'old' => array_key_exists( $key, $old ) ? $old[ $key ] : null,
				'new' => $value,
			);
		}

		if ( empty( $changed ) ) {
			return;
		}

		if ( null === $user_id ) {
			$user_id = function_exists( 'get_current_user_id' ) ? get_current_user_id() : 0;
		}

		Logger::info(
			'settings_change',
			__( 'Plugin settings changed.', 'titanworks-bazna-cijena' ),
			array(
				'changed' => $changed,
				'user_id' => (int) $user_id,
			)
		);

		/**
		 * Fires after settings changed.
		 *
		 * @param array<mixed> $changed Changed keys with old/new values.
		 * @param array<mixed> $new     Complete new settings.
		 */
		do_action( 'twbce_cijena_settings_changed', $changed, $new );
	}

	/**
	 * Sanitize a settings array submitted through the Settings API.
	 *
	 * @param mixed $input Raw input.
	 * @return array<mixed>
	 */
	public static function sanitize( $input ) {
		$old    = self::all();
		$output = $old;

		if ( ! is_array( $input ) ) {
			return $old;
		}

		if ( isset( $input['anchor_label'] ) ) {
			$output['anchor_label'] = sanitize_text_field( (string) $input['anchor_label'] );
		}

		if ( isset( $input['thirty_day_label'] ) ) {
			$output['thirty_day_label'] = sanitize_text_field( (string) $input['thirty_day_label'] );
		}

		if ( isset( $input['currency_display'] ) && in_array( $input['currency_display'], array( 'symbol', 'code', 'none' ), true ) ) {
			$output['currency_display'] = $input['currency_display'];
		}

		if ( isset( $input['display_location'] ) && in_array( $input['display_location'], array( 'price_html', 'summary' ), true ) ) {
			$output['display_location'] = $input['display_location'];
		}

		if ( isset( $input['product_display_style'] ) && is_string( $input['product_display_style'] ) && array_key_exists( $input['product_display_style'], DisplayStyles::presets() ) ) {
			$output['product_display_style'] = $input['product_display_style'];
		}

		if ( isset( $input['anchor_date_mode'] ) && in_array( $input['anchor_date_mode'], array( 'tooltip', 'inline', 'subtext', 'hidden' ), true ) ) {
			$output['anchor_date_mode'] = $input['anchor_date_mode'];
		}

		if ( isset( $input['anchor_tooltip_text'] ) ) {
			$output['anchor_tooltip_text'] = sanitize_textarea_field( (string) $input['anchor_tooltip_text'] );
		}

		if ( isset( $input['anchor_font_weight'] ) && in_array( $input['anchor_font_weight'], array( 'normal', 'semi-bold', 'bold' ), true ) ) {
			$output['anchor_font_weight'] = $input['anchor_font_weight'];
		}

		if ( isset( $input['display_size'] ) ) {
			$output['display_size'] = min( 160, max( 40, (int) $input['display_size'] ) );
		}

		if ( isset( $input['display_priority'] ) ) {
			$output['display_priority'] = (int) $input['display_priority'];
		}

		if ( isset( $input['card_display_style'] ) && is_string( $input['card_display_style'] ) && ( 'same_as_product' === $input['card_display_style'] || array_key_exists( $input['card_display_style'], DisplayStyles::presets() ) ) ) {
			$output['card_display_style'] = $input['card_display_style'];
		}

		if ( isset( $input['card_date_mode'] ) && in_array( $input['card_date_mode'], array( 'tooltip', 'inline', 'subtext', 'hidden' ), true ) ) {
			$output['card_date_mode'] = $input['card_date_mode'];
		}

		if ( isset( $input['card_font_weight'] ) && in_array( $input['card_font_weight'], array( 'normal', 'semi-bold', 'bold' ), true ) ) {
			$output['card_font_weight'] = $input['card_font_weight'];
		}

		if ( isset( $input['card_display_size'] ) ) {
			$output['card_display_size'] = min( 160, max( 40, (int) $input['card_display_size'] ) );
		}

		// Each settings tab submits only its own fields. A flag that is not part
		// of the submitted tab must keep its stored value; the hidden companion
		// input rendered by SettingsFields::checkbox() makes present flags
		// always visible to the sanitizer, including an unchecked one.
		foreach ( array( 'display_enabled', 'display_product_pages', 'display_archives', 'card_display_default', 'display_variations', 'display_cart_checkout', 'only_when_different', 'delete_data_on_uninstall', 'allow_generation_with_errors', 'regenerate_on_change', 'public_archive_enabled', 'archive_footer_link', 'archive_sitemap_link' ) as $flag ) {
			if ( array_key_exists( $flag, $input ) ) {
				$output[ $flag ] = ! empty( $input[ $flag ] );
			}
		}

		if ( isset( $input['disclaimer'] ) ) {
			$output['disclaimer'] = wp_kses_post( (string) $input['disclaimer'] );
		}

		if ( isset( $input['formats'] ) && is_array( $input['formats'] ) ) {
			$formats = array_values( array_intersect( array( 'csv', 'xml' ), $input['formats'] ) );

			if ( ! empty( $formats ) ) {
				$output['formats'] = $formats;
			}
		}

		if ( isset( $input['deadline'] ) ) {
			$deadline = trim( (string) $input['deadline'] );
			// Normalize single-digit hour like "8:00" to "08:00".
			if ( preg_match( '/^([0-9]):([0-5][0-9])$/', $deadline, $matches ) ) {
				$deadline = '0' . $matches[1] . ':' . $matches[2];
			}
			// Convert AM/PM formatted times to 24-hour format.
			if ( preg_match( '/^([0-1]?[0-9]):([0-5][0-9])\s*(AM|PM)$/i', $deadline, $matches ) ) {
				$hour = (int) $matches[1];
				$min  = $matches[2];
				$ampm = strtoupper( $matches[3] );
				if ( 'PM' === $ampm && $hour < 12 ) {
					$hour += 12;
				} elseif ( 'AM' === $ampm && 12 === $hour ) {
					$hour = 0;
				}
				$deadline = sprintf( '%02d:%s', $hour, $min );
			}
			if ( preg_match( '/^([01][0-9]|2[0-3]):[0-5][0-9]$/', $deadline ) ) {
				// NN 132/2026-1584 čl. 3. st. 5.: a changed list is due by 11:00.
				$output['deadline'] = strcmp( $deadline, self::LEGAL_DEADLINE ) > 0 ? self::LEGAL_DEADLINE : $deadline;
			}
		}

		if ( isset( $input['retention_days'] ) ) {
			$output['retention_days'] = max( self::MIN_RETENTION_DAYS, (int) $input['retention_days'] );
		}

		if ( isset( $input['log_retention_days'] ) ) {
			$output['log_retention_days'] = max( 1, (int) $input['log_retention_days'] );
		}

		if ( isset( $input['sale_types'] ) ) {
			$types = is_array( $input['sale_types'] )
				? $input['sale_types']
				: preg_split( '/[\r\n,;]+/', (string) $input['sale_types'] );
			$types = array_filter( array_map( 'sanitize_key', (array) $types ) );

			if ( ! empty( $types ) ) {
				$output['sale_types'] = array_values( array_unique( $types ) );
			}
		}

		if ( isset( $input['merchant_oib'] ) ) {
			$output['merchant_oib'] = (string) preg_replace( '/[^0-9]/', '', (string) $input['merchant_oib'] );
		}

		if ( isset( $input['merchant_id_type'] ) && in_array( $input['merchant_id_type'], array( 'oib', 'mbg' ), true ) ) {
			$output['merchant_id_type'] = $input['merchant_id_type'];
		}

		if ( isset( $input['price_list_scope'] ) && in_array( $input['price_list_scope'], array( 'auto', 'all_locations', 'per_location' ), true ) ) {
			$output['price_list_scope'] = $input['price_list_scope'];
		}

		if ( isset( $input['filename_separator'] ) && in_array( $input['filename_separator'], array( '_', '-' ), true ) ) {
			$output['filename_separator'] = $input['filename_separator'];
		}

		if ( isset( $input['filename_case'] ) && in_array( $input['filename_case'], array( 'upper', 'lower' ), true ) ) {
			$output['filename_case'] = $input['filename_case'];
		}

		self::log_changes( $old, $output );

		return $output;
	}
}
