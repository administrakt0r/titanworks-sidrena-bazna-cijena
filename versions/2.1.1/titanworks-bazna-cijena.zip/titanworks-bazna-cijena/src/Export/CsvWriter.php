<?php
/**
 * Deterministic price-list CSV writer.
 *
 * @package Titanworks\BaznaCijena\Export
 */

namespace Titanworks\BaznaCijena\Export;

use Titanworks\BaznaCijena\Support\Currency;

defined( 'ABSPATH' ) || exit;

/**
 * Writes the documented CSV format (`docs/price-list-format.md`): UTF-8 without
 * BOM, `;` delimiter, comma decimals, RFC 4180 quoting, LF line endings.
 */
class CsvWriter {

	/**
	 * Field delimiter.
	 *
	 * @var string
	 */
	const DELIMITER = ';';

	/**
	 * Stable column order.
	 *
	 * @var string[]
	 */
	const COLUMNS = self::GOODS_COLUMNS;

	/**
	 * Goods price list columns in the mandatory NN 132/2026-1584 čl. 3. st. 2. order.
	 *
	 * The maloprodajna cijena and the special-form-of-sale information are one
	 * item of the regulation, published as two adjacent columns.
	 */
	const GOODS_COLUMNS = array(
		'naziv',
		'sifra',
		'marka',
		'neto_kolicina',
		'jedinica_mjere',
		'maloprodajna_cijena',
		'poseban_oblik_prodaje',
		'cijena_za_jedinicu_mjere',
		'barkod',
		'ean_barkod',
		'bazna_cijena',
	);

	/**
	 * Services price list columns in the mandatory NN 132/2026-1584 čl. 3. st. 3. order.
	 */
	const SERVICES_COLUMNS = array(
		'naziv_usluge',
		'maloprodajna_cijena',
		'poseban_oblik_prodaje',
		'bazna_cijena',
	);

	/**
	 * List type: `goods` or `services`.
	 *
	 * @var string
	 */
	protected $list;

	/**
	 * Constructor.
	 *
	 * @param string $list List type: `goods` or `services`.
	 */
	public function __construct( $list = 'goods' ) {
		$this->list = 'services' === $list ? 'services' : 'goods';
	}

	/**
	 * Header row for the active list type.
	 *
	 * @return string[]
	 */
	public function columns() {
		return 'services' === $this->list ? self::SERVICES_COLUMNS : self::GOODS_COLUMNS;
	}

	/**
	 * Render the whole document as a string.
	 *
	 * @param array<mixed>[] $items Canonical rows.
	 * @return string
	 */
	public function to_string( array $items ) {
		$lines = array( $this->line( $this->columns() ) );

		foreach ( $items as $item ) {
			$lines[] = $this->line( $this->fields( $item ) );
		}

		return implode( '', $lines );
	}

	/**
	 * Write the document to an open stream.
	 *
	 * @param resource       $handle Open stream.
	 * @param array<mixed>[] $items  Canonical rows.
	 * @return int Number of rows written (excluding the header).
	 */
	public function write( $handle, array $items ) {
		// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fwrite -- Streaming the generated price list.
		fwrite( $handle, $this->line( $this->columns() ) );

		$count = 0;

		foreach ( $items as $item ) {
			// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fwrite -- Streaming the generated price list.
			fwrite( $handle, $this->line( $this->fields( $item ) ) );
			++$count;
		}

		return $count;
	}

	/**
	 * Stream CSV lines to a file handle and incrementally update a hash context.
	 *
	 * @param resource          $handle   Target file stream handle.
	 * @param array<mixed>[]    $items    Canonical rows.
	 * @param \HashContext|null $hash_ctx Optional hash context for write-time checksum calculation.
	 * @return int Bytes written.
	 */
	public function write_stream( $handle, array $items, $hash_ctx = null ) {
		$bytes  = 0;
		$header = $this->line( $this->columns() );

		// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fwrite -- Streaming the generated price list.
		$written = fwrite( $handle, $header );
		if ( false !== $written ) {
			$bytes += $written;
			if ( null !== $hash_ctx ) {
				hash_update( $hash_ctx, $header );
			}
		}

		foreach ( $items as $item ) {
			$line = $this->line( $this->fields( $item ) );
			// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fwrite -- Streaming the generated price list.
			$written = fwrite( $handle, $line );
			if ( false !== $written ) {
				$bytes += $written;
				if ( null !== $hash_ctx ) {
					hash_update( $hash_ctx, $line );
				}
			}
		}

		return $bytes;
	}

	/**
	 * Encode one CSV line.
	 *
	 * @param array<mixed> $fields Fields.
	 * @return string
	 */
	protected function line( array $fields ) {
		return implode( self::DELIMITER, array_map( array( $this, 'encode' ), $fields ) ) . "\n";
	}

	/**
	 * RFC 4180-style quoting: only delimiter, quote and newline force quotes.
	 *
	 * Values that spreadsheet software would evaluate as a formula are
	 * neutralised first, so a product name, SKU or brand coming from imported
	 * data cannot execute when the price list is opened in Excel/LibreOffice.
	 *
	 * @param mixed $value Value.
	 * @return string
	 */
	public function encode( $value ) {
		$value = self::neutralise_formula( (string) $value );

		if ( '' !== $value && preg_match( '/[";' . "\r\n" . ']/', $value ) ) {
			return '"' . str_replace( '"', '""', $value ) . '"';
		}

		return $value;
	}

	/**
	 * Prefix values a spreadsheet would treat as a formula with a single quote.
	 *
	 * A leading whitespace or control character is considered too, because
	 * spreadsheet applications skip it before evaluating the cell.
	 *
	 * @param string $value Raw value.
	 * @return string
	 */
	public static function neutralise_formula( $value ) {
		if ( '' === $value ) {
			return $value;
		}

		if ( preg_match( '/^[\s\x00-\x1F]*[=+\-@]/', $value ) ) {
			return "'" . $value;
		}

		return $value;
	}

	/**
	 * Convert a canonical row to ordered CSV fields.
	 *
	 * @param array<mixed> $item Canonical row.
	 * @return array<mixed>
	 */
	public function fields( array $item ) {
		$retail = self::decimal_or_empty( isset( $item['maloprodajna_cijena'] ) ? $item['maloprodajna_cijena'] : null );
		$sale   = ! empty( $item['poseban_oblik_prodaje'] ) ? 'DA' : 'NE';
		$anchor = self::decimal_or_empty( isset( $item['sidrena_cijena'] ) ? $item['sidrena_cijena'] : null );

		if ( 'services' === $this->list ) {
			return array(
				isset( $item['naziv'] ) ? (string) $item['naziv'] : '',
				$retail,
				$sale,
				$anchor,
			);
		}

		return array(
			isset( $item['naziv'] ) ? (string) $item['naziv'] : '',
			isset( $item['sifra'] ) ? (string) $item['sifra'] : '',
			isset( $item['marka'] ) ? (string) $item['marka'] : '',
			isset( $item['neto_kolicina'] ) ? (string) $item['neto_kolicina'] : '',
			isset( $item['jedinica_mjere'] ) ? (string) $item['jedinica_mjere'] : '',
			$retail,
			$sale,
			self::decimal_or_empty( isset( $item['cijena_za_jedinicu_mjere'] ) ? $item['cijena_za_jedinicu_mjere'] : null ),
			isset( $item['barkod'] ) ? (string) $item['barkod'] : '',
			isset( $item['ean_barkod'] ) ? (string) $item['ean_barkod'] : '',
			$anchor,
		);
	}

	/**
	 * Format a decimal with comma separator.
	 *
	 * @param mixed $value Value.
	 * @return string
	 */
	public static function decimal( $value ) {
		return Currency::format_decimal( (float) $value );
	}

	/**
	 * Format an optional decimal; empty string when absent.
	 *
	 * @param mixed $value Value.
	 * @return string
	 */
	public static function decimal_or_empty( $value ) {
		if ( null === $value || '' === $value ) {
			return '';
		}

		return self::decimal( $value );
	}
}
