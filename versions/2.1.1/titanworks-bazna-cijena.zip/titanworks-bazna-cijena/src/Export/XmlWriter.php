<?php
/**
 * Deterministic price-list XML writer.
 *
 * @package Titanworks\BaznaCijena\Export
 */

namespace Titanworks\BaznaCijena\Export;

use Titanworks\BaznaCijena\Support\Currency;
use Titanworks\BaznaCijena\Support\Dates;

defined( 'ABSPATH' ) || exit;

/**
 * Writes the documented XML format (`docs/price-list-format.md`): UTF-8 without
 * BOM, versioned root element, escaped values, omitted empty elements.
 */
class XmlWriter {

	/**
	 * Format version written to the root element.
	 *
	 * @var string
	 */
	const FORMAT_VERSION = '1.0';

	/**
	 * Render the document as a string.
	 *
	 * @param array<mixed>[] $items    Canonical rows.
	 * @param array<mixed>   $location Location row.
	 * @param array<mixed>   $meta     Meta (rule version, generation time).
	 * @return string
	 */
	public function to_string( array $items, array $location, array $meta = array() ) {
		$writer = new \XMLWriter();
		$writer->openMemory();
		$this->fill( $writer, $items, $location, $meta );

		return (string) $writer->outputMemory();
	}

	/**
	 * Write the document to a file.
	 *
	 * @param string         $path     Target path.
	 * @param array<mixed>[] $items    Canonical rows.
	 * @param array<mixed>   $location Location row.
	 * @param array<mixed>   $meta     Meta.
	 * @return bool
	 */
	public function write( $path, array $items, array $location, array $meta = array() ) {
		$writer = new \XMLWriter();

		if ( ! $writer->openURI( (string) $path ) ) {
			return false;
		}

		$this->fill( $writer, $items, $location, $meta );

		return (bool) $writer->flush();
	}

	/**
	 * Stream XML chunks to a file handle and incrementally update a hash context.
	 *
	 * @param resource          $handle   Target file stream handle.
	 * @param array<mixed>[]    $items    Canonical rows.
	 * @param array<mixed>      $location Location row.
	 * @param array<mixed>      $meta     Meta.
	 * @param \HashContext|null $hash_ctx Optional hash context for write-time checksum calculation.
	 * @return int Bytes written.
	 */
	public function write_stream( $handle, array $items, array $location, array $meta = array(), $hash_ctx = null ) {
		$writer = new \XMLWriter();
		$writer->openMemory();
		$writer->setIndent( true );
		$writer->setIndentString( '  ' );
		$writer->startDocument( '1.0', 'UTF-8' );

		$writer->startElement( 'cjenik' );
		$writer->writeAttribute( 'verzija', self::FORMAT_VERSION );
		$writer->writeAttribute( 'pravilo', isset( $meta['rule_version'] ) ? (string) $meta['rule_version'] : '' );
		$writer->writeAttribute(
			'generirano',
			isset( $meta['generated_at'] ) ? (string) $meta['generated_at'] : Dates::now_site()->format( 'c' )
		);

		$writer->startElement( 'prodajnoMjesto' );
		$writer->writeAttribute( 'oznaka', isset( $location['identifier'] ) ? (string) $location['identifier'] : '' );

		foreach ( array(
			'naziv'  => 'name',
			'oblik'  => 'type',
			'adresa' => 'address',
			'grad'   => 'city',
		) as $element => $key ) {
			if ( ! empty( $location[ $key ] ) ) {
				$writer->writeAttribute( $element, (string) $location[ $key ] );
			}
		}

		$bytes = 0;
		$chunk = $writer->flush();
		// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fwrite -- Streaming the generated price list.
		$w = fwrite( $handle, $chunk );
		if ( false !== $w ) {
			$bytes += $w;
			if ( null !== $hash_ctx ) {
				hash_update( $hash_ctx, $chunk );
			}
		}

		foreach ( $items as $item ) {
			$this->write_item( $writer, $item );
			$chunk = $writer->flush();
			// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fwrite -- Streaming the generated price list.
			$w = fwrite( $handle, $chunk );
			if ( false !== $w ) {
				$bytes += $w;
				if ( null !== $hash_ctx ) {
					hash_update( $hash_ctx, $chunk );
				}
			}
		}

		$writer->endElement();
		$writer->endElement();
		$writer->endDocument();

		$chunk = $writer->flush();
		// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fwrite -- Streaming the generated price list.
		$w = fwrite( $handle, $chunk );
		if ( false !== $w ) {
			$bytes += $w;
			if ( null !== $hash_ctx ) {
				hash_update( $hash_ctx, $chunk );
			}
		}

		return $bytes;
	}

	/**
	 * Fill an XMLWriter with the document.
	 *
	 * @param \XMLWriter     $writer   Writer.
	 * @param array<mixed>[] $items    Canonical rows.
	 * @param array<mixed>   $location Location row.
	 * @param array<mixed>   $meta     Meta.
	 * @return void
	 */
	protected function fill( \XMLWriter $writer, array $items, array $location, array $meta ) {
		$writer->setIndent( true );
		$writer->setIndentString( '  ' );
		$writer->startDocument( '1.0', 'UTF-8' );

		$writer->startElement( 'cjenik' );
		$writer->writeAttribute( 'verzija', self::FORMAT_VERSION );
		$writer->writeAttribute( 'pravilo', isset( $meta['rule_version'] ) ? (string) $meta['rule_version'] : '' );
		$writer->writeAttribute(
			'generirano',
			isset( $meta['generated_at'] ) ? (string) $meta['generated_at'] : Dates::now_site()->format( 'c' )
		);

		$writer->startElement( 'prodajnoMjesto' );
		$writer->writeAttribute( 'oznaka', isset( $location['identifier'] ) ? (string) $location['identifier'] : '' );

		foreach ( array(
			'naziv'  => 'name',
			'oblik'  => 'type',
			'adresa' => 'address',
			'grad'   => 'city',
		) as $element => $key ) {
			if ( ! empty( $location[ $key ] ) ) {
				$writer->writeAttribute( $element, (string) $location[ $key ] );
			}
		}

		foreach ( $items as $item ) {
			$this->write_item( $writer, $item );
		}

		$writer->endElement();
		$writer->endElement();
		$writer->endDocument();
	}

	/**
	 * Write a single `stavka` element.
	 *
	 * @param \XMLWriter   $writer Writer.
	 * @param array<mixed> $item   Canonical row.
	 * @return void
	 */
	protected function write_item( \XMLWriter $writer, array $item ) {
		$services = isset( $item['vrsta'] ) && 'usluga' === $item['vrsta'];
		$retail   = isset( $item['maloprodajna_cijena'] ) ? Currency::format_decimal_xml( $item['maloprodajna_cijena'] ) : '';
		$sale     = ! empty( $item['poseban_oblik_prodaje'] ) ? 'DA' : 'NE';
		$anchor   = isset( $item['sidrena_cijena'] ) ? Currency::format_decimal_xml( $item['sidrena_cijena'] ) : '';

		// Element order follows NN 132/2026-1584 čl. 3. st. 2. (goods) and st. 3. (services).
		$writer->startElement( 'stavka' );

		if ( $services ) {
			$this->element( $writer, 'nazivUsluge', isset( $item['naziv'] ) ? $item['naziv'] : '' );
			$writer->writeElement( 'maloprodajnaCijena', $retail );
			$writer->writeElement( 'posebanOblikProdaje', $sale );
			$writer->writeElement( 'baznaCijena', $anchor );
			$writer->endElement();

			return;
		}

		$this->element( $writer, 'naziv', isset( $item['naziv'] ) ? $item['naziv'] : '' );
		$this->element( $writer, 'sifra', isset( $item['sifra'] ) ? $item['sifra'] : '' );
		$this->element( $writer, 'marka', isset( $item['marka'] ) ? $item['marka'] : '' );
		$this->element( $writer, 'netoKolicina', isset( $item['neto_kolicina'] ) ? $item['neto_kolicina'] : '' );
		$this->element( $writer, 'jedinicaMjere', isset( $item['jedinica_mjere'] ) ? $item['jedinica_mjere'] : '' );
		$writer->writeElement( 'maloprodajnaCijena', $retail );
		$writer->writeElement( 'posebanOblikProdaje', $sale );
		$this->element(
			$writer,
			'cijenaZaJedinicuMjere',
			isset( $item['cijena_za_jedinicu_mjere'] ) ? Currency::format_decimal_xml( $item['cijena_za_jedinicu_mjere'] ) : ''
		);
		$this->element( $writer, 'barkod', isset( $item['barkod'] ) ? $item['barkod'] : '' );
		$this->element( $writer, 'eanBarkod', isset( $item['ean_barkod'] ) ? $item['ean_barkod'] : '' );
		$writer->writeElement( 'baznaCijena', $anchor );

		$writer->endElement();
	}

	/**
	 * Write an element, empty when there is no value.
	 *
	 * Every record carries every field in the NN 132/2026-1584 čl. 3. st. 4.
	 * order, so consumers can rely on one fixed record structure.
	 *
	 * @param \XMLWriter $writer Writer.
	 * @param string     $name   Element name.
	 * @param mixed      $value  Value.
	 * @return void
	 */
	protected function element( \XMLWriter $writer, $name, $value ) {
		$writer->writeElement( $name, null === $value ? '' : (string) $value );
	}
}
