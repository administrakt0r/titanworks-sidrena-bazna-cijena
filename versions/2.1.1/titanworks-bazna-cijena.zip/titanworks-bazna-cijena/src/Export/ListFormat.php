<?php
/**
 * Publication format codes.
 *
 * @package Titanworks\BaznaCijena
 */

namespace Titanworks\BaznaCijena\Export;

defined( 'ABSPATH' ) || exit;

/**
 * Maps a publication format code to its file extension and list type.
 *
 * NN 132/2026-1584 čl. 3. st. 2. and 3. define separate goods (roba) and
 * services (usluge) price lists. Goods keep the historical `csv`/`xml` codes,
 * so existing publications, feed URLs and admin filters stay valid; services
 * lists use `csv_u`/`xml_u`.
 */
final class ListFormat {

	const GOODS    = 'goods';
	const SERVICES = 'services';

	const CODES = array( 'csv', 'xml', 'csv_u', 'xml_u' );

	/**
	 * Whether a code is a known publication format.
	 *
	 * @param string $code Format code.
	 * @return bool
	 */
	public static function is_valid( $code ) {
		return in_array( (string) $code, self::CODES, true );
	}

	/**
	 * File extension (`csv` or `xml`) for a format code.
	 *
	 * @param string $code Format code.
	 * @return string
	 */
	public static function extension( $code ) {
		return 0 === strpos( (string) $code, 'xml' ) ? 'xml' : 'csv';
	}

	/**
	 * List type (`goods` or `services`) for a format code.
	 *
	 * @param string $code Format code.
	 * @return string
	 */
	public static function list_type( $code ) {
		return '_u' === substr( (string) $code, -2 ) ? self::SERVICES : self::GOODS;
	}

	/**
	 * Format code for an extension and list type.
	 *
	 * @param string $extension `csv` or `xml`.
	 * @param string $list      `goods` or `services`.
	 * @return string
	 */
	public static function code( $extension, $list ) {
		$extension = 'xml' === $extension ? 'xml' : 'csv';

		return self::SERVICES === $list ? $extension . '_u' : $extension;
	}

	/**
	 * Filename indicator for goods or services (NN 132/2026-1584 čl. 6. st. 3.).
	 *
	 * @param string $code Format code.
	 * @return string
	 */
	public static function indicator( $code ) {
		return self::SERVICES === self::list_type( $code ) ? 'USLUGE' : 'ROBA';
	}
}
