<?php
/**
 * Price-list generation service.
 *
 * @package Titanworks\BaznaCijena\Export
 */

namespace Titanworks\BaznaCijena\Export;

use Titanworks\BaznaCijena\Catalog\CatalogItem;
use Titanworks\BaznaCijena\Catalog\CatalogProvider;
use Titanworks\BaznaCijena\Compliance\RemediationProposer;
use Titanworks\BaznaCijena\Database\LocationRepository;
use Titanworks\BaznaCijena\Database\PriceHistoryRepository;
use Titanworks\BaznaCijena\Database\PublicationRepository;
use Titanworks\BaznaCijena\Database\SpecialSaleRepository;
use Titanworks\BaznaCijena\Logging\Logger;
use Titanworks\BaznaCijena\Plugin;
use Titanworks\BaznaCijena\Support\Settings;

defined( 'ABSPATH' ) || exit;

/**
 * Builds and publishes the daily price lists per sales location and format.
 */
class GenerationService {

	/**
	 * Catalog items hydrated between runtime object cache releases.
	 */
	const RUNTIME_CACHE_RELEASE_EVERY = PriceListBuilder::RUNTIME_CACHE_RELEASE_EVERY;

	/**
	 * Catalog provider.
	 *
	 * @var CatalogProvider
	 */
	protected $catalog;

	/**
	 * Location repository.
	 *
	 * @var LocationRepository
	 */
	protected $locations;

	/**
	 * Publication repository.
	 *
	 * @var PublicationRepository
	 */
	protected $publications;

	/**
	 * Price history repository.
	 *
	 * @var PriceHistoryRepository
	 */
	protected $history;

	/**
	 * Special sale repository.
	 *
	 * @var SpecialSaleRepository
	 */
	protected $sales;

	/**
	 * Constructor.
	 *
	 * @param CatalogProvider        $catalog      Catalog provider.
	 * @param LocationRepository     $locations    Location repository.
	 * @param PublicationRepository  $publications Publication repository.
	 * @param PriceHistoryRepository $history      Price history repository.
	 * @param SpecialSaleRepository  $sales        Special sale repository.
	 */
	public function __construct( CatalogProvider $catalog, LocationRepository $locations, PublicationRepository $publications, PriceHistoryRepository $history, SpecialSaleRepository $sales ) {
		$this->catalog      = $catalog;
		$this->locations    = $locations;
		$this->publications = $publications;
		$this->history      = $history;
		$this->sales        = $sales;
	}

	/**
	 * Generate price lists for every active location.
	 *
	 * @param array<mixed> $args Arguments: `source` (`scheduled|manual|cli`), `type`, `force`.
	 * @return array<mixed>
	 */
	public function generate_all( array $args = array() ) {
		if ( ! isset( $args['items'] ) ) {
			$args['items'] = $this->hydrate_catalog( $args );
		}

		$results   = array();
		$locations = (array) $this->locations->all( true );
		$single    = $this->resolve_single_list( $locations, $args );

		if ( $single ) {
			// NN 132/2026-1584 čl. 3. st. 7. i čl. 6. st. 4.: one list valid for
			// every sales location, named with ZA_SVA_PRODAJNA_MJESTA.
			$args['all_locations']          = true;
			$results[ (int) $single['id'] ] = $this->generate_location( (int) $single['id'], $args );

			// The shared list replaces every per-location list, so retire those
			// (they stay archived for the retention window) instead of leaving
			// them published next to it. Only formats whose shared replacement
			// was actually published are retired; on failure the old lists
			// stay current.
			$retire = $this->replaced_formats( $results[ (int) $single['id'] ] );

			// Routing applies to every format. Keep the previous per-location
			// publications available until the complete shared set is ready.
			$shared_results = $results[ (int) $single['id'] ];
			$transition     = ! self::single_list_mode();
			$complete       = is_array( $shared_results ) && $shared_results && ! array_filter( $shared_results, 'is_wp_error' )
				&& ! array_diff( $this->formats( $single ), array_keys( $shared_results ) );

			if ( $retire && ( ! $transition || $complete ) ) {
				if ( 'auto' === Settings::get( 'price_list_scope', 'auto' ) ) {
					update_option( self::OPTION_SINGLE_LIST, 1, false );
				}

				foreach ( $locations as $location ) {
					if ( (int) $location['id'] !== (int) $single['id'] ) {
						$this->retire_lists( (int) $location['id'], $retire );
					}
				}
			}

			return $results;
		}

		$args['all_locations'] = false;
		foreach ( $locations as $location ) {
			$results[ (int) $location['id'] ] = $this->generate_location( (int) $location['id'], $args );
		}

		if ( 'auto' === Settings::get( 'price_list_scope', 'auto' ) ) {
			$complete = ! empty( $locations );
			foreach ( $locations as $location ) {
				$loc_results = isset( $results[ (int) $location['id'] ] ) ? $results[ (int) $location['id'] ] : null;
				if (
					! is_array( $loc_results )
					|| empty( $loc_results )
					|| array_filter( $loc_results, 'is_wp_error' )
					|| array_diff( $this->formats( $location ), array_keys( $loc_results ) )
				) {
					$complete = false;
					break;
				}
			}

			if ( $complete ) {
				update_option( self::OPTION_SINGLE_LIST, 0, false );
			}
		}

		return $results;
	}

	/**
	 * Generate all configured formats for one location.
	 *
	 * @param int          $location_id Location ID.
	 * @param array<mixed> $args        Arguments.
	 * @return array<mixed>|\WP_Error
	 */
	public function generate_location( $location_id, array $args = array() ) {
		$location = $this->locations->get( $location_id );

		if ( ! $location ) {
			return new \WP_Error( 'location_not_found', __( 'The sales location could not be found.', 'titanworks-bazna-cijena' ) );
		}

		if ( ! isset( $args['items'] ) ) {
			$args['items'] = $this->hydrate_catalog( $args );
		}

		if ( ! isset( $args['validation'] ) ) {
			$args['validation'] = $this->catalog_report( $location_id, $args['items'] );
		}

		if ( ! isset( $args['build'] ) ) {
			$args['build'] = $this->builder()->build( $location, $args );
		}

		if ( ! isset( $args['all_locations'] ) ) {
			$locations             = (array) $this->locations->all( true );
			$single                = count( $locations ) > 1 && 'auto' === Settings::get( 'price_list_scope', 'auto' )
				? $this->resolve_single_list( $locations, $args )
				: null;
			$args['all_locations'] = 'all_locations' === Settings::get( 'price_list_scope', 'auto' )
				|| ( $single && self::is_public_location( $location ) );

			if ( ! $args['all_locations'] && self::single_list_mode() && count( $locations ) > 1 && $single ) {
				return new \WP_Error(
					'single_list_location',
					__( 'One price list is published for all sales locations. Generate it for the location that carries the shared list, or switch the price-list scope to one list per location.', 'titanworks-bazna-cijena' )
				);
			}
		}

		$extensions = $this->formats( $location );

		if ( ! empty( $args['formats'] ) && is_array( $args['formats'] ) ) {
			$wanted     = array_map( 'strval', $args['formats'] );
			$extensions = array_values( array_intersect( $extensions, $wanted ) );
		}

		$lists = array( ListFormat::GOODS );
		foreach ( $args['build']['items'] as $row ) {
			if ( isset( $row['vrsta'] ) && 'usluga' === $row['vrsta'] ) {
				$lists[] = ListFormat::SERVICES;
				break;
			}
		}

		$results = array();

		foreach ( $lists as $list ) {
			foreach ( $extensions as $extension ) {
				$format             = ListFormat::code( $extension, $list );
				$results[ $format ] = $this->generate( $location_id, $format, $args );
			}
		}

		// A list type with no rows any more (for example the last service was
		// removed) must not stay published as the current list.
		if ( ! in_array( ListFormat::SERVICES, $lists, true ) ) {
			$this->retire_lists( (int) $location_id, array( 'csv_u', 'xml_u' ) );
		}

		return $results;
	}

	/**
	 * Format codes whose shared replacement is in place.
	 *
	 * A format counts when its generation succeeded. Services formats also
	 * count when no services list was generated at all (there are no services
	 * any more), because the old services lists must not stay current.
	 *
	 * @param array<mixed>|\WP_Error $results Results of generate_location().
	 * @return string[]
	 */
	protected function replaced_formats( $results ) {
		if ( is_wp_error( $results ) ) {
			return array();
		}

		$replaced    = array();
		$has_service = isset( $results['csv_u'] ) || isset( $results['xml_u'] );
		$goods_ok    = false;

		foreach ( $results as $format => $result ) {
			if ( ! is_wp_error( $result ) && ListFormat::is_valid( (string) $format ) ) {
				$replaced[] = (string) $format;
				$goods_ok   = $goods_ok || ListFormat::GOODS === ListFormat::list_type( (string) $format );
			}
		}

		if ( ! $has_service && $goods_ok ) {
			$replaced[] = 'csv_u';
			$replaced[] = 'xml_u';
		}

		return $replaced;
	}

	/**
	 * Mark the published lists of a location as replaced.
	 *
	 * Replaced lists stay downloadable for the retention window
	 * (NN 132/2026-1584 čl. 3. st. 6.) and are then expired.
	 *
	 * @param int      $location_id Location ID.
	 * @param string[] $formats     Format codes.
	 * @return void
	 */
	protected function retire_lists( $location_id, array $formats ) {
		foreach ( $formats as $format ) {
			if ( $this->publications->latest( $location_id, $format, array( 'published' ) ) ) {
				$this->publications->supersede( $location_id, $format, 0 );
			}
		}
	}

	/**
	 * Locations expected to carry a current price list.
	 *
	 * With one list for all sales locations only the location that carries
	 * the shared ZA_SVA_PRODAJNA_MJESTA list publishes.
	 *
	 * @param array<int,array<mixed>> $locations Active locations.
	 * @return array<int,array<mixed>>
	 */
	public static function publishing_locations( array $locations ) {
		$locations = array_values( $locations );

		if ( count( $locations ) < 2 || ! self::single_list_mode() ) {
			return $locations;
		}

		foreach ( $locations as $location ) {
			if ( self::is_public_location( $location ) ) {
				return array( $location );
			}
		}

		return array( $locations[0] );
	}

	/**
	 * Generate one price list.
	 *
	 * @param int          $location_id Location ID.
	 * @param string       $format      Format (`csv` or `xml`).
	 * @param array<mixed> $args        Arguments.
	 * @return array<mixed>|\WP_Error
	 */
	public function generate( $location_id, $format, array $args = array() ) {
		$location = $this->locations->get( $location_id );

		if ( ! $location ) {
			return new \WP_Error( 'location_not_found', __( 'The sales location could not be found.', 'titanworks-bazna-cijena' ) );
		}

		$format = strtolower( (string) $format );

		if ( ! ListFormat::is_valid( $format ) ) {
			return new \WP_Error( 'invalid_format', __( 'The requested format is not supported.', 'titanworks-bazna-cijena' ) );
		}

		$list = ListFormat::list_type( $format );

		// Every entry point (scheduler, CLI --location, REST) must agree on the
		// list scope, so the shared-list default is resolved here too.
		if ( ! isset( $args['all_locations'] ) ) {
			$locations = (array) $this->locations->all( true );
			if ( count( $locations ) > 1 && 'auto' === Settings::get( 'price_list_scope', 'auto' ) ) {
				if ( ! isset( $args['items'] ) ) {
					$args['items'] = $this->hydrate_catalog( $args );
				}
				$this->resolve_single_list( $locations, $args );
			}
			$args['all_locations'] = self::single_list_mode() && self::is_public_location( $location );

			if ( self::single_list_mode() && ! $args['all_locations'] && count( $locations ) > 1 ) {
				return new \WP_Error(
					'single_list_location',
					__( 'One price list is published for all sales locations. Generate it for the location that carries the shared list, or switch the price-list scope to one list per location.', 'titanworks-bazna-cijena' )
				);
			}
		}

		if ( ! empty( $args['all_locations'] ) ) {
			$location['all_locations'] = true;
		}

		if ( '' === FilenameGenerator::merchant_id() ) {
			$finding = array(
				'code'           => 'missing_merchant_oib',
				'severity'       => 'ERROR',
				'message'        => __( 'The merchant OIB (or registration number) is missing or invalid. NN 132/2026-1584 requires it in every price-list filename.', 'titanworks-bazna-cijena' ),
				'proposal'       => __( 'Enter the merchant OIB under Bazna cijena > Settings > Price lists.', 'titanworks-bazna-cijena' ),
				'entity_type'    => 'settings',
				'entity_id'      => 0,
				'rule_reference' => 'NN 132/2026-1584 čl. 6.',
			);

			$this->record_failure( $location_id, $format, array( $finding ) );

			return new \WP_Error( 'missing_merchant_oib', $finding['message'], array( 'findings' => array( $finding ) ) );
		}

		$source            = isset( $args['source'] ) ? (string) $args['source'] : 'manual';
		$event             = 'scheduled' === $source ? 'export_scheduled' : 'export_manual';
		$force             = ! empty( $args['force'] );
		$allow_with_errors = $force || (bool) Settings::get( 'allow_generation_with_errors', true );

		$identifier = isset( $location['identifier'] ) ? trim( (string) $location['identifier'] ) : '';
		$findings   = array();

		if ( '' === $identifier ) {
			$findings[] = array(
				'code'           => 'missing_store_identifier',
				'severity'       => 'ERROR',
				'message'        => __( 'The sales location has no facility identifier.', 'titanworks-bazna-cijena' ),
				'proposal'       => RemediationProposer::propose( 'missing_store_identifier', array( 'name' => $location['name'] ) ),
				'entity_type'    => 'location',
				'entity_id'      => (int) $location_id,
				'rule_reference' => 'FR-040',
			);

			// A made-up identifier would publish a misleading statutory filename,
			// so this blocks even forced runs. A single list for all locations
			// does not carry the location code and is unaffected.
			if ( empty( $location['all_locations'] ) ) {
				$this->record_failure( $location_id, $format, $findings );

				return new \WP_Error( 'missing_store_identifier', $findings[0]['message'], array( 'findings' => $findings ) );
			}

			$findings = array();
		}

		// Ensure address and city are populated for filename generation.
		if ( empty( $location['address'] ) ) {
			$wc_addr             = (string) get_option( 'woocommerce_store_address', '' );
			$location['address'] = '' !== $wc_addr ? $wc_addr : __( 'Online', 'titanworks-bazna-cijena' );
		}
		if ( empty( $location['city'] ) ) {
			$wc_city          = (string) get_option( 'woocommerce_store_city', '' );
			$location['city'] = '' !== $wc_city ? $wc_city : __( 'Hrvatska', 'titanworks-bazna-cijena' );
		}

		if ( ! isset( $args['items'] ) ) {
			$args['items'] = $this->hydrate_catalog( $args );
		}

		$validation   = isset( $args['validation'] ) && is_array( $args['validation'] )
			? $args['validation']
			: $this->catalog_report( $location_id, $args['items'] );
		$blockers     = self::publication_blockers( $validation['errors'] );
		$all_blockers = array_merge( $findings, $blockers );

		if ( ! empty( $all_blockers ) && ! $allow_with_errors ) {
			$this->record_failure( $location_id, $format, $all_blockers );

			return new \WP_Error( 'validation_failed', __( 'The price list failed compliance validation and was not published.', 'titanworks-bazna-cijena' ), array( 'findings' => $all_blockers ) );
		}

		$proposals = array();
		foreach ( $all_blockers as &$b_finding ) {
			if ( empty( $b_finding['proposal'] ) ) {
				$code = isset( $b_finding['code'] ) ? (string) $b_finding['code'] : '';
				$ctx  = isset( $b_finding['context'] ) && is_array( $b_finding['context'] ) ? $b_finding['context'] : array();

				$b_finding['proposal'] = RemediationProposer::propose( $code, $ctx );
			}
			if ( ! empty( $b_finding['proposal'] ) ) {
				$proposals[] = $b_finding['proposal'];
			}
		}
		unset( $b_finding );

		$build = isset( $args['build'] ) && is_array( $args['build'] )
			? $args['build']
			: $this->builder()->build( $location, $args );

		$items = array_values(
			array_filter(
				$build['items'],
				static function ( $row ) use ( $list ) {
					$is_service = isset( $row['vrsta'] ) && 'usluga' === $row['vrsta'];

					return ListFormat::SERVICES === $list ? $is_service : ! $is_service;
				}
			)
		);
		$meta  = $build['meta'];

		$fingerprint = $this->builder()->fingerprint( $items, $location, $format, (string) $meta['rule_version'] );

		$content = 'xml' === ListFormat::extension( $format )
			? function ( $handle, $hash_ctx ) use ( $items, $location, $meta ) {
				return ( new XmlWriter() )->write_stream( $handle, $items, $location, $meta, $hash_ctx );
			}
			: function ( $handle, $hash_ctx ) use ( $items, $list ) {
				return ( new CsvWriter( $list ) )->write_stream( $handle, $items, $hash_ctx );
			};

		$result = $this->publisher()->publish(
			$location,
			$format,
			$content,
			array(
				'fingerprint'        => $fingerprint,
				'item_count'         => count( $items ),
				'rule_version'       => (string) $meta['rule_version'],
				'validation_summary' => array(
					'errors'    => count( $all_blockers ),
					'warnings'  => (int) $validation['warnings'] + count( $validation['errors'] ) - count( $blockers ),
					'findings'  => $all_blockers,
					'proposals' => $proposals,
				),
				'force'              => $force,
			)
		);

		if ( is_wp_error( $result ) ) {
			$failure_findings = array(
				array(
					'code'           => (string) $result->get_error_code(),
					'severity'       => 'ERROR',
					'message'        => $result->get_error_message(),
					'proposal'       => __( 'Check directory permissions and disk space in the uploads folder.', 'titanworks-bazna-cijena' ),
					'entity_type'    => 'publication',
					'entity_id'      => (int) $location_id,
					'rule_reference' => 'FR-040',
				),
			);

			$this->record_failure( $location_id, $format, $failure_findings, 'The price list could not be published.' );

			return $result;
		}

		if ( ! empty( $all_blockers ) ) {
			Logger::warning(
				'export_warning',
				'Price list generated with compliance findings. Remediation proposed.',
				array(
					'location_id' => (int) $location_id,
					'format'      => $format,
					'filename'    => isset( $result['filename'] ) ? $result['filename'] : '',
					'items'       => count( $items ),
					'findings'    => count( $all_blockers ),
					'proposals'   => count( $proposals ),
				)
			);
		} else {
			Logger::info(
				$event,
				empty( $result['skipped'] ) ? 'Price list published.' : 'Price list unchanged; the current version was kept.',
				array(
					'location_id' => (int) $location_id,
					'format'      => $format,
					'filename'    => isset( $result['filename'] ) ? $result['filename'] : '',
					'items'       => count( $items ),
					'skipped'     => ! empty( $result['skipped'] ),
				)
			);
		}

		return array(
			'location_id' => (int) $location_id,
			'format'      => $format,
			'filename'    => isset( $result['filename'] ) ? $result['filename'] : '',
			'item_count'  => count( $items ),
			'skipped'     => ! empty( $result['skipped'] ),
			'publication' => isset( $result['publication'] ) ? $result['publication'] : null,
			'has_errors'  => ! empty( $all_blockers ),
			'findings'    => $all_blockers,
			'proposals'   => $proposals,
		);
	}

	/**
	 * Option caching the last automatic single-list decision.
	 */
	const OPTION_SINGLE_LIST = 'twbce_cijena_single_list';

	/**
	 * Whether one price list currently covers every sales location.
	 *
	 * @return bool
	 */
	public static function single_list_mode() {
		$scope = (string) Settings::get( 'price_list_scope', 'auto' );

		if ( 'all_locations' === $scope ) {
			return true;
		}

		if ( 'per_location' === $scope ) {
			return false;
		}

		return (bool) get_option( self::OPTION_SINGLE_LIST, true );
	}

	/**
	 * Whether a location is the one that carries the shared public list.
	 *
	 * @param array<mixed> $location Location row.
	 * @return bool
	 */
	protected static function is_public_location( array $location ) {
		$public = \Titanworks\BaznaCijena\Api\PublicFeed::public_location();

		return $public && (int) $public['id'] === (int) $location['id'];
	}

	/**
	 * Decide whether to publish one list for every location.
	 *
	 * In `auto` scope the lists are compared: when every active location would
	 * publish the same rows, one ZA_SVA_PRODAJNA_MJESTA list is published.
	 *
	 * @param array<int,array<mixed>> $locations Active locations.
	 * @param array<mixed>            $args      Generation arguments (with `items`).
	 * @return array<mixed>|null Location that carries the shared list, or null.
	 */
	protected function resolve_single_list( array $locations, array $args ) {
		if ( empty( $locations ) ) {
			return null;
		}

		$scope  = (string) Settings::get( 'price_list_scope', 'auto' );
		$single = 'all_locations' === $scope;

		if ( 'auto' === $scope ) {
			$hashes = array();
			foreach ( $locations as $location ) {
				$build = $this->builder()->build( $location, array_merge( $args, array( 'build' => null ) ) );
				$rows  = array_map(
					static function ( $row ) {
						unset( $row['updated_at'] );

						return $row;
					},
					$build['items']
				);
				$hashes[ hash( 'sha256', (string) wp_json_encode( array( $this->formats( $location ), $rows ) ) ) ] = true;
			}
			$single = 1 === count( $hashes );
		}

		if ( ! $single ) {
			return null;
		}

		$public = \Titanworks\BaznaCijena\Api\PublicFeed::public_location();

		return $public ? $public : $locations[0];
	}

	/**
	 * Formats enabled for a location.
	 *
	 * @param array<mixed> $location Location row.
	 * @return string[]
	 */
	public function formats( array $location ) {
		$settings = (array) Settings::get( 'formats', array( 'csv', 'xml' ) );
		$config   = isset( $location['price_list_config'] ) && is_array( $location['price_list_config'] ) ? $location['price_list_config'] : array();

		if ( ! empty( $config['formats'] ) ) {
			$settings = array_intersect( $settings, (array) $config['formats'] );
		}

		$formats = array_values( array_intersect( array( 'csv', 'xml' ), $settings ) );

		return empty( $formats ) ? array( 'csv', 'xml' ) : $formats;
	}

	/**
	 * Catalog-level findings for a location, split by severity.
	 *
	 * @param int                                                   $location_id Location ID.
	 * @param array<int,CatalogItem>|\Traversable<CatalogItem>|null $items       Optional pre-hydrated catalog items.
	 * @return array{errors:array<mixed>,warnings:int}
	 */
	protected function catalog_report( $location_id, $items = null ) {
		$validator = Plugin::instance()->validator();

		$validate_args = array(
			'scope'       => 'catalog',
			'location_id' => (int) $location_id,
		);

		if ( is_array( $items ) || $items instanceof \Traversable ) {
			$validate_args['items'] = $items;
		}

		$report = $validator->validate( $validate_args );

		$errors   = array();
		$warnings = 0;

		foreach ( $report['findings'] as $finding ) {
			if ( 'ERROR' === $finding->severity ) {
				$errors[] = $finding->to_array();
				continue;
			}

			++$warnings;
		}

		return array(
			'errors'   => $errors,
			'warnings' => $warnings,
		);
	}

	/**
	 * Hydrate catalog items into an array once for reuse.
	 *
	 * @param array<mixed> $args Arguments.
	 * @return array<int,CatalogItem>
	 */
	protected function hydrate_catalog( array $args = array() ) {
		$type = isset( $args['type'] ) ? (string) $args['type'] : 'all';

		/** @var mixed $iter */
		$iter = $this->catalog->iterate(
			array(
				'type'               => $type,
				'include_variations' => true,
			)
		);

		if ( ! is_iterable( $iter ) ) {
			return array();
		}

		$items   = array();
		$release = PriceListBuilder::can_release_runtime_cache();
		$seen    = 0;

		foreach ( $iter as $item ) {
			if ( $item instanceof CatalogItem ) {
				$items[] = $item;
			}

			// The catalog keeps only the small CatalogItem value objects, but every
			// product post, meta row and term it read stays in the runtime object
			// cache (~20 KB per product). Release it in batches between yielded items
			// so peak memory no longer scales with catalog size (PERF-24). Each page is
			// fully built before it is yielded, so the next page re-primes its caches.
			++$seen;
			if ( $release && 0 === $seen % self::RUNTIME_CACHE_RELEASE_EVERY ) {
				wp_cache_flush_runtime();
			}
		}

		return $items;
	}

	/**
	 * Missing retail/anchor evidence and unusable active-promotion references
	 * prevent a cjenik publication. Other findings remain warnings.
	 *
	 * @param array<mixed> $errors Error findings.
	 * @return array<mixed>
	 */
	public static function publication_blockers( array $errors ) {
		$required = array(
			'missing_anchor_price',
			'invalid_anchor_date',
			'invalid_retail_price',
			'missing_sale_type',
			'missing_30_day_price',
			'sale_price_not_below_reference',
		);

		return array_values(
			array_filter(
				$errors,
				static function ( $finding ) use ( $required ) {
					return isset( $finding['code'] ) && in_array( $finding['code'], $required, true );
				}
			)
		);
	}

	/**
	 * Store a failed publication row so the attempt stays auditable.
	 *
	 * @param int          $location_id Location ID.
	 * @param string       $format      Format.
	 * @param array<mixed> $findings    Findings.
	 * @param string       $message     Optional error log message.
	 * @return void
	 */
	protected function record_failure( $location_id, $format, array $findings, $message = '' ) {
		$id = $this->publications->insert(
			array(
				'location_id'        => (int) $location_id,
				'format'             => (string) $format,
				'status'             => 'failed',
				'rule_version'       => (string) \Titanworks\BaznaCijena\Compliance\RuleConfig::get( 'rule_version', '' ),
				'validation_summary' => $findings,
			)
		);

		Logger::error(
			'export_failed',
			'' !== $message ? $message : 'Price-list generation was blocked by validation.',
			array(
				'location_id' => (int) $location_id,
				'format'      => (string) $format,
				'findings'    => count( $findings ),
			)
		);

		/**
		 * Fires when a price-list publication fails.
		 *
		 * @param int          $location_id Location ID.
		 * @param string       $format      Format.
		 * @param array<mixed> $findings    Failure findings.
		 */
		do_action( 'twbce_cijena_publication_failed', $location_id, $format, $findings );
	}

	/**
	 * Row builder.
	 *
	 * @return PriceListBuilder
	 */
	protected function builder() {
		return new PriceListBuilder( $this->catalog, $this->history, $this->sales );
	}

	/**
	 * Publisher.
	 *
	 * @return Publisher
	 */
	protected function publisher() {
		return new Publisher( $this->locations, $this->publications, new FilenameGenerator() );
	}
}
