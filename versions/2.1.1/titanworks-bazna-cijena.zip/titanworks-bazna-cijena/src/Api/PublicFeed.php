<?php
/**
 * Public price-list feed on a stable, human-readable URL.
 *
 * @package Titanworks\BaznaCijena\Api
 */

namespace Titanworks\BaznaCijena\Api;

use Titanworks\BaznaCijena\Cron\Scheduler;
use Titanworks\BaznaCijena\Plugin;
use Titanworks\BaznaCijena\Logging\Logger;

use Titanworks\BaznaCijena\Export\GenerationService;
use Titanworks\BaznaCijena\Export\ListFormat;

defined( 'ABSPATH' ) || exit;

/**
 * Serves the current price list at `/bazna-cijena.xml` and `/bazna-cijena.csv`.
 *
 * The decree expects a price list that can be retrieved at a known address, not
 * only through a JSON endpoint. When the file is missing the response is a 503
 * and exactly one background rebuild is queued, so the visitor is told the list
 * is unavailable instead of receiving a stale or empty document.
 */
class PublicFeed {

	/**
	 * URL stem of the public feed.
	 *
	 * @var string
	 */
	const STEM = 'bazna-cijena';

	/**
	 * Alternate compact URL stem.
	 *
	 * @var string
	 */
	const STEM_COMPACT = 'baznacijena';

	/**
	 * Query var that carries the requested format.
	 *
	 * @var string
	 */
	const QUERY_VAR = 'twbce_cijena_feed';

	/**
	 * Option storing the last queued rebuild timestamp.
	 *
	 * @var string
	 */
	const OPTION_LAST_QUEUE = 'twbce_cijena_public_feed_last_queue';

	/**
	 * Minimum seconds between two queued rebuilds.
	 *
	 * @var int
	 */
	const REBUILD_COOLDOWN = 900;

	/**
	 * Register hooks.
	 *
	 * @return void
	 */
	public function register() {
		// Called from `init` itself: a hook added to the running `init` action would never fire.
		$this->add_rewrites();

		add_filter( 'query_vars', array( $this, 'query_vars' ) );
		add_action( 'parse_request', array( $this, 'parse_request_fallback' ) );
		add_action( 'template_redirect', array( $this, 'serve' ), 0 );
		add_action( 'twbce_cijena_publication_published', array( __CLASS__, 'purge_caches' ) );
	}

	/**
	 * Add the public feed rules.
	 *
	 * @return void
	 */
	public function add_rewrites() {
		add_rewrite_rule(
			'^' . self::STEM . '\.(xml|csv)$',
			'index.php?' . self::QUERY_VAR . '=$matches[1]',
			'top'
		);
		add_rewrite_rule(
			'^' . self::STEM_COMPACT . '\.(xml|csv)$',
			'index.php?' . self::QUERY_VAR . '=$matches[1]',
			'top'
		);
		// Services price list (NN 132/2026-1584 čl. 3. st. 3.).
		add_rewrite_rule(
			'^' . self::STEM . '-usluge\.(xml|csv)$',
			'index.php?' . self::QUERY_VAR . '=$matches[1]_u',
			'top'
		);

		$rules = get_option( 'rewrite_rules' );
		if ( is_array( $rules ) && ! empty( $rules ) && ( ! isset( $rules[ '^' . self::STEM . '\.(xml|csv)$' ] ) || ! isset( $rules[ '^' . self::STEM . '-usluge\.(xml|csv)$' ] ) ) ) {
			flush_rewrite_rules( false );
		}
	}

	/**
	 * Extract normalized path from a URL.
	 *
	 * @param string $url URL or request URI.
	 * @return string
	 */
	protected static function parse_path( $url ) {
		$path = wp_parse_url( (string) $url, PHP_URL_PATH );

		return trim( (string) $path, '/' );
	}

	/**
	 * Fallback route matching when rewrite rules have not been flushed yet.
	 *
	 * @param \WP $wp WordPress environment.
	 * @return void
	 */
	public function parse_request_fallback( $wp ) {
		$request = trim( (string) $wp->request, '/' );
		if ( '' === $request && isset( $_SERVER['REQUEST_URI'] ) ) {
			$raw_uri = esc_url_raw( wp_unslash( $_SERVER['REQUEST_URI'] ) );
			$request = self::parse_path( $raw_uri );
			$home    = self::parse_path( home_url() );
			if ( '' !== $home && 0 === strpos( $request, $home ) ) {
				$request = trim( (string) substr( $request, strlen( $home ) ), '/' );
			}
		}

		$format = self::format_for_path( $request );

		if ( '' !== $format ) {
			$wp->query_vars[ self::QUERY_VAR ] = $format;
			$wp->matched_rule                  = 'twbce_cijena_feed_' . $format;
			unset( $wp->query_vars['error'] );
		}
	}

	/**
	 * Allow the feed query var through WordPress.
	 *
	 * @param string[] $vars Query vars.
	 * @return string[]
	 */
	public function query_vars( $vars ) {
		$vars[] = self::QUERY_VAR;

		return $vars;
	}

	/**
	 * Serve the feed for a public feed request.
	 *
	 * @return void
	 */
	public function serve() {
		$format = (string) get_query_var( self::QUERY_VAR );

		if ( ! ListFormat::is_valid( $format ) ) {
			$raw_uri = isset( $_SERVER['REQUEST_URI'] ) ? esc_url_raw( wp_unslash( $_SERVER['REQUEST_URI'] ) ) : '';
			$request = '' !== $raw_uri ? self::parse_path( $raw_uri ) : '';
			$home    = self::parse_path( home_url() );
			if ( '' !== $home && 0 === strpos( $request, $home ) ) {
				$request = trim( (string) substr( $request, strlen( $home ) ), '/' );
			}

			$format = self::format_for_path( $request );

			if ( '' === $format ) {
				return;
			}
		}

		global $wp_query;
		if ( $wp_query instanceof \WP_Query ) {
			$wp_query->is_404 = false;
		}

		$location = self::requested_location();

		// An unknown `?mjesto=` code, or a services list on a shop that
		// currently publishes none, can never be produced by a rebuild: answer
		// 404 instead of an endless 503 that queues pointless rebuilds.
		if ( ! $location ) {
			$this->serve_not_found();

			return;
		}

		$row = $this->current_file( (int) $location['id'], $format );

		if ( ! $row && ListFormat::SERVICES === ListFormat::list_type( $format ) ) {
			$this->serve_not_found();

			return;
		}

		if ( $row && $this->is_valid_published_file( $row ) ) {
			$this->send_file( $row, ListFormat::extension( $format ) );

			return;
		}

		$this->serve_missing();
	}

	/**
	 * Answer a feed request that maps to no list at all.
	 *
	 * @return void
	 */
	protected function serve_not_found() {
		self::disable_page_cache();

		status_header( 404 );
		nocache_headers();
		header( 'Content-Type: text/plain; charset=utf-8' );

		echo esc_html__( 'No price list is published at this address.', 'titanworks-bazna-cijena' ) . "\n";
		exit;
	}

	/**
	 * Verify that a published file exists, is readable, non-empty, and matches its recorded checksum.
	 *
	 * Corrupt or truncated files are rejected so the visitor or ministry receives
	 * a 503 while a clean file is regenerated, rather than malformed data.
	 *
	 * @param array<mixed> $row Publication row.
	 * @return bool
	 */
	public function is_valid_published_file( array $row ) {
		if ( empty( $row['path'] ) || ! is_string( $row['path'] ) || ! is_readable( $row['path'] ) ) {
			return false;
		}

		$size = filesize( $row['path'] );
		if ( false === $size || $size <= 0 ) {
			Logger::warning(
				'public_feed_corrupt_file',
				'The published price list file is empty or unreadable.',
				array( 'path' => $row['path'] )
			);

			return false;
		}

		if ( ! empty( $row['checksum'] ) && is_string( $row['checksum'] ) ) {
			$actual = hash_file( 'sha256', $row['path'] );
			if ( false === $actual || ! hash_equals( (string) $row['checksum'], $actual ) ) {
				Logger::warning(
					'public_feed_checksum_mismatch',
					'The published price list file checksum did not match the recorded publication evidence.',
					array(
						'path'              => $row['path'],
						'recorded_checksum' => $row['checksum'],
						'actual_checksum'   => $actual,
					)
				);

				return false;
			}
		}

		return true;
	}

	/**
	 * Publication format code for a request path, or an empty string.
	 *
	 * @param string $request Request path relative to the home URL.
	 * @return string
	 */
	public static function format_for_path( $request ) {
		$request = strtolower( trim( (string) $request, '/' ) );

		if ( ! preg_match( '/^(?:' . preg_quote( self::STEM, '/' ) . '|' . preg_quote( self::STEM_COMPACT, '/' ) . ')(-usluge)?\.(xml|csv)$/', $request, $matches ) ) {
			return '';
		}

		return ListFormat::code( $matches[2], '' !== $matches[1] ? ListFormat::SERVICES : ListFormat::GOODS );
	}

	/**
	 * Location requested through `?mjesto=<oznaka>`, else the public location.
	 *
	 * When one list covers every sales location (NN 132/2026-1584 čl. 6. st. 4.)
	 * it is stored under the public location, so the parameter is ignored.
	 *
	 * @return array<mixed>|null
	 */
	public static function requested_location() {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Public, read-only feed.
		$wanted = isset( $_GET['mjesto'] ) ? sanitize_text_field( wp_unslash( $_GET['mjesto'] ) ) : '';

		if ( '' !== $wanted && ! GenerationService::single_list_mode() ) {
			foreach ( Plugin::instance()->locations()->all( true ) as $location ) {
				if ( 0 === strcasecmp( (string) $location['identifier'], $wanted ) ) {
					return $location;
				}
			}

			return null;
		}

		return self::public_location();
	}

	/**
	 * The location whose price list is published at the public URLs.
	 *
	 * The webshop location represents the online store; a shop without one
	 * falls back to its first active location. Shared by the public feed and
	 * the public HTML pages so they can never point at different shops.
	 *
	 * @return array<mixed>|null
	 */
	public static function public_location() {
		$locations = Plugin::instance()->locations()->all( true );

		foreach ( $locations as $location ) {
			if ( 'webshop' === $location['type'] ) {
				return $location;
			}
		}

		return $locations ? $locations[0] : null;
	}

	/**
	 * The currently published file for a location and format.
	 *
	 * @param int    $location_id Location ID.
	 * @param string $format      `xml` or `csv`.
	 * @return array<mixed>|null
	 */
	protected function current_file( $location_id, $format ) {
		$row = Plugin::instance()->publications()->latest( $location_id, $format, array( 'published' ) );

		if ( ! $row || empty( $row['path'] ) ) {
			return null;
		}

		return $row;
	}

	/**
	 * Stream the published file.
	 *
	 * @param array<mixed> $row    Publication row.
	 * @param string       $format `xml` or `csv`.
	 * @return void
	 */
	protected function send_file( array $row, $format ) {
		self::disable_page_cache();
		nocache_headers();
		header( 'Content-Type: ' . ( 'xml' === $format ? 'application/xml' : 'text/csv' ) . '; charset=utf-8' );
		header( 'Content-Disposition: attachment; filename="' . $row['filename'] . '"' );
		header( 'Content-Length: ' . (int) filesize( $row['path'] ) );
		header( 'X-Bazna-Cijena-Checksum: ' . $row['checksum'] );

		// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_readfile -- Streaming the generated price list.
		readfile( $row['path'] );
		exit;
	}

	/**
	 * Report a missing price list and queue one rebuild.
	 *
	 * @return void
	 */
	protected function serve_missing() {
		$this->queue_rebuild();
		self::disable_page_cache();

		status_header( 503 );
		nocache_headers();
		header( 'Content-Type: text/plain; charset=utf-8' );
		header( 'Retry-After: ' . self::REBUILD_COOLDOWN );

		echo esc_html__( 'The price list is being regenerated. Please try again shortly.', 'titanworks-bazna-cijena' ) . "\n";
		exit;
	}

	/**
	 * Queue a rebuild, at most once per cooldown window.
	 *
	 * @return void
	 */
	protected function queue_rebuild() {
		$last = (int) get_option( self::OPTION_LAST_QUEUE, 0 );

		if ( $last && ( time() - $last ) < self::REBUILD_COOLDOWN ) {
			return;
		}

		update_option( self::OPTION_LAST_QUEUE, time(), false );
		Scheduler::queue_service_regeneration( array(), 60 );

		Logger::info(
			'public_feed_rebuild_queued',
			'A public price-list request found no published file; a rebuild was queued.',
			array( 'cooldown' => self::REBUILD_COOLDOWN )
		);
	}

	/**
	 * Keep page caches from storing the statutory feed.
	 *
	 * The nocache_headers() call alone does not stop LiteSpeed Cache, which sets its own
	 * `X-LiteSpeed-Cache-Control: public` and would serve a stale list for days.
	 *
	 * @return void
	 */
	public static function disable_page_cache() {
		if ( ! defined( 'DONOTCACHEPAGE' ) ) {
			// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedConstantFound -- Cross-plugin page-cache convention honoured by WP Rocket, W3TC and others.
			define( 'DONOTCACHEPAGE', true );
		}

		// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- LiteSpeed's documented integration hook.
		do_action( 'litespeed_control_set_nocache', 'bazna-cijena price list feed' );

		if ( ! headers_sent() ) {
			header( 'X-LiteSpeed-Cache-Control: no-cache' );
			header( 'CDN-Cache-Control: no-store' );
			header( 'Cloudflare-CDN-Cache-Control: no-store' );
		}
	}

	/**
	 * Purge page caches for the public price-list URLs after a publication.
	 *
	 * @return void
	 */
	public static function purge_caches() {
		$paths = array(
			'/' . self::STEM . '.csv',
			'/' . self::STEM . '.xml',
			'/' . self::STEM . '-usluge.csv',
			'/' . self::STEM . '-usluge.xml',
			'/' . self::STEM_COMPACT . '.csv',
			'/' . self::STEM_COMPACT . '.xml',
			'/' . PublicPage::STEM_ARCHIVE . '/',
			'/' . PublicPage::STEM_LIST . '/',
		);

		foreach ( $paths as $path ) {
			$url = home_url( $path );
			// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- LiteSpeed Cache exposes this third-party purge hook.
			do_action( 'litespeed_purge_url', $url );
			if ( function_exists( 'rocket_clean_files' ) ) {
				rocket_clean_files( array( $url ) );
			}
		}

		do_action( 'twbce_cijena_purge_public_urls', array_map( 'home_url', $paths ) );
	}
}
