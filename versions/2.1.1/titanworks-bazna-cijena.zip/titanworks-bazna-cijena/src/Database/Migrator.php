<?php
/**
 * Versioned schema migrations.
 *
 * @package Titanworks\BaznaCijena\Database
 */

namespace Titanworks\BaznaCijena\Database;

use Titanworks\BaznaCijena\Compliance\RuleConfig;
use Titanworks\BaznaCijena\Support\IdentifierMigration;
use Titanworks\BaznaCijena\Support\Install;
use Titanworks\BaznaCijena\Support\Settings;

defined( 'ABSPATH' ) || exit;

/**
 * Runs dbDelta() migrations when the stored schema version is behind.
 */
final class Migrator {

	/**
	 * Option holding the installed schema version.
	 */
	const OPTION = 'twbce_cijena_db_version';

	/**
	 * Run the upgrade check on admin requests.
	 *
	 * @return void
	 */
	public static function maybe_upgrade() {
		if ( self::installed_version() !== Schema::DB_VERSION || false === get_option( Settings::OPTION, false ) ) {
			self::migrate();
		}
	}

	/**
	 * Installed schema version.
	 *
	 * @return string
	 */
	public static function installed_version() {
		return (string) get_option( self::OPTION, '' );
	}

	/**
	 * Run migrations up to the current schema version.
	 *
	 * @return string The version now installed.
	 */
	public static function migrate() {
		$from = self::installed_version();
		$to   = Schema::DB_VERSION;

		if ( $from === $to && false !== get_option( Settings::OPTION, false ) ) {
			return $to;
		}

		// Never create or seed new tables while legacy tables still wait to be
		// renamed: a seeded empty copy would hide the legacy rows for good.
		if ( ! IdentifierMigration::rename_tables() ) {
			return $from;
		}

		Schema::create_tables();
		Install::seed_options();

		if ( '' !== $from && version_compare( $from, '1.3.0', '<' ) ) {
			self::upgrade_to_nn_132_2026();
		}

		$locations = new LocationRepository();
		$locations->ensure_default_webshop();

		update_option( self::OPTION, $to, false );

		if ( function_exists( 'flush_rewrite_rules' ) ) {
			flush_rewrite_rules( false );
		}

		/**
		 * Fires after the schema has been migrated.
		 *
		 * @param string $from Previous version.
		 * @param string $to   New version.
		 */
		do_action( 'twbce_cijena_migrated', $from, $to );

		return $to;
	}

	/**
	 * Move stored settings off the repealed Odluke onto NN 132/2026 (1583, 1584).
	 *
	 * Only values that still equal a former plugin default are replaced, so a
	 * merchant's own choices survive. Retention above the new 15-day minimum and
	 * deadlines earlier than 11:00 are kept as they are.
	 *
	 * @return void
	 */
	public static function upgrade_to_nn_132_2026() {
		$settings = get_option( Settings::OPTION, array() );

		if ( is_array( $settings ) ) {
			if ( isset( $settings['anchor_label'] ) && in_array( trim( (string) $settings['anchor_label'] ), Settings::LEGACY_LABELS, true ) ) {
				$settings['anchor_label'] = 'Bazna cijena';
			}

			if ( isset( $settings['anchor_tooltip_text'] ) && Settings::LEGACY_TOOLTIP === trim( (string) $settings['anchor_tooltip_text'] ) ) {
				$settings['anchor_tooltip_text'] = Settings::DEFAULT_TOOLTIP;
			}

			if ( isset( $settings['deadline'] ) && strcmp( (string) $settings['deadline'], Settings::LEGAL_DEADLINE ) > 0 ) {
				$settings['deadline'] = Settings::LEGAL_DEADLINE;
			}

			update_option( Settings::OPTION, $settings );
			Settings::reset_cache();
		}

		$rules = get_option( RuleConfig::OPTION, array() );

		if ( is_array( $rules ) && isset( $rules['rule_version'] ) && '2026-10-01' === $rules['rule_version'] ) {
			$rules['rule_version'] = RuleConfig::DEFAULT_RULE_VERSION;
			update_option( RuleConfig::OPTION, $rules );
		}
	}
}
