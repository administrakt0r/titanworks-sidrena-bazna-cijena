<?php
/**
 * Restore storefront visibility after upgrades from opt-in display builds.
 *
 * @package Titanworks\SidrenaCijena\Support
 */

namespace Titanworks\SidrenaCijena\Support;

defined( 'ABSPATH' ) || exit;

/**
 * Applies the requested visible-by-default policy once, preserving later choices.
 */
final class StorefrontDefaults {

	/** Upgrade marker. */
	const OPTION = 'twbce_cijena_storefront_defaults_restored';

	/**
	 * Restore public cards and archive links without changing price evidence.
	 *
	 * @return void
	 */
	public static function restore_once() {
		if ( get_option( self::OPTION, false ) ) {
			// Preserve subsequent merchant choices once the one-time restore has run.
			return;
		}

		Settings::update(
			array(
				'display_archives'       => true,
				'card_display_default'   => true,
				'public_archive_enabled' => true,
				'archive_footer_link'    => true,
			)
		);
		// Older opt-in controls saved zero on ordinary product updates. Start
		// those products on the global default; future explicit opt-outs persist.
		delete_metadata( 'post', 0, '_twbce_cijena_show_in_cards', '0', true );
		update_option( self::OPTION, 1, false );
		// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- LiteSpeed Cache exposes this third-party purge hook.
		do_action( 'litespeed_purge_all' );
	}
}
