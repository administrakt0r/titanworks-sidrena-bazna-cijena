<?php
/**
 * `wp bazna-cijena integrity` command.
 *
 * @package Titanworks\BaznaCijena\Cli
 */

namespace Titanworks\BaznaCijena\Cli;

use Titanworks\BaznaCijena\Plugin;
use Titanworks\BaznaCijena\Pricing\AnchorIntegrity;

defined( 'ABSPATH' ) || exit;

/**
 * Lists published items without a base price and base prices dated before the
 * item was first offered, and optionally repairs both (append-only).
 *
 * Options: --fix-missing, --fix-dates --reason=<text>, --dry-run, --format=table|json.
 * Exit codes: 0 clean, 1 gaps remain, 2 failure, 3 bad arguments.
 */
final class IntegrityCommand {

	/**
	 * WP-CLI entry point.
	 *
	 * @param array<mixed> $args       Positional arguments.
	 * @param array<mixed> $assoc_args Named arguments.
	 * @return void
	 */
	public static function run( $args, $assoc_args ) {
		// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Exit code, not output.
		exit( self::execute( (array) $args, (array) $assoc_args ) );
	}

	/**
	 * Run the check.
	 *
	 * @param array<mixed> $args       Positional arguments.
	 * @param array<mixed> $assoc_args Named arguments.
	 * @return int Exit code.
	 */
	public static function execute( $args = array(), $assoc_args = array() ) {
		unset( $args );

		try {
			$plugin    = Plugin::instance();
			$integrity = new AnchorIntegrity( $plugin->catalog(), $plugin->history(), $plugin->anchors() );
			$dry_run   = ! empty( $assoc_args['dry-run'] );

			if ( ! empty( $assoc_args['fix-dates'] ) ) {
				$result = $integrity->correct_dates( isset( $assoc_args['reason'] ) ? (string) $assoc_args['reason'] : '', $dry_run );

				if ( is_wp_error( $result ) ) {
					Cli::out( $result->get_error_message() . ' (--reason="...")', 'error' );

					return 3;
				}

				Cli::out( sprintf( '%s %d base-price date(s); prices unchanged.', $dry_run ? 'Would correct' : 'Corrected', $dry_run ? count( $result['rows'] ) : $result['corrected'] ) );

				if ( ! empty( $result['failed'] ) ) {
					Cli::out( sprintf( '%d date correction(s) could not be saved.', $result['failed'] ), 'error' );

					return 2;
				}
			}

			if ( ! empty( $assoc_args['fix-missing'] ) ) {
				$result = $integrity->fix_missing( $dry_run );
				Cli::out( sprintf( '%s %d missing base price(s) from the first-offer date; %d need manual entry.', $dry_run ? 'Would record' : 'Recorded', $dry_run ? count( $result['rows'] ) : $result['recorded'], $result['skipped'] ) );

				if ( ! empty( $result['failed'] ) ) {
					Cli::out( sprintf( '%d base price(s) could not be saved.', $result['failed'] ), 'error' );

					return 2;
				}
			}

			$scan = $integrity->scan();

			if ( isset( $assoc_args['format'] ) && 'json' === $assoc_args['format'] ) {
				Cli::out( Cli::as_json( $scan ), 'line' );
			} else {
				Cli::out( sprintf( 'Checked %d published item(s): %d without a base price, %d dated before their first offer.', $scan['checked'], count( $scan['missing'] ), count( $scan['dates'] ) ) );

				foreach ( $scan['missing'] as $row ) {
					Cli::out( sprintf( '[missing] #%d/%d %s (first offered %s) %s', $row['product_id'], $row['variation_id'], $row['name'], '' === $row['first_seen'] ? '?' : $row['first_seen'], $row['fixable'] ? '-> fixable: ' . $row['date'] . ' @ ' . $row['price'] : '-> enter manually' ) );
				}

				foreach ( $scan['dates'] as $row ) {
					Cli::out( sprintf( '[date] #%d/%d %s: %s -> %s', $row['product_id'], $row['variation_id'], $row['name'], $row['anchor_date'], $row['date'] ) );
				}
			}

			return ( $scan['missing'] || $scan['dates'] ) ? 1 : 0;
		} catch ( \Throwable $exception ) {
			Cli::out( 'Integrity check failed: ' . $exception->getMessage(), 'error' );

			return 2;
		}
	}
}
