<?php
/**
 * Public HTML price list and archive pages.
 *
 * @package Titanworks\BaznaCijena\Api
 */

namespace Titanworks\BaznaCijena\Api;

use Titanworks\BaznaCijena\Export\PriceListBuilder;
use Titanworks\BaznaCijena\Plugin;
use Titanworks\BaznaCijena\Support\Currency;
use Titanworks\BaznaCijena\Support\Dates;
use Titanworks\BaznaCijena\Support\Settings;

use Titanworks\BaznaCijena\Export\GenerationService;
use Titanworks\BaznaCijena\Export\ListFormat;

defined( 'ABSPATH' ) || exit;

/**
 * Serves a human-readable price list at `/bazna-cijena-cjenik` and the publication
 * archive at `/arhiva-bazne-cijene`, and provides the same tables through the
 * `[twbce_cjenik]` and `[twbce_arhiva]` shortcodes.
 *
 * The decree expects a price list a person can open, not only a machine
 * endpoint; the rows are the same canonical rows the CSV/XML exports use, so a
 * printed page cannot disagree with the published file.
 */
class PublicPage {

	/**
	 * Query var carrying the requested page.
	 *
	 * @var string
	 */
	const QUERY_VAR = 'twbce_cijena_page';

	/**
	 * Value of the price-list page.
	 *
	 * @var string
	 */
	const PAGE_LIST = 'cjenik';

	/**
	 * Value of the archive page.
	 *
	 * @var string
	 */
	const PAGE_ARCHIVE = 'arhiva';

	/**
	 * URL stem of the price-list page.
	 *
	 * @var string
	 */
	const STEM_LIST = 'bazna-cijena-cjenik';

	/**
	 * Alternate compact URL stem for the price list.
	 *
	 * @var string
	 */
	const STEM_LIST_COMPACT = 'baznacijena';

	/**
	 * URL stem of the archive page.
	 *
	 * @var string
	 */
	const STEM_ARCHIVE = 'arhiva-bazne-cijene';

	/**
	 * Maximum publications shown in the archive.
	 *
	 * @var int
	 */
	const ARCHIVE_LIMIT = 50;

	/**
	 * Maximum items per page on the public price list.
	 *
	 * @var int
	 */
	const LIST_PER_PAGE = 50;

	/**
	 * Whether the table styles were already printed on this request.
	 *
	 * @var bool
	 */
	protected static $styled = false;

	/**
	 * Register hooks.
	 *
	 * @return void
	 */
	public function register() {
		// Called from `init` itself: a hook added to the running `init` action would never fire.
		$this->add_rewrites();

		add_filter( 'query_vars', array( $this, 'query_vars' ) );
		add_action( 'parse_request', array( $this, 'parse_request_fallback' ) );
		add_action( 'template_redirect', array( $this, 'serve' ), 0 );
		add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_assets' ) );
		add_action( 'wp_footer', array( $this, 'footer_link' ) );
		add_filter( 'render_block_core/template-part', array( $this, 'footer_block' ), 20, 2 );
		add_action( 'wp_sitemaps_init', array( $this, 'register_sitemap_provider' ) );

		add_shortcode( 'twbce_cjenik', array( $this, 'shortcode_list' ) );
		add_shortcode( 'twbce_arhiva', array( $this, 'shortcode_archive' ) );
	}

	/**
	 * Add the public page rules.
	 *
	 * @return void
	 */
	public function add_rewrites() {
		add_rewrite_rule(
			'^' . self::STEM_LIST . '/?$',
			'index.php?' . self::QUERY_VAR . '=' . self::PAGE_LIST,
			'top'
		);

		add_rewrite_rule(
			'^' . self::STEM_LIST_COMPACT . '/?$',
			'index.php?' . self::QUERY_VAR . '=' . self::PAGE_LIST,
			'top'
		);

		add_rewrite_rule(
			'^' . self::STEM_ARCHIVE . '/?$',
			'index.php?' . self::QUERY_VAR . '=' . self::PAGE_ARCHIVE,
			'top'
		);

		// Self-heal: ensure rules are flushed if missing from the active rules.
		$rules = get_option( 'rewrite_rules' );
		if ( is_array( $rules ) && ! empty( $rules ) && ! isset( $rules[ '^' . self::STEM_ARCHIVE . '/?$' ] ) ) {
			flush_rewrite_rules( false );
		}
	}

	/**
	 * Extract normalized path from a URL.
	 *
	 * @param string $url URL or request URI.
	 * @return string
	 */
	protected static function parse_path( $url ) {
		$path = wp_parse_url( (string) $url, PHP_URL_PATH );

		return trim( (string) $path, '/' );
	}

	/**
	 * Fallback route matching when rewrite rules have not been flushed yet.
	 *
	 * @param \WP $wp WordPress environment.
	 * @return void
	 */
	public function parse_request_fallback( $wp ) {
		$request = trim( (string) $wp->request, '/' );
		if ( '' === $request && isset( $_SERVER['REQUEST_URI'] ) ) {
			$raw_uri = esc_url_raw( wp_unslash( $_SERVER['REQUEST_URI'] ) );
			$request = self::parse_path( $raw_uri );
			$home    = self::parse_path( home_url() );
			if ( '' !== $home && 0 === strpos( $request, $home ) ) {
				$request = trim( (string) substr( $request, strlen( $home ) ), '/' );
			}
		}

		if ( self::STEM_ARCHIVE === $request ) {
			$wp->query_vars[ self::QUERY_VAR ] = self::PAGE_ARCHIVE;
			$wp->matched_rule                  = 'twbce_cijena_archive';
			unset( $wp->query_vars['error'] );
		} elseif ( self::STEM_LIST === $request || self::STEM_LIST_COMPACT === $request || 'bazna-cijena' === $request ) {
			$wp->query_vars[ self::QUERY_VAR ] = self::PAGE_LIST;
			$wp->matched_rule                  = 'twbce_cijena_cjenik';
			unset( $wp->query_vars['error'] );
		}
	}

	/**
	 * Allow the page query var through WordPress.
	 *
	 * @param string[] $vars Query vars.
	 * @return string[]
	 */
	public function query_vars( $vars ) {
		$vars[] = self::QUERY_VAR;

		return $vars;
	}

	/**
	 * Serve a public page request.
	 *
	 * @return void
	 */
	public function serve() {
		$page = (string) get_query_var( self::QUERY_VAR );

		if ( ! in_array( $page, array( self::PAGE_LIST, self::PAGE_ARCHIVE ), true ) ) {
			$raw_uri = isset( $_SERVER['REQUEST_URI'] ) ? esc_url_raw( wp_unslash( $_SERVER['REQUEST_URI'] ) ) : '';
			$request = '' !== $raw_uri ? self::parse_path( $raw_uri ) : '';
			$home    = self::parse_path( home_url() );
			if ( '' !== $home && 0 === strpos( $request, $home ) ) {
				$request = trim( (string) substr( $request, strlen( $home ) ), '/' );
			}

			if ( self::STEM_ARCHIVE === $request ) {
				$page = self::PAGE_ARCHIVE;
			} elseif ( self::STEM_LIST === $request || self::STEM_LIST_COMPACT === $request || 'bazna-cijena' === $request ) {
				$page = self::PAGE_LIST;
			} else {
				return;
			}
		}

		global $wp_query;

		if ( self::PAGE_ARCHIVE === $page && ! Settings::get( 'public_archive_enabled', true ) ) {
			if ( $wp_query instanceof \WP_Query ) {
				$wp_query->set_404();
			}
			status_header( 404 );
			return;
		}

		if ( $wp_query instanceof \WP_Query ) {
			$wp_query->is_404 = false;
		}

		status_header( 200 );
		nocache_headers();
		// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- LiteSpeed's documented integration hook.
		do_action( 'litespeed_control_set_nocache', 'bazna-cijena-public' );

		self::ensure_croatian_catalog();

		$title = self::page_title( $page );
		add_filter(
			'pre_get_document_title',
			static function () use ( $title ) {
				return $title . ' – ' . get_bloginfo( 'name', 'display' );
			},
			99
		);

		get_header();

		echo '<div class="bazna-cijena-page"><h1 class="bazna-cijena-page__title">' . esc_html( $title ) . '</h1>';
		// The templates escape every value they print.
		echo wp_kses( $this->render( $page, $this->request_args() ), self::allowed_html() );
		echo '</div>';

		get_footer();

		exit;
	}

	/**
	 * Heading and document title of a public page.
	 *
	 * @param string $page Page key.
	 * @return string
	 */
	public static function page_title( $page ) {
		return self::PAGE_ARCHIVE === $page
			? __( 'Archive of published price lists', 'titanworks-bazna-cijena' )
			: __( 'Price list with the base price', 'titanworks-bazna-cijena' );
	}

	/**
	 * HTML permitted in the public catalog, including its GET filter controls.
	 *
	 * @return array<string,array<string,bool>>
	 */
	public static function allowed_html() {
		$allowed = wp_kses_allowed_html( 'post' );

		$allowed['form']              = array(
			'method' => true,
			'class'  => true,
		);
		$allowed['label']             = array(
			'for'   => true,
			'class' => true,
		);
		$allowed['input']             = array(
			'type'         => true,
			'id'           => true,
			'name'         => true,
			'value'        => true,
			'placeholder'  => true,
			'autocomplete' => true,
			'class'        => true,
		);
		$allowed['select']            = array(
			'name'  => true,
			'id'    => true,
			'class' => true,
		);
		$allowed['option']            = array(
			'value'    => true,
			'selected' => true,
		);
		$allowed['button']            = array(
			'type'  => true,
			'class' => true,
		);
		$allowed['p']['aria-live']    = true;
		$allowed['div']['role']       = true;
		$allowed['div']['tabindex']   = true;
		$allowed['div']['aria-label'] = true;
		return $allowed;
	}

	/**
	 * Show a link to the archive in the active theme footer.
	 *
	 * @return void
	 */
	public function footer_link() {
		if ( ! Settings::get( 'public_archive_enabled', true ) || ! Settings::get( 'archive_footer_link', true ) ) {
			return;
		}

		wp_enqueue_style(
			'bazna-cijena-frontend',
			TWBCE_CIJENA_URL . 'assets/css/frontend.css',
			array(),
			TWBCE_CIJENA_VERSION
		);

		$text = (string) apply_filters( 'twbce_cijena_footer_link_text', __( 'Cjenici', 'titanworks-bazna-cijena' ) );

		printf(
			'<p class="bazna-cijena-archive-link"><a href="%1$s">%2$s</a></p>',
			esc_url( home_url( '/' . self::STEM_ARCHIVE . '/' ) ),
			esc_html( $text )
		);
	}

	/**
	 * Place the link inside block-theme footers, retaining wp_footer as fallback.
	 *
	 * @param string $content Rendered template part.
	 * @param array  $block Parsed block.
	 * @return string
	 */
	public function footer_block( $content, $block ) {
		$area = isset( $block['attrs']['area'] ) ? (string) $block['attrs']['area'] : '';
		$slug = isset( $block['attrs']['slug'] ) ? (string) $block['attrs']['slug'] : '';
		if ( 'footer' !== $area && 'footer' !== $slug && false === stripos( $slug, 'footer' ) ) {
			return $content;
		}
		ob_start();
		$this->footer_link();
		$link = (string) ob_get_clean();
		if ( '' !== $link ) {
			remove_action( 'wp_footer', array( $this, 'footer_link' ) );
		}
		$closing_footer = strripos( $content, '</footer>' );
		if ( false !== $closing_footer ) {
			return substr( $content, 0, $closing_footer ) . $link . substr( $content, $closing_footer );
		}
		return $content . $link;
	}

	/**
	 * Enqueue stylesheet on the frontend.
	 *
	 * @return void
	 */
	public function enqueue_assets() {
		$page    = (string) get_query_var( self::QUERY_VAR );
		$is_page = in_array( $page, array( self::PAGE_LIST, self::PAGE_ARCHIVE ), true );

		if ( ! $is_page ) {
			$raw_uri = isset( $_SERVER['REQUEST_URI'] ) ? esc_url_raw( wp_unslash( $_SERVER['REQUEST_URI'] ) ) : '';
			$request = '' !== $raw_uri ? self::parse_path( $raw_uri ) : '';
			$home    = self::parse_path( home_url() );
			if ( '' !== $home && 0 === strpos( $request, $home ) ) {
				$request = trim( (string) substr( $request, strlen( $home ) ), '/' );
			}

			if ( self::STEM_ARCHIVE === $request || self::STEM_LIST === $request ) {
				$is_page = true;
			}
		}

		if ( ! $is_page && function_exists( 'is_singular' ) && is_singular() ) {
			global $post;
			if ( is_object( $post ) && isset( $post->post_content ) && ( false !== strpos( (string) $post->post_content, 'bazna-cijena-cjenik' ) || false !== strpos( (string) $post->post_content, 'bazna-cijena-arhiva' ) ) ) {
				$is_page = true;
			}
		}

		if ( ! $is_page && ! ( Settings::get( 'public_archive_enabled', true ) && Settings::get( 'archive_footer_link', true ) ) ) {
			return;
		}

		wp_enqueue_style(
			'bazna-cijena-frontend',
			TWBCE_CIJENA_URL . 'assets/css/frontend.css',
			array(),
			TWBCE_CIJENA_VERSION
		);
	}

	/**
	 * Register the archive URL in the WordPress sitemap.
	 *
	 * @param \WP_Sitemaps $sitemaps Sitemap registry.
	 * @return void
	 */
	public function register_sitemap_provider( $sitemaps ) {
		if ( ! Settings::get( 'public_archive_enabled', true ) || ! Settings::get( 'archive_sitemap_link', true ) || ! class_exists( '\WP_Sitemaps_Provider' ) ) {
			return;
		}

		$sitemaps->registry->add_provider( 'bazna-cijena', new PublicArchiveSitemapProvider() );
	}

	/**
	 * Render a public page as HTML.
	 *
	 * @param string       $page Page identifier.
	 * @param array<mixed> $args Arguments.
	 * @return string
	 */
	public function render( $page, array $args = array() ) {
		if ( self::PAGE_ARCHIVE === $page ) {
			return $this->render_archive( $args );
		}

		return $this->render_list( $args );
	}

	/**
	 * Render the price list table.
	 *
	 * @param array<mixed> $args `q`, `type`, `paged`.
	 * @return string
	 */
	public function render_list( array $args = array() ) {
		self::ensure_croatian_catalog();

		$query = isset( $args['q'] ) ? trim( (string) $args['q'] ) : '';
		$type  = isset( $args['type'] ) ? (string) $args['type'] : '';
		$paged = isset( $args['paged'] ) ? max( 1, (int) $args['paged'] ) : 1;

		if ( ! in_array( $type, array( 'proizvod', 'usluga' ), true ) ) {
			$type = '';
		}

		$location = PublicFeed::public_location();

		$rows = array();
		$meta = array();

		if ( $location ) {
			// Cache the canonical row set once per location per generation.
			// Filtering by query, type and pagination is done in PHP per request,
			// preventing cache fragmentation and avoiding redundant catalog walks.
			$cache     = Plugin::instance()->rest_cache();
			$build_key = $cache->key(
				array(
					'build'    => 'public_list',
					'location' => (int) $location['id'],
					'v'        => TWBCE_CIJENA_VERSION,
				)
			);
			$cached    = $cache->get( $build_key );

			if ( is_array( $cached ) && isset( $cached['items'], $cached['meta'] ) ) {
				$build = $cached;
			} else {
				$builder = new PriceListBuilder(
					Plugin::instance()->catalog(),
					Plugin::instance()->history(),
					Plugin::instance()->special_sales()
				);

				$build = $builder->build( $location );
				$cache->set( $build_key, $build );
			}

			$rows = $build['items'];
			$meta = $build['meta'];
		}

		// Goods and services are separate statutory lists with different
		// columns (NN 132/2026-1584), so they are shown in separate tables.
		$filtered = array();
		$services = array();

		foreach ( $rows as $row ) {
			if ( '' !== $type && $type !== $row['vrsta'] ) {
				continue;
			}

			if ( '' !== $query && ! $this->matches( $row, $query ) ) {
				continue;
			}

			if ( 'usluga' === $row['vrsta'] ) {
				$services[] = $row;
			} else {
				$filtered[] = $row;
			}
		}

		$total_items = count( $filtered );
		$per_page    = self::LIST_PER_PAGE;
		$total_pages = max( 1, (int) ceil( $total_items / $per_page ) );
		$paged       = min( $paged, $total_pages );
		$offset      = ( $paged - 1 ) * $per_page;
		$page_rows   = array_map( array( $this, 'display_row' ), array_slice( $filtered, $offset, $per_page ) );

		$html = $this->partial(
			'public-price-list.php',
			array(
				'rows'          => $page_rows,
				// Services are few: listed in full on the first page only.
				'service_rows'  => 1 === $paged ? array_map( array( $this, 'display_row' ), $services ) : array(),
				'meta'          => $meta,
				'location'      => $location,
				'q'             => $query,
				'type'          => $type,
				'paged'         => $paged,
				'per_page'      => $per_page,
				'total_items'   => $total_items,
				'total_pages'   => $total_pages,
				'feed_xml'      => home_url( '/' . PublicFeed::STEM . '.xml' ),
				'feed_csv'      => home_url( '/' . PublicFeed::STEM . '.csv' ),
				'feed_services' => self::services_feeds( $location ),
				'archive_url'   => home_url( '/' . self::STEM_ARCHIVE . '/' ),
			)
		);

		return $this->style() . $html;
	}

	/**
	 * Render the publication archive table.
	 *
	 * @param array<mixed> $args Optional. Arguments including `paged`.
	 * @return string
	 */
	public function render_archive( array $args = array() ) {
		self::ensure_croatian_catalog();

		$paged = isset( $args['paged'] ) ? max( 1, (int) $args['paged'] ) : 1;
		if ( 1 === $paged && isset( $_GET['paged'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only public pagination.
			$paged = max( 1, absint( wp_unslash( $_GET['paged'] ) ) ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only public pagination.
		}

		$location = PublicFeed::public_location();

		$cache     = Plugin::instance()->rest_cache();
		$cache_key = $cache->key(
			array(
				'page'     => 'public_archive',
				'location' => $location ? (int) $location['id'] : 0,
				'paged'    => $paged,
				'v'        => TWBCE_CIJENA_VERSION,
			)
		);

		$cached = $cache->get( $cache_key );
		if ( is_string( $cached ) && '' !== $cached ) {
			return $cached;
		}

		$items    = array();
		$total    = 0;
		$per_page = self::ARCHIVE_LIMIT;

		if ( $location ) {
			// Separate per-location lists (NN 132/2026-1584 čl. 3. st. 7.) are
			// all archived publicly, not only the webshop's.
			$index = Plugin::instance()->publications()->index(
				array(
					'location' => GenerationService::single_list_mode() ? (int) $location['id'] : 0,
					'page'     => $paged,
					'per_page' => $per_page,
				)
			);

			$items = (array) $index['items'];
			$total = (int) $index['total'];
		}

		$rows = array();

		foreach ( $items as $item ) {
			$rows[] = $this->display_publication( $item );
		}

		$total_pages = $total > 0 ? (int) ceil( $total / $per_page ) : 1;

		$html = $this->style() . $this->partial(
			'public-archive.php',
			array(
				'rows'          => $rows,
				'location'      => $location,
				'paged'         => $paged,
				'per_page'      => $per_page,
				'total_items'   => $total,
				'total_pages'   => $total_pages,
				'list_url'      => home_url( '/' . self::STEM_LIST . '/' ),
				'feed_xml'      => home_url( '/' . PublicFeed::STEM . '.xml' ),
				'feed_csv'      => home_url( '/' . PublicFeed::STEM . '.csv' ),
				'feed_services' => self::services_feeds( $location ),
			)
		);

		$cache->set( $cache_key, $html );

		return $html;
	}

	/**
	 * Shortcode: the price list table.
	 *
	 * @param array<mixed> $atts Attributes.
	 * @return string
	 */
	public function shortcode_list( $atts ) {
		$atts = shortcode_atts(
			array(
				'q'     => '',
				'type'  => '',
				'paged' => 0,
			),
			$atts,
			'bazna-cijena-cjenik'
		);

		$paged = (int) $atts['paged'];
		if ( $paged <= 0 && isset( $_GET['paged'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only public filter.
			$paged = max( 1, absint( wp_unslash( $_GET['paged'] ) ) ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only public filter.
		}
		if ( $paged <= 0 ) {
			$paged = 1;
		}

		return $this->render_list(
			array(
				'q'     => (string) $atts['q'],
				'type'  => (string) $atts['type'],
				'paged' => $paged,
			)
		);
	}

	/**
	 * Shortcode: the publication archive table.
	 *
	 * @param array<mixed> $atts Attributes.
	 * @return string
	 */
	public function shortcode_archive( $atts ) {
		$atts = shortcode_atts(
			array(
				'paged' => 0,
			),
			$atts,
			'bazna-cijena-arhiva'
		);

		$paged = (int) $atts['paged'];
		if ( $paged <= 0 && isset( $_GET['paged'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only public filter.
			$paged = max( 1, absint( wp_unslash( $_GET['paged'] ) ) ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only public filter.
		}
		if ( $paged <= 0 ) {
			$paged = 1;
		}

		return $this->render_archive( array( 'paged' => $paged ) );
	}

	/**
	 * Request arguments of a public page request.
	 *
	 * @return array<mixed>
	 */
	protected function request_args() {
		$query = isset( $_GET['q'] ) ? sanitize_text_field( wp_unslash( (string) $_GET['q'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only public filter.
		$type  = isset( $_GET['type'] ) ? sanitize_key( wp_unslash( (string) $_GET['type'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only public filter.
		$paged = isset( $_GET['paged'] ) ? max( 1, absint( wp_unslash( $_GET['paged'] ) ) ) : 1; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only public filter.

		return array(
			'q'     => $query,
			'type'  => $type,
			'paged' => $paged,
		);
	}

	/**
	 * Whether a row matches a search term.
	 *
	 * @param array<mixed> $row Canonical row.
	 * @param string       $q   Search term.
	 * @return bool
	 */
	protected function matches( array $row, $q ) {
		foreach ( array( 'naziv', 'sifra', 'marka', 'barkod' ) as $field ) {
			$value = isset( $row[ $field ] ) ? (string) $row[ $field ] : '';

			if ( '' === $value ) {
				continue;
			}

			$found = function_exists( 'mb_stripos' ) ? mb_stripos( $value, $q ) : stripos( $value, $q );

			if ( false !== $found ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Add display values to a canonical row.
	 *
	 * @param array<mixed> $row Canonical row.
	 * @return array<mixed>
	 */
	protected function display_row( array $row ) {
		$row['unit_price_display']    = null === $row['cijena_za_jedinicu_mjere'] ? '' : Currency::format( (float) $row['cijena_za_jedinicu_mjere'] );
		$row['retail_display']        = null === $row['maloprodajna_cijena'] ? '' : Currency::format( (float) $row['maloprodajna_cijena'] );
		$lowest_30_day_price          = isset( $row['special_sale']['lowest_30_day_price'] ) ? $row['special_sale']['lowest_30_day_price'] : null;
		$row['lowest_30_day_display'] = null === $lowest_30_day_price ? '' : Currency::format( (float) $lowest_30_day_price );
		$row['anchor_display']        = null === $row['sidrena_cijena'] ? '' : Currency::format( (float) $row['sidrena_cijena'] );
		$row['reference_display']     = Dates::format_date_display( isset( $row['anchor_reference_date'] ) ? $row['anchor_reference_date'] : '' );
		$row['type_display']          = 'usluga' === $row['vrsta'] ? __( 'Service', 'titanworks-bazna-cijena' ) : __( 'Product', 'titanworks-bazna-cijena' );
		$row['sale_display']          = empty( $row['poseban_oblik_prodaje'] )
			? __( 'No', 'titanworks-bazna-cijena' )
			: trim( __( 'Yes', 'titanworks-bazna-cijena' ) . ( empty( $row['naziv_posebnog_oblika_prodaje'] ) ? '' : ' (' . (string) $row['naziv_posebnog_oblika_prodaje'] . ')' ) );
		$row['availability_display']  = 'dostupno' === $row['dostupnost'] ? __( 'Available', 'titanworks-bazna-cijena' ) : __( 'Unavailable', 'titanworks-bazna-cijena' );

		return $row;
	}

	/**
	 * Public URLs of the services price lists, when any is published.
	 *
	 * @param array<mixed>|null $location Public location.
	 * @return array<string,string> Extension => URL.
	 */
	protected static function services_feeds( $location ) {
		$feeds = array();

		if ( ! $location ) {
			return $feeds;
		}

		foreach ( array( 'xml', 'csv' ) as $extension ) {
			if ( Plugin::instance()->publications()->latest( (int) $location['id'], ListFormat::code( $extension, ListFormat::SERVICES ), array( 'published' ) ) ) {
				$feeds[ $extension ] = home_url( '/' . PublicFeed::STEM . '-usluge.' . $extension );
			}
		}

		return $feeds;
	}

	/**
	 * Add display values to a publication row.
	 *
	 * @param array<mixed> $item Publication row.
	 * @return array<mixed>
	 */
	protected function display_publication( array $item ) {
		$published = ! empty( $item['published_at'] ) ? (string) $item['published_at'] : (string) $item['created_at'];

		$item['published_display'] = wp_date( 'd.m.Y. H:i', (int) strtotime( $published ) );
		$item['format_display']    = strtoupper( ListFormat::extension( (string) $item['format'] ) )
			. ( ListFormat::SERVICES === ListFormat::list_type( (string) $item['format'] ) ? ' · ' . __( 'services', 'titanworks-bazna-cijena' ) : '' );
		$item['size_display']      = size_format( (int) $item['file_size'] );
		$item['checksum_short']    = substr( (string) $item['checksum'], 0, 12 );
		$item['download_url']      = (string) $item['url'];

		return $item;
	}

	/**
	 * Load a template partial, allowing a theme override.
	 *
	 * @param string       $name Partial file name.
	 * @param array<mixed> $args Template arguments.
	 * @return string
	 */
	protected function partial( $name, array $args ) {
		$template = locate_template( array( 'bazna-cijena/' . $name, 'sidrena-cijena/' . $name ) );
		$path     = $template ? $template : TWBCE_CIJENA_DIR . 'templates/' . $name;

		if ( ! is_readable( $path ) ) {
			return '';
		}

		ob_start();

		// phpcs:ignore WordPress.PHP.DontExtract.extract_extract -- Template arguments.
		extract( $args, EXTR_SKIP );

		include $path;

		return \Titanworks\BaznaCijena\Support\LegacyTemplate::normalize( (string) ob_get_clean(), $path );
	}

	/**
	 * Enqueue table styles once per request.
	 *
	 * Uses standard wp_enqueue_style so assets are registered and printed
	 * according to WordPress theme and plugin standards.
	 *
	 * @return string Empty string for backward compatibility with template concatenation.
	 */
	protected function style() {
		if ( self::$styled ) {
			return '';
		}

		self::$styled = true;

		if ( function_exists( 'wp_enqueue_style' ) ) {
			wp_enqueue_style(
				'bazna-cijena-frontend',
				TWBCE_CIJENA_URL . 'assets/css/frontend.css',
				array(),
				TWBCE_CIJENA_VERSION
			);
		}

		return '';
	}

	/**
	 * Guarantee Croatian translation catalog is loaded for statutory price list displays.
	 *
	 * @return void
	 */
	public static function ensure_croatian_catalog() {
		$candidates = array(
			TWBCE_CIJENA_DIR . 'languages/titanworks-bazna-cijena-hr.mo',
			TWBCE_CIJENA_DIR . 'languages/titanworks-bazna-cijena-hr_HR.mo',
		);

		foreach ( $candidates as $mo_file ) {
			if ( file_exists( $mo_file ) ) {
				load_textdomain( 'titanworks-bazna-cijena', $mo_file );
				break;
			}
		}
	}

	/**
	 * Print the optional author credit under a public price list.
	 *
	 * Opt-in only (WordPress.org Plugin Guideline 10): nothing is printed
	 * unless the merchant enabled "public_credit_link" in the settings or the
	 * setup guide.
	 *
	 * @return void
	 */
	public static function render_credit() {
		if ( ! Settings::get( 'public_credit_link', false ) ) {
			return;
		}

		printf(
			'<p class="bazna-cijena-cjenik__credit">%1$s <a href="%2$s" target="_blank" rel="noopener">administraktor.com</a></p>',
			esc_html__( 'Price list by', 'titanworks-bazna-cijena' ),
			esc_url( 'https://administraktor.com' )
		);
	}
}
