<?php
/**
 * Integrity check for base prices: published items without one, and items
 * whose base-price date is earlier than the day they were first offered.
 *
 * @package Titanworks\BaznaCijena\Pricing
 */

namespace Titanworks\BaznaCijena\Pricing;

use Titanworks\BaznaCijena\Catalog\CatalogItem;
use Titanworks\BaznaCijena\Catalog\CatalogProvider;
use Titanworks\BaznaCijena\Compliance\ReferenceDateResolver;
use Titanworks\BaznaCijena\Database\PriceHistoryRepository;
use Titanworks\BaznaCijena\Support\Dates;

defined( 'ABSPATH' ) || exit;

/**
 * Finds and repairs gaps between the catalog and the base-price records.
 *
 * Repairs are append-only: a missing base price gets its first record, and a
 * date correction is a new reasoned record with the unchanged price.
 */
final class AnchorIntegrity {

	/** Cached result of the last check, read by the admin notice. */
	const OPTION = 'twbce_cijena_integrity_last';

	/** Source for base prices recorded from the first-offer date. */
	const SOURCE_FIRST_OFFER = 'first_offer_backfill';

	/**
	 * History source of a reference-date correction.
	 */
	const SOURCE_DATE_CORRECTION = 'reference_date_correction';

	/**
	 * Catalog.
	 *
	 * @var CatalogProvider
	 */
	private $catalog;

	/**
	 * History.
	 *
	 * @var PriceHistoryRepository
	 */
	private $history;

	/**
	 * Anchor service.
	 *
	 * @var AnchorPriceService
	 */
	private $anchors;

	/**
	 * Constructor.
	 *
	 * @param CatalogProvider        $catalog Catalog.
	 * @param PriceHistoryRepository $history History.
	 * @param AnchorPriceService     $anchors Anchor service.
	 */
	public function __construct( CatalogProvider $catalog, PriceHistoryRepository $history, AnchorPriceService $anchors ) {
		$this->catalog = $catalog;
		$this->history = $history;
		$this->anchors = $anchors;
	}

	/**
	 * Scan every published catalog item.
	 *
	 * `missing` lists items with no base price. `fixable` is true when the item
	 * was first offered on or after its legal reference date, so the price on
	 * its first-offer day is the base price (NN 132/2026-1583 čl. 3. st. 3.).
	 * `dates` lists base prices dated before the item was first offered.
	 *
	 * @return array{missing:array<int,array<string,mixed>>,dates:array<int,array<string,mixed>>,checked:int}
	 */
	public function scan() {
		$missing = array();
		$dates   = array();
		$checked = 0;
		$batch   = array();

		// Same item set as the published price list: variations, not their parents.
		foreach ( $this->catalog->iterate( array( 'include_variations' => true ) ) as $item ) {
			$batch[] = $item;

			if ( count( $batch ) >= 200 ) {
				$checked += $this->scan_batch( $batch, $missing, $dates );
				$batch    = array();
			}
		}

		if ( $batch ) {
			$checked += $this->scan_batch( $batch, $missing, $dates );
		}

		$result = array(
			'missing' => $missing,
			'dates'   => $dates,
			'checked' => $checked,
		);

		update_option(
			self::OPTION,
			array(
				'missing'    => count( $missing ),
				'fixable'    => count( array_filter( array_column( $missing, 'fixable' ) ) ),
				'dates'      => count( $dates ),
				'checked_at' => Dates::now_utc(),
			),
			false
		);

		return $result;
	}

	/**
	 * Scan one batch.
	 *
	 * @param CatalogItem[]                  $batch   Items.
	 * @param array<int,array<string,mixed>> $missing Missing rows, appended.
	 * @param array<int,array<string,mixed>> $dates   Date rows, appended.
	 * @return int Items checked.
	 */
	private function scan_batch( array $batch, array &$missing, array &$dates ) {
		$ids     = array_values( array_unique( array_map( 'intval', array_column( $batch, 'id' ) ) ) );
		$anchors = $this->history->latest_map( $ids, 'anchor' );

		foreach ( $batch as $item ) {
			$baseline   = ReferenceDateResolver::date( $item );
			$first_seen = self::first_offered( $item );
			$verified   = self::verified_first_offer( $item );
			$anchor     = isset( $anchors[ $item->key() ] ) ? $anchors[ $item->key() ] : null;
			$row        = array(
				'product_id'   => (int) $item->id,
				'variation_id' => (int) $item->variation_id,
				'name'         => (string) $item->name,
				'sku'          => (string) $item->sku,
				'first_seen'   => $first_seen,
				'baseline'     => $baseline,
			);

			if ( ! $anchor ) {
				$evidence             = $this->evidence( $item, $first_seen, $verified );
				$row['date']          = '' !== $first_seen && $first_seen > $baseline ? $first_seen : $baseline;
				$row['price']         = $evidence ? $evidence['price'] : null;
				$row['tax_inclusive'] = $evidence ? $evidence['tax_inclusive'] : (bool) $item->tax_inclusive;
				$row['basis']         = $evidence ? $evidence['basis'] : '';
				$row['fixable']       = null !== $evidence && $first_seen >= $baseline && $row['date'] <= Dates::today();
				$missing[]            = $row;
				continue;
			}

			$anchor_date = isset( $anchor['reference_date'] ) ? (string) $anchor['reference_date'] : '';

			// A catalog or import date is only a suggestion; re-dating a
			// recorded base price needs the first offer the plugin observed.
			if ( '' !== $verified && $verified > $baseline && $verified <= Dates::today() && $anchor_date < $verified ) {
				$row['first_seen']    = $verified;
				$row['anchor_id']     = (int) $anchor['id'];
				$row['price']         = (float) $anchor['price'];
				$row['tax_inclusive'] = ! empty( $anchor['tax_inclusive'] );
				$row['anchor_date']   = $anchor_date;
				$row['date']          = $verified;
				$dates[]              = $row;
			}
		}

		return count( $batch );
	}

	/**
	 * Record a base price for every fixable missing item.
	 *
	 * @param bool $dry_run Report only.
	 * @return array{recorded:int,skipped:int,failed:int,rows:array<int,array<string,mixed>>}
	 */
	public function fix_missing( $dry_run = false ) {
		$scan     = $this->scan();
		$recorded = 0;
		$skipped  = 0;
		$failed   = 0;
		$rows     = array();

		foreach ( $scan['missing'] as $row ) {
			if ( empty( $row['fixable'] ) ) {
				++$skipped;
				continue;
			}

			$item = $this->item( $row );

			if ( ! $item ) {
				++$skipped;
				continue;
			}

			$rows[] = $row;

			if ( $dry_run ) {
				continue;
			}

			// Another request may have recorded it since the scan.
			if ( $this->anchors->get_anchor( $item ) ) {
				continue;
			}

			$result = $this->anchors->record(
				$item,
				$row['price'],
				array(
					'reference_date' => $row['date'],
					'source'         => self::SOURCE_FIRST_OFFER,
					'tax_inclusive'  => ! empty( $row['tax_inclusive'] ),
					'metadata'       => array(
						'first_seen' => $row['first_seen'],
						'baseline'   => $row['baseline'],
						'basis'      => $row['basis'],
					),
				)
			);

			if ( ! is_wp_error( $result ) && $result ) {
				++$recorded;
			} else {
				++$failed;
			}
		}

		if ( ! $dry_run && $recorded ) {
			$this->scan();
		}

		return array(
			'recorded' => $recorded,
			'skipped'  => $skipped,
			'failed'   => $failed,
			'rows'     => $rows,
		);
	}

	/**
	 * Re-date base prices that predate the item's first offer.
	 *
	 * Each correction is a new history row with the same price and a reason;
	 * the price itself is never changed.
	 *
	 * @param string $reason  Correction reason.
	 * @param bool   $dry_run Report only.
	 * @return array{corrected:int,failed:int,rows:array<int,array<string,mixed>>}|\WP_Error
	 */
	public function correct_dates( $reason, $dry_run = false ) {
		$reason = trim( (string) $reason );

		if ( ! $dry_run && strlen( $reason ) < 5 ) {
			return new \WP_Error( 'reason_required', __( 'Enter a reason of at least 5 characters.', 'titanworks-bazna-cijena' ) );
		}

		$scan      = $this->scan();
		$corrected = 0;
		$failed    = 0;

		if ( ! $dry_run ) {
			foreach ( $scan['dates'] as $row ) {
				$item = $this->item( $row );

				if ( ! $item ) {
					continue;
				}

				$result = $this->anchors->record(
					$item,
					$row['price'],
					array(
						'reference_date'    => $row['date'],
						'source'            => self::SOURCE_DATE_CORRECTION,
						'correction_of'     => $row['anchor_id'],
						'correction_reason' => $reason,
						'tax_inclusive'     => ! empty( $row['tax_inclusive'] ),
					)
				);

				if ( ! is_wp_error( $result ) && $result ) {
					++$corrected;
				} else {
					++$failed;
				}
			}

			if ( $corrected ) {
				$this->scan();
			}
		}

		return array(
			'corrected' => $corrected,
			'failed'    => $failed,
			'rows'      => $scan['dates'],
		);
	}

	/**
	 * Day the item was first offered, in site time (Y-m-d) or ''.
	 *
	 * @param CatalogItem $item Item.
	 * @return string
	 */
	public static function first_offered( CatalogItem $item ) {
		$date = substr( (string) $item->first_seen, 0, 10 );

		return Dates::is_valid_date( $date ) ? $date : '';
	}

	/**
	 * First-offer day the plugin itself observed, or ''.
	 *
	 * Only the observation FirstOfferRecorder freezes when it witnesses the
	 * first offer counts. `_twbce_first_seen` is also written by editable date
	 * fields and post-date fallbacks, and post and import dates are not proof
	 * (docs/legal-rules.md).
	 *
	 * @param CatalogItem $item Item.
	 * @return string `Y-m-d` or ''.
	 */
	public static function verified_first_offer( CatalogItem $item ) {
		$post_id  = $item->variation_id ? (int) $item->variation_id : (int) $item->id;
		$observed = FirstOfferRecorder::observation( $post_id );
		$date     = is_array( $observed ) && isset( $observed['observed_at'] )
			? substr( (string) $observed['observed_at'], 0, 10 )
			: '';

		return Dates::is_valid_date( $date ) ? $date : '';
	}

	/**
	 * Non-discounted price to record (NN 132/2026-1583 čl. 3. st. 4. i 5.),
	 * on the catalog's own tax basis like a manual entry.
	 *
	 * @param CatalogItem $item Item.
	 * @return float|null
	 */
	public static function first_offer_price( CatalogItem $item ) {
		$price = null !== $item->regular_price ? $item->regular_price : $item->current_price;

		return null === $price || $price < 0 ? null : (float) $price;
	}

	/**
	 * Evidence of the regular price on the first-offer day.
	 *
	 * Neither a current catalog price nor a post or import date proves
	 * anything about an earlier day (docs/legal-rules.md), so a repair uses
	 * only:
	 * 1. the first-offer observation stored when the item was published;
	 * 2. a regular price row recorded and valid on that observed day;
	 * 3. the current regular price when an item the recorder marked as newly
	 *    created or first published is first offered today.
	 * Anything else needs a verified manual entry. The price keeps the tax
	 * basis it was recorded on, so storefront and lists convert it once.
	 *
	 * @param CatalogItem $item       Item.
	 * @param string      $first_seen First-offer date (`Y-m-d`).
	 * @param string      $verified   Observed first-offer date or ''.
	 * @return array{price:float,tax_inclusive:bool,basis:string}|null
	 */
	private function evidence( CatalogItem $item, $first_seen, $verified ) {
		if ( '' === (string) $first_seen ) {
			return null;
		}

		$post_id = $item->variation_id ? (int) $item->variation_id : (int) $item->id;

		if ( $verified === $first_seen ) {
			$observed = FirstOfferRecorder::observation( $post_id );

			if ( is_array( $observed ) && isset( $observed['price'] ) && is_numeric( $observed['price'] ) ) {
				// The recorder stores the observed regular price including tax.
				return array(
					'price'         => (float) $observed['price'],
					'tax_inclusive' => true,
					'basis'         => 'first_offer_observation',
				);
			}

			$recorded = array();

			foreach ( $this->history->timeline( (int) $item->id, (int) $item->variation_id, $first_seen, $first_seen ) as $history_row ) {
				if ( isset( $history_row['price_type'], $history_row['price'] ) && 'regular' === $history_row['price_type'] && is_numeric( $history_row['price'] ) ) {
					$recorded[ (string) (float) $history_row['price'] ] = array(
						'price'         => (float) $history_row['price'],
						'tax_inclusive' => ! empty( $history_row['tax_inclusive'] ),
						'basis'         => 'recorded_regular_price',
					);
				}
			}

			if ( 1 === count( $recorded ) ) {
				return reset( $recorded );
			}

			if ( count( $recorded ) > 1 ) {
				// The regular price changed on the first-offer day and the history
				// cannot prove which price was offered first: enter it manually.
				return null;
			}
		}

		// Only items the recorder marked at creation or first publication: the
		// import marker ('0') is removed on the import save itself, so a missing
		// marker is not proof that the item was not imported.
		if ( Dates::today() === $first_seen && (int) get_post_meta( $post_id, FirstOfferRecorder::ELIGIBLE, true ) === $post_id ) {
			$price = self::first_offer_price( $item );

			return null === $price ? null : array(
				'price'         => $price,
				'tax_inclusive' => (bool) $item->tax_inclusive,
				'basis'         => 'regular_price_on_first_offer_day',
			);
		}

		return null;
	}

	/**
	 * Load the catalog item for a scan row.
	 *
	 * @param array<string,mixed> $row Row.
	 * @return CatalogItem|null
	 */
	private function item( array $row ) {
		return $row['variation_id']
			? $this->catalog->get_variation( (int) $row['product_id'], (int) $row['variation_id'] )
			: $this->catalog->get_item( (int) $row['product_id'] );
	}
}
