<?php
/**
 * Contemporaneous first-offer evidence for newly created catalog entries.
 *
 * @package Titanworks\BaznaCijena\Pricing
 */

namespace Titanworks\BaznaCijena\Pricing;

use Titanworks\BaznaCijena\Catalog\CatalogItem;
use Titanworks\BaznaCijena\Catalog\StandaloneCatalogProvider;
use Titanworks\BaznaCijena\Catalog\StandalonePostType;
use Titanworks\BaznaCijena\Compliance\ReferenceDateResolver;
use Titanworks\BaznaCijena\Logging\Logger;
use Titanworks\BaznaCijena\Plugin;
use Titanworks\BaznaCijena\Support\Dates;
use Titanworks\BaznaCijena\WooCommerce\WooCommerceCatalogProvider;

defined( 'ABSPATH' ) || exit;

/**
 * Observes new entries prospectively; never scans or backfills existing entries.
 */
final class FirstOfferRecorder {

	/** Eligibility is tied to the actual post ID, so copied metadata cannot qualify another item. */
	const ELIGIBLE = '_twbce_first_offer_eligible';

	/** Immutable observation, retained even if writing the history row fails. */
	const OBSERVATION = '_twbce_first_offer_observation';

	/** Set when a product leaves the published state: proof it was offered before. */
	const WAS_PUBLISHED = '_twbce_was_published';

	/**
	 * Register after plugin activation, before catalog writes.
	 *
	 * @return void
	 */
	public function register() {
		add_action( 'wp_insert_post', array( $this, 'observe_creation' ), 10, 3 );
		add_action( 'wp_after_insert_post', array( $this, 'capture_standalone' ), 20, 2 );
		add_action( 'woocommerce_after_product_object_save', array( $this, 'capture_woocommerce' ) );
		add_action( 'transition_post_status', array( $this, 'observe_first_publish' ), 10, 3 );
		add_filter( 'woocommerce_product_import_pre_insert_product_object', array( $this, 'exclude_import' ) );
		add_filter( 'woocommerce_duplicate_product_exclude_meta', array( $this, 'exclude_duplicate_meta' ) );
	}

	/**
	 * First-offer evidence belongs to one product and must not travel with a copy.
	 *
	 * @return string[]
	 */
	public static function evidence_meta_keys() {
		return array( self::ELIGIBLE, self::OBSERVATION, self::WAS_PUBLISHED, '_twbce_first_seen' );
	}

	/**
	 * Keep WooCommerce's Duplicate action from cloning first-offer evidence.
	 *
	 * @param mixed $exclude Meta keys WooCommerce will not copy.
	 * @return string[]
	 */
	public function exclude_duplicate_meta( $exclude ) {
		return array_values( array_unique( array_merge( (array) $exclude, self::evidence_meta_keys() ) ) );
	}

	/**
	 * The frozen observation of this exact post, ignoring one copied from another product.
	 *
	 * @param int $post_id Product or variation ID.
	 * @return array<string,mixed>|null
	 */
	public static function observation( $post_id ) {
		$post_id  = (int) $post_id;
		$observed = get_post_meta( $post_id, self::OBSERVATION, true );

		if ( ! is_array( $observed ) || ! isset( $observed['product_id'], $observed['variation_id'] ) ) {
			return null;
		}

		$variation_id = (int) $observed['variation_id'];
		$owner        = $variation_id ? $variation_id : (int) $observed['product_id'];

		return $owner === $post_id ? $observed : null;
	}

	/**
	 * An import is not evidence of a product's first offer for sale.
	 *
	 * @param \WC_Product $product Imported product.
	 * @return \WC_Product
	 */
	public function exclude_import( $product ) {
		$product->update_meta_data( self::ELIGIBLE, '0' );
		return $product;
	}

	/**
	 * Mark only insertions actually witnessed with this recorder active.
	 *
	 * @param int      $post_id Post ID.
	 * @param \WP_Post $post Post.
	 * @param bool     $update Whether this is an existing entry.
	 * @return void
	 */
	public function observe_creation( $post_id, $post, $update ) {
		if ( defined( 'WP_IMPORTING' ) && WP_IMPORTING ) {
			return;
		}
		if ( ! $update && in_array( $post->post_type, array( 'product', 'product_variation', StandalonePostType::POST_TYPE ), true ) ) {
			update_post_meta( $post_id, self::ELIGIBLE, (int) $post_id );
		}
	}

	/**
	 * A product that waited as a draft (or was scheduled) is first offered for
	 * sale when it is published. Mark it and its variations, unless they already
	 * have a base price, then capture once the save has finished.
	 *
	 * @param string   $new_status New status.
	 * @param string   $old_status Old status.
	 * @param \WP_Post $post       Post.
	 * @return void
	 */
	public function observe_first_publish( $new_status, $old_status, $post ) {
		if ( 'product' !== $post->post_type || $new_status === $old_status ) {
			return;
		}
		if ( 'publish' === $old_status ) {
			update_post_meta( (int) $post->ID, self::WAS_PUBLISHED, Dates::today() );
			return;
		}
		if ( 'publish' !== $new_status || ! self::is_first_publication( $post, $old_status ) ) {
			return;
		}
		if ( ( defined( 'WP_IMPORTING' ) && WP_IMPORTING ) || ! function_exists( 'wc_get_product' ) ) {
			return;
		}

		$post_id = (int) $post->ID;
		$ids     = array_merge(
			array( $post_id ),
			array_map(
				'intval',
				(array) get_children(
					array(
						'post_parent' => $post_id,
						'post_type'   => 'product_variation',
						'fields'      => 'ids',
					)
				)
			)
		);

		foreach ( $ids as $id ) {
			// An imported item stays excluded; an observed one keeps its evidence.
			if ( '0' === (string) get_post_meta( $id, self::ELIGIBLE, true ) || self::observation( $id ) ) {
				continue;
			}
			update_post_meta( $id, self::ELIGIBLE, $id );
		}

		// Prices and variations are saved after the status change. Capturing
		// after the request (or right away in WooCommerce's after-save hook)
		// reads the final values. capture() runs once per item.
		$recorder = $this;
		add_action(
			'shutdown',
			static function () use ( $recorder, $post_id ) {
				clean_post_cache( $post_id );
				$product = wc_get_product( $post_id );
				if ( $product ) {
					$recorder->capture_woocommerce( $product );
				}
			}
		);
	}

	/**
	 * Whether a publish is the product's first offer for sale.
	 *
	 * Unpublishing and republishing, restoring from the trash or publishing a
	 * backdated post is not a first offer. Publishing a draft sets its post
	 * date to today, so an older date means it was offered before. Without
	 * that proof the item is left for a verified manual entry.
	 *
	 * @param \WP_Post $post       Product being published.
	 * @param string   $old_status Previous status.
	 * @return bool
	 */
	private static function is_first_publication( $post, $old_status ) {
		$post_id = (int) $post->ID;

		if ( 'trash' === $old_status
			|| get_post_meta( $post_id, self::WAS_PUBLISHED, true )
			|| get_post_meta( $post_id, '_twbce_first_seen', true )
			|| self::observation( $post_id ) ) {
			return false;
		}

		$post_date = substr( (string) $post->post_date, 0, 10 );

		return Dates::today() === $post_date;
	}

	/**
	 * Capture standalone items after their fields and terms have been saved.
	 *
	 * @param int      $post_id Post ID.
	 * @param \WP_Post $post Post.
	 * @return void
	 */
	public function capture_standalone( $post_id, $post ) {
		if ( StandalonePostType::POST_TYPE !== $post->post_type || 'publish' !== $post->post_status ) {
			return;
		}
		$item = ( new StandaloneCatalogProvider() )->get_item( $post_id );
		if ( $item && $item->tax_inclusive ) {
			// NN 132/2026-1583 čl. 3. st. 4. i 5.: the base price is the
			// non-discounted price, even when the first offer is already on sale.
			if ( null !== $item->regular_price && $item->regular_price > 0 ) {
				$item->current_price = (float) $item->regular_price;
			}
			$this->capture( $item );
		}
	}

	/**
	 * Capture only a saved, published offer; never use a variable parent's range.
	 *
	 * @param \WC_Product $product Saved product.
	 * @return void
	 */
	public function capture_woocommerce( $product ) {
		// WooCommerce writes imported object metadata after wp_insert_post.
		// Remove insertion eligibility before this or any later save can use it.
		if ( '0' === (string) $product->get_meta( self::ELIGIBLE ) ) {
			delete_post_meta( $product->get_id(), self::ELIGIBLE );
			return;
		}
		if ( 'publish' !== $product->get_status() ) {
			return;
		}
		if ( $product->is_type( 'variable' ) ) {
			foreach ( $product->get_children() as $child_id ) {
				$child = wc_get_product( $child_id );
				if ( $child ) {
					$this->capture_woocommerce( $child );
				}
			}
			return;
		}
		if ( $product->is_type( 'variation' ) && 'publish' !== get_post_status( $product->get_parent_id() ) ) {
			return;
		}
		if ( '' === $product->get_price( 'edit' ) ) {
			return;
		}
		$provider = new WooCommerceCatalogProvider();
		$item     = $product->is_type( 'variation' )
			? $provider->get_variation( $product->get_parent_id(), $product->get_id() )
			: $provider->get_item( $product->get_id() );
		if ( $item ) {
			// NN 132/2026-1583 čl. 3. st. 4. i 5.: a discounted first-offer price
			// is not the base price; the non-discounted price is.
			$regular             = $product->get_regular_price( 'edit' );
			$item->current_price = '' !== (string) $regular
				? (float) wc_get_price_including_tax( $product, array( 'price' => $regular ) )
				: (float) wc_get_price_including_tax( $product );
			$item->tax_inclusive = true;
			$this->capture( $item );
		}
	}

	/**
	 * Freeze the witnessed offer before recording its anchor, once only.
	 *
	 * @param CatalogItem $item Published catalog offer.
	 * @return void
	 */
	private function capture( CatalogItem $item ) {
		$post_id = $item->variation_id ? $item->variation_id : $item->id;
		if ( (int) get_post_meta( $post_id, self::ELIGIBLE, true ) !== $post_id
			|| self::observation( $post_id )
			|| null === $item->current_price || $item->current_price < 0 ) {
			return;
		}
		// A copy of another product's observation is not evidence for this one.
		delete_post_meta( $post_id, self::OBSERVATION );
		$now      = Dates::now_site();
		$baseline = ReferenceDateResolver::date( $item );
		$evidence = array(
			'product_id'   => $item->id,
			'variation_id' => $item->variation_id,
			'observed_at'  => $now->format( DATE_ATOM ),
			'price'        => $item->current_price,
			'currency'     => $item->currency,
			'baseline'     => $baseline,
		);
		if ( ! add_post_meta( $post_id, self::OBSERVATION, $evidence, true ) ) {
			return;
		}
		// An offer before the baseline does not prove its price on that later date.
		if ( $now->format( 'Y-m-d' ) < $baseline || Plugin::instance()->anchors()->get_anchor( $item ) ) {
			return;
		}
		update_post_meta( $post_id, '_twbce_first_seen', $now->format( 'Y-m-d' ) );
		$result = Plugin::instance()->anchors()->record(
			$item,
			$item->current_price,
			array(
				'reference_date' => $now->format( 'Y-m-d' ),
				'valid_from'     => Dates::to_utc( $now ),
				'source'         => 'observed_first_offer',
				'tax_inclusive'  => true,
				'metadata'       => $evidence,
			)
		);
		if ( is_wp_error( $result ) || ! $result ) {
			$message = is_wp_error( $result ) ? $result->get_error_message() : 'The first-offer history row could not be written.';
			Logger::error( 'first_offer_record_failed', $message, $evidence );
		}
	}
}
