<?php
/**
 * Paid services screen (USLUGE price list).
 *
 * @package Titanworks\BaznaCijena\Admin
 */

namespace Titanworks\BaznaCijena\Admin;

use Titanworks\BaznaCijena\Api\PublicFeed;
use Titanworks\BaznaCijena\Plugin;
use Titanworks\BaznaCijena\Services\ServiceCatalog;
use Titanworks\BaznaCijena\Services\ServiceManager;
use Titanworks\BaznaCijena\Services\ShippingMethods;
use Titanworks\BaznaCijena\Support\Currency;
use Titanworks\BaznaCijena\Support\Dates;
use Titanworks\BaznaCijena\Support\Settings;

defined( 'ABSPATH' ) || exit;

/**
 * Lists, adds and edits the services shown in the separate services list.
 */
class ServicesPage {

	/**
	 * Page slug.
	 */
	const SLUG = 'bazna-cijena-services';

	/**
	 * Save action.
	 */
	const ACTION_SAVE = 'twbce_cijena_save_service';

	/**
	 * Switch on/off action.
	 */
	const ACTION_TOGGLE = 'twbce_cijena_toggle_service';

	/**
	 * Import from shipping methods action.
	 */
	const ACTION_IMPORT = 'twbce_cijena_import_shipping';

	/**
	 * Register admin-post handlers.
	 *
	 * @return void
	 */
	public static function register() {
		add_action( 'admin_post_' . self::ACTION_SAVE, array( __CLASS__, 'handle_save' ) );
		add_action( 'admin_post_' . self::ACTION_TOGGLE, array( __CLASS__, 'handle_toggle' ) );
		add_action( 'admin_post_' . self::ACTION_IMPORT, array( __CLASS__, 'handle_import' ) );
	}

	/**
	 * Render the screen.
	 *
	 * @return void
	 */
	public static function render() {
		if ( ! Capabilities::current_user_can() ) {
			wp_die( esc_html__( 'You do not have permission to access this page.', 'titanworks-bazna-cijena' ) );
		}

		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only screen selection.
		$edit_id = isset( $_GET['service'] ) ? absint( wp_unslash( $_GET['service'] ) ) : 0;
		$edit    = $edit_id ? get_post( $edit_id ) : null;
		$edit    = ServiceCatalog::is_service_post( $edit ) ? $edit : null;

		echo '<div class="wrap bazna-services">';
		echo '<h1>' . esc_html__( 'Bazna cijena: Services', 'titanworks-bazna-cijena' ) . '</h1>';

		Notice::from_request();

		echo '<p>' . esc_html__( 'Services you charge consumers for, such as delivery, are published in a separate services price list (USLUGE) with their own base price. Products are not entered here.', 'titanworks-bazna-cijena' ) . '</p>';

		if ( ! ServiceCatalog::enabled() ) {
			echo '<div class="notice notice-warning inline"><p>' . esc_html__( 'Services are switched off, so no services price list is published.', 'titanworks-bazna-cijena' ) . ' <a href="' . esc_url( AdminMenu::url( SettingsPage::SLUG, array( 'tab' => 'operations' ) ) ) . '">' . esc_html__( 'Change in settings', 'titanworks-bazna-cijena' ) . '</a></p></div>';
		}

		self::render_list();

		if ( ! $edit ) {
			self::render_shipping_import();
		}

		self::render_form( $edit );
		self::render_feeds();

		echo '</div>';
	}

	/**
	 * Shipping methods offered for import, with paid methods pre-selected.
	 *
	 * Shared with the setup wizard.
	 *
	 * @return bool Whether any method can be imported.
	 */
	public static function render_shipping_choices() {
		$rows = array();

		foreach ( ShippingMethods::candidates() as $candidate ) {
			// Free methods are not paid services (and a 0 price blocks publication).
			if ( ( null !== $candidate['price'] && $candidate['price'] <= 0 ) || ServiceManager::linked_service( $candidate['instance_id'] ) ) {
				continue;
			}

			$rows[] = $candidate;
		}

		if ( empty( $rows ) ) {
			return false;
		}

		echo '<fieldset class="bazna-services__choices"><legend class="screen-reader-text">' . esc_html__( 'Shipping methods', 'titanworks-bazna-cijena' ) . '</legend>';

		foreach ( $rows as $row ) {
			$id    = 'bazna-shipping-' . (int) $row['instance_id'];
			$price = null === $row['price'] ? __( 'price depends on the cart, enter it manually', 'titanworks-bazna-cijena' ) : Currency::format( $row['price'] );

			echo '<label for="' . esc_attr( $id ) . '" class="bazna-services__choice">';
			echo '<input type="checkbox" id="' . esc_attr( $id ) . '" name="shipping[]" value="' . esc_attr( (string) (int) $row['instance_id'] ) . '"' . checked( $row['paid'], true, false ) . disabled( null === $row['price'], true, false ) . ' /> ';
			echo '<strong>' . esc_html( $row['name'] ) . '</strong> <span class="bazna-services__price">' . esc_html( $price ) . '</span>';
			echo '</label>';
		}

		echo '</fieldset>';

		return true;
	}

	/**
	 * Base-price date field with the default for services already offered.
	 *
	 * @param string $id    Field ID.
	 * @param string $value Current value.
	 * @return void
	 */
	public static function render_base_date_field( $id, $value = '' ) {
		$value = '' !== $value ? $value : ServiceManager::default_base_date();

		echo '<input type="date" id="' . esc_attr( $id ) . '" name="base_date" value="' . esc_attr( $value ) . '" max="' . esc_attr( Dates::today() ) . '" />';
		echo '<p class="description">' . esc_html__( 'Keep the reference date if you already charged this price on that day. For a service you started offering later, enter the first day you offered it.', 'titanworks-bazna-cijena' ) . '</p>';
	}

	/**
	 * Services table.
	 *
	 * @return void
	 */
	protected static function render_list() {
		$posts   = ServiceCatalog::posts( false );
		$history = Plugin::instance()->history();
		$methods = array();

		foreach ( ShippingMethods::candidates() as $candidate ) {
			$methods[ (int) $candidate['instance_id'] ] = $candidate['name'];
		}

		echo '<h2>' . esc_html__( 'Your services', 'titanworks-bazna-cijena' ) . '</h2>';
		echo '<table class="widefat striped bazna-services__table">';
		echo '<caption class="screen-reader-text">' . esc_html__( 'Services', 'titanworks-bazna-cijena' ) . '</caption>';
		echo '<thead><tr>';

		foreach ( array(
			__( 'Service', 'titanworks-bazna-cijena' ),
			__( 'Price', 'titanworks-bazna-cijena' ),
			__( 'Base price', 'titanworks-bazna-cijena' ),
			__( 'Price source', 'titanworks-bazna-cijena' ),
			__( 'Status', 'titanworks-bazna-cijena' ),
			__( 'Actions', 'titanworks-bazna-cijena' ),
		) as $heading ) {
			echo '<th scope="col">' . esc_html( $heading ) . '</th>';
		}

		echo '</tr></thead><tbody>';

		if ( empty( $posts ) ) {
			echo '<tr><td colspan="6">' . esc_html__( 'No services yet. Import your delivery methods below or add a service by hand.', 'titanworks-bazna-cijena' ) . '</td></tr>';
		}

		foreach ( $posts as $post ) {
			$item     = ServiceCatalog::build_item( $post );
			$anchor   = $history->latest( (int) $post->ID, 0, 'anchor' );
			$shipping = (int) get_post_meta( $post->ID, ServiceCatalog::META_SHIPPING, true );
			$active   = 'publish' === $post->post_status;

			echo '<tr>';
			echo '<td><strong>' . esc_html( $item->name ) . '</strong></td>';
			echo '<td>' . esc_html( null === $item->regular_price ? '—' : Currency::format( $item->regular_price, $item->currency ) ) . '</td>';
			echo '<td>';

			if ( $anchor ) {
				echo esc_html( Currency::format( (float) $anchor['price'], $item->currency ) );
				echo '<br /><span class="description">' . esc_html( Dates::format_date_display( (string) $anchor['reference_date'] ) ) . '</span>';
			} else {
				echo '<span class="bazna-services__missing">' . esc_html__( 'Missing', 'titanworks-bazna-cijena' ) . '</span>';
			}

			echo '</td>';
			echo '<td>';

			if ( $shipping ) {
				/* translators: %s: shipping method name. */
				echo esc_html( sprintf( __( 'WooCommerce shipping: %s', 'titanworks-bazna-cijena' ), isset( $methods[ $shipping ] ) ? $methods[ $shipping ] : '#' . $shipping ) );
			} else {
				echo esc_html__( 'Entered by hand', 'titanworks-bazna-cijena' );
			}

			echo '</td>';
			echo '<td>' . esc_html( $active ? __( 'Listed', 'titanworks-bazna-cijena' ) : __( 'Not listed', 'titanworks-bazna-cijena' ) ) . '</td>';
			echo '<td><a href="' . esc_url( AdminMenu::url( self::SLUG, array( 'service' => (int) $post->ID ) ) . '#bazna-service-form' ) . '">' . esc_html__( 'Edit', 'titanworks-bazna-cijena' ) . '</a> | ';
			echo '<a href="' . esc_url( self::toggle_url( (int) $post->ID, ! $active ) ) . '">' . esc_html( $active ? __( 'Stop listing', 'titanworks-bazna-cijena' ) : __( 'List again', 'titanworks-bazna-cijena' ) ) . '</a></td>';
			echo '</tr>';
		}

		echo '</tbody></table>';
	}

	/**
	 * Import box for WooCommerce shipping methods.
	 *
	 * @return void
	 */
	protected static function render_shipping_import() {
		if ( ! class_exists( '\WC_Shipping_Zones' ) ) {
			return;
		}

		echo '<div class="bazna-services__import">';
		echo '<h2>' . esc_html__( 'Import delivery from WooCommerce', 'titanworks-bazna-cijena' ) . '</h2>';
		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" class="bazna-busy-form">';
		wp_nonce_field( self::ACTION_IMPORT );
		echo '<input type="hidden" name="action" value="' . esc_attr( self::ACTION_IMPORT ) . '" />';

		if ( ! self::render_shipping_choices() ) {
			echo '<p>' . esc_html__( 'Every enabled shipping method is already listed.', 'titanworks-bazna-cijena' ) . '</p></form></div>';

			return;
		}

		echo '<p><label for="bazna-import-date"><strong>' . esc_html__( 'Base price date', 'titanworks-bazna-cijena' ) . '</strong></label><br />';
		self::render_base_date_field( 'bazna-import-date' );
		echo '</p>';
		echo '<p class="description">' . esc_html__( 'Imported services keep following WooCommerce: a new shipping price is recorded automatically, and a disabled method is taken off the list.', 'titanworks-bazna-cijena' ) . '</p>';
		submit_button( __( 'Import selected', 'titanworks-bazna-cijena' ), 'primary bazna-btn-busy', 'submit', false );
		echo '</form></div>';
	}

	/**
	 * Add or edit form.
	 *
	 * @param \WP_Post|null $post Service being edited.
	 * @return void
	 */
	protected static function render_form( $post ) {
		$state  = FormState::pull( 'service-form' );
		$values = $state['values'];
		$errors = $state['errors'];
		$id     = $post ? (int) $post->ID : 0;
		$item   = $post ? ServiceCatalog::build_item( $post ) : null;
		$anchor = $id ? Plugin::instance()->history()->latest( $id, 0, 'anchor' ) : null;

		$name       = isset( $values['name'] ) ? (string) $values['name'] : ( $item ? $item->name : '' );
		$price      = isset( $values['price'] ) ? (string) $values['price'] : ( $item && null !== $item->regular_price ? Currency::format_decimal( $item->regular_price ) : '' );
		$base_price = isset( $values['base_price'] ) ? (string) $values['base_price'] : ( $anchor ? Currency::format_decimal( (float) $anchor['price'] ) : '' );
		$base_date  = isset( $values['base_date'] ) ? (string) $values['base_date'] : ( $anchor ? (string) $anchor['reference_date'] : '' );
		$active     = isset( $values['active'] ) ? ! empty( $values['active'] ) : ( ! $post || 'publish' === $post->post_status );

		echo '<h2 id="bazna-service-form">' . esc_html( $id ? __( 'Edit service', 'titanworks-bazna-cijena' ) : __( 'Add a service by hand', 'titanworks-bazna-cijena' ) ) . '</h2>';
		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" class="bazna-busy-form">';
		wp_nonce_field( self::ACTION_SAVE );
		echo '<input type="hidden" name="action" value="' . esc_attr( self::ACTION_SAVE ) . '" />';
		echo '<input type="hidden" name="service_id" value="' . esc_attr( (string) $id ) . '" />';
		echo '<table class="form-table" role="presentation"><tbody>';

		echo '<tr><th scope="row"><label for="bazna-service-name">' . esc_html__( 'Service name', 'titanworks-bazna-cijena' ) . '</label></th><td>';
		echo '<input type="text" class="regular-text" id="bazna-service-name" name="name" required value="' . esc_attr( $name ) . '" placeholder="' . esc_attr__( 'e.g. Home delivery', 'titanworks-bazna-cijena' ) . '"';
		FormState::render_error_attributes( $errors, 'name', 'bazna-service-name' );
		echo ' />';
		FormState::render_error( $errors, 'name', 'bazna-service-name' );
		echo '</td></tr>';

		$linked = $id && get_post_meta( $id, ServiceCatalog::META_SHIPPING, true );

		echo '<tr><th scope="row"><label for="bazna-service-price">' . esc_html__( 'Price incl. VAT', 'titanworks-bazna-cijena' ) . '</label></th><td>';
		echo '<input type="text" inputmode="decimal" class="small-text bazna-services__amount" id="bazna-service-price" name="price" required value="' . esc_attr( $price ) . '"' . ( $linked ? ' readonly aria-describedby="bazna-service-price-linked"' : '' );
		FormState::render_error_attributes( $errors, 'price', 'bazna-service-price' );
		echo ' /> ' . esc_html( function_exists( 'get_woocommerce_currency' ) ? (string) get_woocommerce_currency() : Currency::DEFAULT_CURRENCY );
		FormState::render_error( $errors, 'price', 'bazna-service-price' );

		if ( $linked ) {
			echo '<p class="description" id="bazna-service-price-linked">' . esc_html__( 'Linked to a WooCommerce shipping method: change the price there and it is copied here.', 'titanworks-bazna-cijena' ) . '</p>';
		}

		echo '</td></tr>';

		echo '<tr><th scope="row"><label for="bazna-service-base">' . esc_html__( 'Base price', 'titanworks-bazna-cijena' ) . '</label></th><td>';
		echo '<input type="text" inputmode="decimal" class="small-text bazna-services__amount" id="bazna-service-base" name="base_price" value="' . esc_attr( $base_price ) . '"';
		FormState::render_error_attributes( $errors, 'base_price', 'bazna-service-base' );
		echo ' />';
		echo '<p class="description">' . esc_html__( 'The retail price on the reference date, or on the first day you offered the service. Leave empty to use the price above.', 'titanworks-bazna-cijena' ) . '</p>';
		FormState::render_error( $errors, 'base_price', 'bazna-service-base' );
		echo '</td></tr>';

		echo '<tr><th scope="row"><label for="bazna-service-date">' . esc_html__( 'Base price date', 'titanworks-bazna-cijena' ) . '</label></th><td>';
		self::render_base_date_field( 'bazna-service-date', $base_date );
		echo '</td></tr>';

		if ( $anchor ) {
			echo '<tr><th scope="row"><label for="bazna-service-reason">' . esc_html__( 'Correction reason', 'titanworks-bazna-cijena' ) . '</label></th><td>';
			echo '<input type="text" class="regular-text" id="bazna-service-reason" name="base_reason" value=""';
			FormState::render_error_attributes( $errors, 'base_reason', 'bazna-service-reason' );
			echo ' />';
			echo '<p class="description">' . esc_html__( 'Only needed when you change the base price or its date. The previous value stays in the price history.', 'titanworks-bazna-cijena' ) . '</p>';
			FormState::render_error( $errors, 'base_reason', 'bazna-service-reason' );
			echo '</td></tr>';
		}

		echo '<tr><th scope="row">' . esc_html__( 'Price list', 'titanworks-bazna-cijena' ) . '</th><td>';
		echo '<input type="hidden" name="active" value="0" />';
		echo '<label><input type="checkbox" name="active" value="1"' . checked( $active, true, false ) . ' /> ' . esc_html__( 'List this service in the services price list', 'titanworks-bazna-cijena' ) . '</label>';
		echo '</td></tr>';

		echo '</tbody></table>';
		echo '<p class="submit">';
		submit_button( $id ? __( 'Save service', 'titanworks-bazna-cijena' ) : __( 'Add service', 'titanworks-bazna-cijena' ), 'primary bazna-btn-busy', 'submit', false );

		if ( $id ) {
			echo ' <a class="button" href="' . esc_url( AdminMenu::url( self::SLUG ) ) . '">' . esc_html__( 'Cancel', 'titanworks-bazna-cijena' ) . '</a>';
		}

		echo '</p></form>';
	}

	/**
	 * Public services feed addresses.
	 *
	 * @return void
	 */
	protected static function render_feeds() {
		echo '<h2>' . esc_html__( 'Published services list', 'titanworks-bazna-cijena' ) . '</h2>';
		echo '<p>' . esc_html__( 'After the next generation the services list is available at:', 'titanworks-bazna-cijena' ) . '</p><ul class="bazna-services__feeds">';

		foreach ( array( 'csv', 'xml' ) as $extension ) {
			$url = home_url( '/' . PublicFeed::STEM . '-usluge.' . $extension );
			echo '<li><a href="' . esc_url( $url ) . '" target="_blank" rel="noopener"><code>' . esc_html( $url ) . '</code></a></li>';
		}

		echo '</ul>';
	}

	/**
	 * Save a service.
	 *
	 * @return void
	 */
	public static function handle_save() {
		if ( ! Capabilities::current_user_can() ) {
			wp_die( esc_html__( 'You do not have permission to perform this action.', 'titanworks-bazna-cijena' ) );
		}

		check_admin_referer( self::ACTION_SAVE );

		$id     = isset( $_POST['service_id'] ) ? absint( wp_unslash( $_POST['service_id'] ) ) : 0;
		$values = array(
			'name'        => isset( $_POST['name'] ) ? sanitize_text_field( wp_unslash( $_POST['name'] ) ) : '',
			'price'       => isset( $_POST['price'] ) ? sanitize_text_field( wp_unslash( $_POST['price'] ) ) : '',
			'base_price'  => isset( $_POST['base_price'] ) ? sanitize_text_field( wp_unslash( $_POST['base_price'] ) ) : '',
			'base_date'   => isset( $_POST['base_date'] ) ? sanitize_text_field( wp_unslash( $_POST['base_date'] ) ) : '',
			'base_reason' => isset( $_POST['base_reason'] ) ? sanitize_text_field( wp_unslash( $_POST['base_reason'] ) ) : '',
			'active'      => ! empty( $_POST['active'] ),
		);

		$data = $values;

		if ( '' === trim( $data['base_price'] ) ) {
			// A new service without its own base price starts at its price.
			$data['base_price'] = $id && Plugin::instance()->history()->latest( $id, 0, 'anchor' ) ? '' : $data['price'];
		}

		$result = ServiceManager::save( $data, $id );

		if ( is_wp_error( $result ) ) {
			$fields = array(
				'service_name_required'      => 'name',
				'service_price_required'     => 'price',
				'service_base_invalid'       => 'base_price',
				'service_base_date_invalid'  => 'base_price',
				'correction_reason_required' => 'base_reason',
			);
			$code   = (string) $result->get_error_code();
			$errors = isset( $fields[ $code ] ) ? array( $fields[ $code ] => $result->get_error_message() ) : array();

			FormState::store( 'service-form', $values, $errors );
			self::redirect( 'error', $result->get_error_message(), $id ? array( 'service' => $id ) : array() );
		}

		self::redirect( 'success', __( 'Service saved. The services price list is regenerated shortly.', 'titanworks-bazna-cijena' ) );
	}

	/**
	 * Switch a service on or off.
	 *
	 * @return void
	 */
	public static function handle_toggle() {
		if ( ! Capabilities::current_user_can() ) {
			wp_die( esc_html__( 'You do not have permission to perform this action.', 'titanworks-bazna-cijena' ) );
		}

		$id = isset( $_GET['service'] ) ? absint( wp_unslash( $_GET['service'] ) ) : 0;
		check_admin_referer( self::ACTION_TOGGLE . '_' . $id );

		$active = ! empty( $_GET['active'] );

		if ( ! ServiceManager::set_active( $id, $active ) ) {
			self::redirect( 'error', __( 'The service was not found.', 'titanworks-bazna-cijena' ) );
		}

		self::redirect( 'success', $active ? __( 'The service is listed again.', 'titanworks-bazna-cijena' ) : __( 'The service is no longer listed. Its price history is kept.', 'titanworks-bazna-cijena' ) );
	}

	/**
	 * Import selected shipping methods.
	 *
	 * @return void
	 */
	public static function handle_import() {
		if ( ! Capabilities::current_user_can() ) {
			wp_die( esc_html__( 'You do not have permission to perform this action.', 'titanworks-bazna-cijena' ) );
		}

		check_admin_referer( self::ACTION_IMPORT );

		$selected = isset( $_POST['shipping'] ) ? array_map( 'absint', (array) wp_unslash( $_POST['shipping'] ) ) : array();
		$date     = isset( $_POST['base_date'] ) ? sanitize_text_field( wp_unslash( $_POST['base_date'] ) ) : '';

		if ( empty( $selected ) ) {
			self::redirect( 'error', __( 'Select at least one shipping method.', 'titanworks-bazna-cijena' ) );
		}

		$summary = ServiceManager::import_shipping( $selected, $date );

		if ( ! empty( $summary['errors'] ) ) {
			self::redirect( 'error', implode( ' ', $summary['errors'] ) );
		}

		/* translators: %d: number of services. */
		self::redirect( 'success', sprintf( _n( '%d service imported.', '%d services imported.', $summary['created'], 'titanworks-bazna-cijena' ), $summary['created'] ) );
	}

	/**
	 * Nonced switch URL.
	 *
	 * @param int  $id     Service ID.
	 * @param bool $active Target state.
	 * @return string
	 */
	protected static function toggle_url( $id, $active ) {
		return wp_nonce_url(
			add_query_arg(
				array(
					'action'  => self::ACTION_TOGGLE,
					'service' => (int) $id,
					'active'  => $active ? 1 : 0,
				),
				admin_url( 'admin-post.php' )
			),
			self::ACTION_TOGGLE . '_' . (int) $id
		);
	}

	/**
	 * Redirect back with a notice.
	 *
	 * @param string              $type    `success` or `error`.
	 * @param string              $message Notice text.
	 * @param array<string,mixed> $args    Extra query args.
	 * @return void
	 */
	protected static function redirect( $type, $message, array $args = array() ) {
		wp_safe_redirect(
			add_query_arg(
				array_merge(
					array(
						'page'                     => self::SLUG,
						'twbce_cijena_notice'      => $type,
						'twbce_cijena_notice_text' => rawurlencode( $message ),
					),
					$args
				),
				admin_url( 'admin.php' )
			)
		);
		exit;
	}
}
