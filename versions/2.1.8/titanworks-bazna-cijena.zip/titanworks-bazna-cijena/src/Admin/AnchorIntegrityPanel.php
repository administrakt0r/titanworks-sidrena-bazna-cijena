<?php
/**
 * Base-price integrity panel on the compliance screen, and its admin notice.
 *
 * @package Titanworks\BaznaCijena\Admin
 */

namespace Titanworks\BaznaCijena\Admin;

use Titanworks\BaznaCijena\Plugin;
use Titanworks\BaznaCijena\Pricing\AnchorIntegrity;

defined( 'ABSPATH' ) || exit;

/**
 * Shows published items without a base price and base prices dated before
 * the item's first offer, with append-only repair actions.
 */
final class AnchorIntegrityPanel {

	const ACTION_SCAN = 'twbce_cijena_integrity_scan';

	const ACTION_FIX_MISSING = 'twbce_cijena_integrity_fix_missing';

	const ACTION_FIX_DATES = 'twbce_cijena_integrity_fix_dates';

	/**
	 * Register handlers.
	 *
	 * @return void
	 */
	public static function register() {
		add_action( 'admin_post_' . self::ACTION_SCAN, array( __CLASS__, 'handle_scan' ) );
		add_action( 'admin_post_' . self::ACTION_FIX_MISSING, array( __CLASS__, 'handle_fix_missing' ) );
		add_action( 'admin_post_' . self::ACTION_FIX_DATES, array( __CLASS__, 'handle_fix_dates' ) );
		add_action( 'admin_notices', array( __CLASS__, 'maybe_notice' ) );
	}

	/**
	 * Integrity service.
	 *
	 * @return AnchorIntegrity
	 */
	public static function service() {
		$plugin = Plugin::instance();

		return new AnchorIntegrity( $plugin->catalog(), $plugin->history(), $plugin->anchors() );
	}

	/**
	 * Cached summary of the last scan.
	 *
	 * @return array{missing:int,fixable:int,dates:int,checked_at:string}|null
	 */
	public static function summary() {
		$summary = get_option( AnchorIntegrity::OPTION );

		if ( ! is_array( $summary ) || ! isset( $summary['missing'] ) ) {
			return null;
		}

		return array(
			'missing'    => (int) $summary['missing'],
			'fixable'    => isset( $summary['fixable'] ) ? (int) $summary['fixable'] : 0,
			'dates'      => isset( $summary['dates'] ) ? (int) $summary['dates'] : 0,
			'checked_at' => isset( $summary['checked_at'] ) ? (string) $summary['checked_at'] : '',
		);
	}

	/**
	 * Render the panel.
	 *
	 * @return void
	 */
	public static function render() {
		$summary = self::summary();

		Notice::from_request();

		echo '<div class="bazna-integrity">';
		echo '<h2>' . esc_html__( 'Base price check', 'titanworks-bazna-cijena' ) . '</h2>';

		if ( ! $summary ) {
			echo '<p>' . esc_html__( 'Checks that every published product has a base price dated from the day it was first offered.', 'titanworks-bazna-cijena' ) . '</p>';
		} elseif ( 0 === $summary['missing'] && 0 === $summary['dates'] ) {
			echo '<p class="bazna-integrity__ok">' . esc_html__( 'Every published product has a base price.', 'titanworks-bazna-cijena' ) . '</p>';
		} else {
			echo '<ul class="bazna-integrity__list">';

			if ( $summary['missing'] > 0 ) {
				echo '<li>' . esc_html(
					sprintf(
						/* translators: 1: items without a base price, 2: items that can be filled in automatically. */
						__( '%1$d published products have no base price. %2$d of them were first offered after the reference date and can be filled in from that day\'s regular price.', 'titanworks-bazna-cijena' ),
						$summary['missing'],
						$summary['fixable']
					)
				) . '</li>';
			}

			if ( $summary['dates'] > 0 ) {
				echo '<li>' . esc_html(
					sprintf(
						/* translators: %d: item count. */
						__( '%d base prices carry a date before the product was first offered. The label should show the first-offer date.', 'titanworks-bazna-cijena' ),
						$summary['dates']
					)
				) . '</li>';
			}

			echo '</ul>';
		}

		echo '<div class="bazna-integrity__actions">';
		self::form( self::ACTION_SCAN, __( 'Check now', 'titanworks-bazna-cijena' ), 'secondary' );

		if ( $summary && $summary['fixable'] > 0 ) {
			self::form( self::ACTION_FIX_MISSING, __( 'Fill in missing base prices', 'titanworks-bazna-cijena' ), 'primary' );
		}

		echo '</div>';

		if ( $summary && $summary['dates'] > 0 ) {
			echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" class="bazna-busy-form bazna-integrity__dates">';
			echo '<input type="hidden" name="action" value="' . esc_attr( self::ACTION_FIX_DATES ) . '" />';
			wp_nonce_field( self::ACTION_FIX_DATES );
			echo '<label for="twbce-integrity-reason">' . esc_html__( 'Reason for the date correction', 'titanworks-bazna-cijena' ) . '</label> ';
			echo '<input type="text" class="regular-text" id="twbce-integrity-reason" name="reason" required minlength="5" value="' . esc_attr__( 'Base price date set to the first-offer date', 'titanworks-bazna-cijena' ) . '" /> ';
			submit_button( __( 'Correct base price dates', 'titanworks-bazna-cijena' ), 'secondary bazna-btn-busy', 'submit', false );
			echo '<p class="description">' . esc_html__( 'Adds a correction record with the same price and the first-offer date. Prices are never changed; earlier records stay in the history.', 'titanworks-bazna-cijena' ) . '</p>';
			echo '</form>';
		}

		echo '<p class="description">' . esc_html__( 'Base prices are also recorded automatically when a product is published for the first time. WP-CLI: wp bazna-cijena integrity [--fix-missing] [--fix-dates --reason="..."] [--dry-run]', 'titanworks-bazna-cijena' ) . '</p>';
		echo '</div>';
	}

	/**
	 * One-button admin-post form.
	 *
	 * @param string $action Action.
	 * @param string $label  Button label.
	 * @param string $type   Button type.
	 * @return void
	 */
	private static function form( $action, $label, $type ) {
		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" class="bazna-busy-form">';
		echo '<input type="hidden" name="action" value="' . esc_attr( $action ) . '" />';
		wp_nonce_field( $action );
		submit_button( $label, $type . ' bazna-btn-busy', 'submit', false );
		echo '</form>';
	}

	/**
	 * Re-scan.
	 *
	 * @return void
	 */
	public static function handle_scan() {
		self::guard( self::ACTION_SCAN );
		$scan = self::service()->scan();

		self::back(
			( $scan['missing'] || $scan['dates'] ) ? 'warning' : 'success',
			sprintf(
				/* translators: 1: checked items, 2: missing, 3: dates. */
				__( 'Checked %1$d published items: %2$d without a base price, %3$d with a date before the first offer.', 'titanworks-bazna-cijena' ),
				$scan['checked'],
				count( $scan['missing'] ),
				count( $scan['dates'] )
			)
		);
	}

	/**
	 * Record missing base prices.
	 *
	 * @return void
	 */
	public static function handle_fix_missing() {
		self::guard( self::ACTION_FIX_MISSING );
		$result = self::service()->fix_missing();

		if ( ! empty( $result['failed'] ) ) {
			self::back(
				'error',
				sprintf(
					/* translators: 1: recorded, 2: failed writes. */
					__( 'Recorded %1$d base prices, but %2$d could not be saved. Check the log and run the repair again.', 'titanworks-bazna-cijena' ),
					$result['recorded'],
					$result['failed']
				)
			);
		}

		self::back(
			$result['skipped'] ? 'warning' : 'success',
			sprintf(
				/* translators: 1: recorded, 2: still needing manual entry. */
				__( 'Recorded %1$d base prices from the first-offer date. %2$d still need a price entered by hand.', 'titanworks-bazna-cijena' ),
				$result['recorded'],
				$result['skipped']
			)
		);
	}

	/**
	 * Correct base-price dates.
	 *
	 * @return void
	 */
	public static function handle_fix_dates() {
		self::guard( self::ACTION_FIX_DATES );
		$reason = isset( $_POST['reason'] ) ? sanitize_text_field( wp_unslash( $_POST['reason'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Checked in guard().
		$result = self::service()->correct_dates( $reason );

		if ( is_wp_error( $result ) ) {
			self::back( 'error', $result->get_error_message() );
		}

		if ( ! empty( $result['failed'] ) ) {
			self::back(
				'error',
				sprintf(
					/* translators: 1: corrected, 2: failed writes. */
					__( 'Corrected %1$d base price dates, but %2$d could not be saved. Check the log and run the correction again.', 'titanworks-bazna-cijena' ),
					$result['corrected'],
					$result['failed']
				)
			);
		}

		self::back(
			'success',
			sprintf(
				/* translators: %d: corrected records. */
				__( 'Corrected %d base price dates. Prices are unchanged.', 'titanworks-bazna-cijena' ),
				$result['corrected']
			)
		);
	}

	/**
	 * Admin notice on plugin screens and the product list.
	 *
	 * @return void
	 */
	public static function maybe_notice() {
		if ( ! Capabilities::current_user_can() ) {
			return;
		}

		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Screen detection only.
		$page = isset( $_GET['page'] ) ? sanitize_key( wp_unslash( $_GET['page'] ) ) : '';

		if ( 'bazna-cijena-compliance' === $page ) {
			return;
		}

		$screen   = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
		$products = $screen && 'edit-product' === $screen->id;

		if ( ! $products && ! AdminMenu::is_plugin_screen() ) {
			return;
		}

		$summary = self::summary();

		if ( ! $summary || $summary['missing'] < 1 ) {
			return;
		}

		printf(
			'<div class="notice notice-warning"><p>%s <a href="%s">%s</a></p></div>',
			esc_html(
				sprintf(
					/* translators: %d: item count. */
					_n( '%d published product has no base price.', '%d published products have no base price.', $summary['missing'], 'titanworks-bazna-cijena' ),
					$summary['missing']
				)
			),
			esc_url( AdminMenu::url( 'bazna-cijena-compliance' ) ),
			esc_html__( 'Review and fill in', 'titanworks-bazna-cijena' )
		);
	}

	/**
	 * Capability and nonce check.
	 *
	 * @param string $action Action.
	 * @return void
	 */
	private static function guard( $action ) {
		if ( ! Capabilities::current_user_can() ) {
			wp_die( esc_html__( 'You do not have permission to change base prices.', 'titanworks-bazna-cijena' ) );
		}

		check_admin_referer( $action );
	}

	/**
	 * Redirect back to the compliance screen with a notice.
	 *
	 * @param string $type    Notice type.
	 * @param string $message Message.
	 * @return void
	 */
	private static function back( $type, $message ) {
		wp_safe_redirect(
			add_query_arg(
				array(
					'twbce_cijena_notice'      => $type,
					'twbce_cijena_notice_text' => rawurlencode( $message ),
				),
				AdminMenu::url( 'bazna-cijena-compliance' )
			)
		);
		exit;
	}
}
