<?php
/**
 * First-run setup wizard.
 *
 * @package Titanworks\BaznaCijena\Admin
 */

namespace Titanworks\BaznaCijena\Admin;

use Titanworks\BaznaCijena\Compliance\RuleConfig;
use Titanworks\BaznaCijena\Export\FilenameGenerator;
use Titanworks\BaznaCijena\Plugin;
use Titanworks\BaznaCijena\Services\ServiceCatalog;
use Titanworks\BaznaCijena\Services\ServiceManager;
use Titanworks\BaznaCijena\Support\Dates;
use Titanworks\BaznaCijena\Support\Labels;
use Titanworks\BaznaCijena\Support\Settings;

defined( 'ABSPATH' ) || exit;

/**
 * Step-by-step wizard that configures the plugin in the right order.
 *
 * Each step saves its own small form, so a shop owner never has to find the
 * matching field on the full settings screens during the first setup.
 */
final class SetupGuidePage {

	/**
	 * Page slug.
	 */
	const SLUG = 'bazna-cijena-setup';

	/**
	 * Completion flag.
	 */
	const COMPLETE_OPTION = 'twbce_cijena_setup_complete';

	/**
	 * Flag: the merchant confirmed they sell no legacy-date categories.
	 */
	const NO_LEGACY_OPTION = 'twbce_cijena_setup_no_legacy';

	/**
	 * Flag: the merchant has answered the credit-link question once.
	 */
	const CREDIT_ASKED_OPTION = 'twbce_cijena_setup_credit_asked';

	/**
	 * Set when the shop confirmed it charges for no services.
	 */
	const NO_SERVICES_OPTION = 'twbce_cijena_setup_no_services';

	/**
	 * Actions.
	 */
	const COMPLETE_ACTION = 'twbce_cijena_setup_complete';
	const REOPEN_ACTION   = 'twbce_cijena_setup_reopen';
	const SAVE_ACTION     = 'twbce_cijena_setup_save';

	/**
	 * Register hooks.
	 *
	 * @return void
	 */
	public static function register() {
		add_action( 'admin_post_' . self::COMPLETE_ACTION, array( __CLASS__, 'handle_complete' ) );
		add_action( 'admin_post_' . self::REOPEN_ACTION, array( __CLASS__, 'handle_reopen' ) );
		add_action( 'admin_post_' . self::SAVE_ACTION, array( __CLASS__, 'handle_save' ) );
	}

	/**
	 * Ordered setup steps (pure, unit-testable).
	 *
	 * @return array<int,array{key:string,title:string,short:string,description:string}>
	 */
	public static function steps() {
		return array(
			array(
				'key'         => 'locations',
				'title'       => __( '1. Add sales locations', 'titanworks-bazna-cijena' ),
				'short'       => __( 'Business', 'titanworks-bazna-cijena' ),
				'description' => __( 'Your OIB and the address of your sales location build the statutory price-list filename. One location is enough for a webshop; add physical shops later under Sales locations.', 'titanworks-bazna-cijena' ),
			),
			array(
				'key'         => 'rules',
				'title'       => __( '2. Check legal rules', 'titanworks-bazna-cijena' ),
				'short'       => __( 'Categories', 'titanworks-bazna-cijena' ),
				'description' => __( 'Most products use 10 September 2026 as the reference date. Food, beverages, cosmetics, cleaning, toiletries and household products keep 2 May 2025. Tick the categories that sell these products; the plugin never guesses them.', 'titanworks-bazna-cijena' ),
			),
			array(
				'key'         => 'anchors',
				'title'       => __( '3. Record anchor prices', 'titanworks-bazna-cijena' ),
				'short'       => __( 'Prices', 'titanworks-bazna-cijena' ),
				'description' => __( 'Enter evidenced prices for existing products or import them by CSV. New products published with this plugin active capture their first offer automatically.', 'titanworks-bazna-cijena' ),
			),
			array(
				'key'         => 'services',
				'title'       => __( '4. Add paid services', 'titanworks-bazna-cijena' ),
				'short'       => __( 'Services', 'titanworks-bazna-cijena' ),
				'description' => __( 'Delivery and other services you charge consumers for get their own services price list (USLUGE) with a base price. Import your WooCommerce shipping methods or add services by hand.', 'titanworks-bazna-cijena' ),
			),
			array(
				'key'         => 'lists',
				'title'       => __( '5. Generate the price list', 'titanworks-bazna-cijena' ),
				'short'       => __( 'Storefront', 'titanworks-bazna-cijena' ),
				'description' => __( 'Choose how the base price appears in your shop, then publish the first CSV/XML price list. Lists regenerate shortly after each price change and daily before 11:00.', 'titanworks-bazna-cijena' ),
			),
			array(
				'key'         => 'check',
				'title'       => __( '6. Run the compliance check', 'titanworks-bazna-cijena' ),
				'short'       => __( 'Check', 'titanworks-bazna-cijena' ),
				'description' => __( 'Fix ERROR findings before publishing: missing anchors, missing addresses and unclassified promotions block the price list.', 'titanworks-bazna-cijena' ),
			),
		);
	}

	/**
	 * Whether setup was marked complete.
	 *
	 * @return bool
	 */
	public static function is_complete() {
		return (bool) get_option( self::COMPLETE_OPTION, false );
	}

	/**
	 * Current completion status of every setup step.
	 *
	 * @return array<string,array<string,mixed>> Keyed by step key.
	 */
	public static function statuses() {
		$plugin       = Plugin::instance();
		$locations    = $plugin->locations()->all();
		$rule         = RuleConfig::all();
		$total        = (int) $plugin->catalog()->count_items();
		$last         = $plugin->publications()->last_successful();
		$anchor_count = (int) $plugin->history()->count( array( 'price_type' => 'anchor' ) );
		$report       = CompliancePage::stored_report();
		$no_legacy    = (bool) get_option( self::NO_LEGACY_OPTION, false );
		$no_services  = (bool) get_option( self::NO_SERVICES_OPTION, false );
		$services_on  = ServiceCatalog::enabled();
		$services     = $services_on ? count( ServiceCatalog::posts() ) : 0;

		$legacy_slugs = isset( $rule['legacy_category_slugs'] ) ? array_filter( array_map( 'strval', (array) $rule['legacy_category_slugs'] ) ) : array();

		if ( $anchor_count <= 0 ) {
			$anchor_badge = __( '(none recorded)', 'titanworks-bazna-cijena' );
		} elseif ( $total > $anchor_count ) {
			$anchor_badge = sprintf(
				/* translators: 1: recorded anchors, 2: catalog items. */
				__( '(done: %1$d of %2$d recorded)', 'titanworks-bazna-cijena' ),
				$anchor_count,
				$total
			);
		} else {
			$anchor_badge = sprintf(
				/* translators: %d: count of recorded anchors. */
				__( '(done: %d recorded)', 'titanworks-bazna-cijena' ),
				$anchor_count
			);
		}

		$error_count = is_array( $report ) && isset( $report['counts']['ERROR'] ) ? (int) $report['counts']['ERROR'] : null;

		if ( null === $error_count ) {
			$check_badge = __( '(not run yet)', 'titanworks-bazna-cijena' );
		} else {
			$check_badge = $error_count > 0 ? __( '(errors found)', 'titanworks-bazna-cijena' ) : __( '(clean)', 'titanworks-bazna-cijena' );
		}

		$rules_complete = ! empty( $legacy_slugs ) || $no_legacy;
		$has_oib        = '' !== FilenameGenerator::merchant_id();

		if ( empty( $locations ) ) {
			$locations_badge = __( '(missing)', 'titanworks-bazna-cijena' );
		} else {
			$locations_badge = $has_oib ? __( '(done)', 'titanworks-bazna-cijena' ) : __( '(add your OIB)', 'titanworks-bazna-cijena' );
		}

		return array(
			'locations' => array(
				'complete' => ! empty( $locations ) && $has_oib,
				'badge'    => $locations_badge,
				'count'    => count( $locations ),
				'oib'      => $has_oib,
			),
			'rules'     => array(
				'complete'               => $rules_complete,
				'badge'                  => $rules_complete ? __( '(done)', 'titanworks-bazna-cijena' ) : __( '(map your categories)', 'titanworks-bazna-cijena' ),
				'slugs'                  => array_values( $legacy_slugs ),
				'no_legacy'              => $no_legacy,
				'general_reference_date' => isset( $rule['general_reference_date'] ) ? (string) $rule['general_reference_date'] : '',
				'legacy_reference_date'  => isset( $rule['legacy_reference_date'] ) ? (string) $rule['legacy_reference_date'] : '',
			),
			'anchors'   => array(
				'complete' => $anchor_count > 0,
				'badge'    => $anchor_badge,
				'count'    => $anchor_count,
				'total'    => $total,
			),
			'services'  => array(
				'complete' => $services > 0 || $no_services || ! $services_on,
				'badge'    => self::services_badge( $services, $no_services, $services_on ),
				'count'    => $services,
				'none'     => $no_services,
			),
			'lists'     => array(
				'complete' => (bool) $last,
				'badge'    => $last ? __( '(published)', 'titanworks-bazna-cijena' ) : __( '(not published yet)', 'titanworks-bazna-cijena' ),
			),
			'check'     => array(
				'complete' => null !== $error_count && 0 === $error_count,
				'badge'    => $check_badge,
				'errors'   => $error_count,
			),
		);
	}

	/**
	 * The step shown on this request.
	 *
	 * An explicit `step` query value wins; otherwise the first incomplete step.
	 *
	 * @param array<string,array<string,mixed>> $statuses Step statuses.
	 * @return string
	 */
	public static function current_step( array $statuses ) {
		$keys = array_column( self::steps(), 'key' );

		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only navigation.
		$requested = isset( $_GET['step'] ) ? sanitize_key( wp_unslash( $_GET['step'] ) ) : '';

		if ( in_array( $requested, $keys, true ) ) {
			return $requested;
		}

		foreach ( $keys as $key ) {
			if ( empty( $statuses[ $key ]['complete'] ) ) {
				return $key;
			}
		}

		return 'check';
	}

	/**
	 * URL of one wizard step.
	 *
	 * @param string $key Step key.
	 * @return string
	 */
	public static function step_url( $key ) {
		return AdminMenu::url( self::SLUG, array( 'step' => $key ) );
	}

	/**
	 * Render the screen.
	 *
	 * @return void
	 */
	public static function render() {
		if ( ! Capabilities::current_user_can() ) {
			wp_die( esc_html__( 'You do not have permission to access this page.', 'titanworks-bazna-cijena' ) );
		}

		$statuses = self::statuses();
		$complete = self::is_complete();
		$steps    = self::steps();
		$current  = self::current_step( $statuses );
		$done     = count( array_filter( array_column( $statuses, 'complete' ) ) );

		echo '<div class="wrap bazna-setup">';
		echo '<h1>' . esc_html__( 'Bazna cijena: Setup Guide', 'titanworks-bazna-cijena' ) . '</h1>';
		AdminMenu::render_tabs( self::SLUG );
		echo '<p class="bazna-setup__lead">' . esc_html__( 'A few short steps get your shop compliant with the Croatian base price and price list rules. Every step can be changed later.', 'titanworks-bazna-cijena' ) . '</p>';

		Notice::from_request();

		if ( $complete ) {
			echo '<div class="notice notice-success inline"><p>' . esc_html__( 'Setup is marked complete. Reopen it any time you add locations or categories.', 'titanworks-bazna-cijena' ) . '</p></div>';
		}

		printf(
			'<div class="bazna-setup__progress" role="progressbar" aria-valuemin="0" aria-valuemax="%4$d" aria-valuenow="%1$d" aria-label="%2$s"><span style="width:%3$d%%"></span></div>',
			(int) $done,
			esc_attr__( 'Setup progress', 'titanworks-bazna-cijena' ),
			(int) round( $done / max( 1, count( $steps ) ) * 100 ),
			(int) count( $steps )
		);

		echo '<ol class="bazna-setup__nav">';

		foreach ( $steps as $index => $step ) {
			$status  = $statuses[ $step['key'] ];
			$classes = array( 'bazna-setup__nav-item' );

			if ( ! empty( $status['complete'] ) ) {
				$classes[] = 'is-done';
			}

			if ( $current === $step['key'] ) {
				$classes[] = 'is-current';
			}

			printf(
				'<li class="%1$s"><a href="%2$s"%3$s><span class="bazna-setup__nav-num">%4$s</span><span class="bazna-setup__nav-text"><strong>%5$s</strong> <span class="bazna-setup__nav-badge">%6$s</span></span></a></li>',
				esc_attr( implode( ' ', $classes ) ),
				esc_url( self::step_url( $step['key'] ) ),
				$current === $step['key'] ? ' aria-current="step"' : '',
				! empty( $status['complete'] ) ? '&#10003;' : (int) ( $index + 1 ),
				esc_html( $step['short'] ),
				esc_html( (string) $status['badge'] )
			);
		}

		echo '</ol>';

		foreach ( $steps as $index => $step ) {
			if ( $current !== $step['key'] ) {
				continue;
			}

			echo '<section class="bazna-setup__panel" aria-labelledby="bazna-setup-step-title">';
			printf(
				'<h2 id="bazna-setup-step-title">%1$s <span class="bazna-setup__badge">%2$s</span></h2>',
				esc_html( $step['title'] ),
				esc_html( (string) $statuses[ $step['key'] ]['badge'] )
			);
			echo '<p class="bazna-setup__desc">' . esc_html( $step['description'] ) . '</p>';

			$method = 'render_step_' . $step['key'];
			self::$method( $statuses );

			$prev = $index > 0 ? $steps[ $index - 1 ]['key'] : '';
			$next = isset( $steps[ $index + 1 ] ) ? $steps[ $index + 1 ]['key'] : '';

			echo '<p class="bazna-setup__pager">';

			if ( $prev ) {
				printf( '<a class="button-link" href="%1$s">&larr; %2$s</a>', esc_url( self::step_url( $prev ) ), esc_html__( 'Back', 'titanworks-bazna-cijena' ) );
			}

			if ( $next ) {
				printf( '<a class="button-link bazna-setup__skip" href="%1$s">%2$s &rarr;</a>', esc_url( self::step_url( $next ) ), esc_html__( 'Skip for now', 'titanworks-bazna-cijena' ) );
			}

			echo '</p></section>';
		}

		self::render_overview( $statuses );
		self::render_completion( $complete );
		self::render_projects();

		echo '</div>';
	}

	/**
	 * Compact read-only list of every step and its status.
	 *
	 * @param array<string,array<string,mixed>> $statuses Step statuses.
	 * @return void
	 */
	protected static function render_overview( array $statuses ) {
		echo '<details class="bazna-setup__overview"><summary>' . esc_html__( 'All steps at a glance', 'titanworks-bazna-cijena' ) . '</summary><ul>';

		foreach ( self::steps() as $step ) {
			printf(
				'<li><a href="%1$s">%2$s</a> %3$s</li>',
				esc_url( self::step_url( $step['key'] ) ),
				esc_html( $step['title'] ),
				esc_html( (string) $statuses[ $step['key'] ]['badge'] )
			);
		}

		echo '</ul></details>';
	}

	/**
	 * Open a wizard save form.
	 *
	 * @param string $step Step key.
	 * @return void
	 */
	protected static function open_form( $step ) {
		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" class="bazna-setup__form bazna-busy-form">';
		wp_nonce_field( self::SAVE_ACTION );
		echo '<input type="hidden" name="action" value="' . esc_attr( self::SAVE_ACTION ) . '" />';
		echo '<input type="hidden" name="step" value="' . esc_attr( $step ) . '" />';
	}

	/**
	 * Step 1: business identity and first sales location.
	 *
	 * @param array<string,array<string,mixed>> $statuses Step statuses.
	 * @return void
	 */
	protected static function render_step_locations( array $statuses ) {
		$locations = Plugin::instance()->locations()->all();
		$location  = $locations ? reset( $locations ) : array();
		$oib       = (string) Settings::get( 'merchant_oib', '' );
		$id_type   = (string) Settings::get( 'merchant_id_type', 'oib' );

		self::open_form( 'locations' );

		echo '<fieldset class="bazna-setup__group"><legend>' . esc_html__( 'Your business', 'titanworks-bazna-cijena' ) . '</legend>';
		printf(
			'<p><label for="bazna-setup-oib">%1$s</label><br /><input type="text" id="bazna-setup-oib" name="merchant_oib" value="%2$s" class="regular-text" inputmode="numeric" maxlength="13" autocomplete="off" required /></p>',
			esc_html__( 'Merchant OIB', 'titanworks-bazna-cijena' ),
			esc_attr( $oib )
		);

		if ( '' !== $oib && empty( $statuses['locations']['oib'] ) ) {
			echo '<p class="bazna-setup__error">' . esc_html__( 'This value fails the OIB check digit (ISO 7064 MOD 11,10).', 'titanworks-bazna-cijena' ) . '</p>';
		}

		printf(
			'<p><label for="bazna-setup-id-type">%1$s</label><br /><select id="bazna-setup-id-type" name="merchant_id_type"><option value="oib"%2$s>%3$s</option><option value="mbg"%4$s>%5$s</option></select></p>',
			esc_html__( 'Identifier type', 'titanworks-bazna-cijena' ),
			selected( $id_type, 'oib', false ),
			esc_html__( 'OIB (legal entity, 11 digits)', 'titanworks-bazna-cijena' ),
			selected( $id_type, 'mbg', false ),
			esc_html__( 'Registration number (natural person)', 'titanworks-bazna-cijena' )
		);
		echo '</fieldset>';

		echo '<fieldset class="bazna-setup__group"><legend>' . esc_html__( 'Sales location', 'titanworks-bazna-cijena' ) . '</legend>';
		echo '<input type="hidden" name="location_id" value="' . esc_attr( (string) ( isset( $location['id'] ) ? (int) $location['id'] : 0 ) ) . '" />';

		$type = isset( $location['type'] ) ? (string) $location['type'] : 'webshop';

		echo '<p><label for="bazna-setup-loc-type">' . esc_html__( 'Facility form', 'titanworks-bazna-cijena' ) . '</label><br /><select id="bazna-setup-loc-type" name="location[type]">';

		foreach ( array( 'webshop', 'prodavaonica', 'poslovnica', 'usluzno_mjesto' ) as $choice ) {
			printf( '<option value="%1$s"%2$s>%3$s</option>', esc_attr( $choice ), selected( $type, $choice, false ), esc_html( Labels::location_type( $choice ) ) );
		}

		echo '</select></p>';

		$fields = array(
			'name'       => array( __( 'Location name', 'titanworks-bazna-cijena' ), '' ),
			'address'    => array( __( 'Street address', 'titanworks-bazna-cijena' ), '' ),
			'city'       => array( __( 'City', 'titanworks-bazna-cijena' ), '' ),
			'identifier' => array( __( 'Facility identifier', 'titanworks-bazna-cijena' ), __( 'Short unique code, for example P1. It appears in the price-list filename.', 'titanworks-bazna-cijena' ) ),
		);

		echo '<div class="bazna-setup__grid">';

		foreach ( $fields as $key => $field ) {
			printf(
				'<p><label for="bazna-setup-loc-%1$s">%2$s</label><br /><input type="text" id="bazna-setup-loc-%1$s" name="location[%1$s]" value="%3$s" class="regular-text" required />%4$s</p>',
				esc_attr( $key ),
				esc_html( $field[0] ),
				esc_attr( isset( $location[ $key ] ) ? (string) $location[ $key ] : '' ),
				'' !== $field[1] ? '<span class="description">' . esc_html( $field[1] ) . '</span>' : ''
			);
		}

		echo '</div>';

		if ( count( $locations ) > 1 ) {
			printf(
				'<p class="description">%1$s <a href="%2$s">%3$s</a></p>',
				/* translators: %d: number of sales locations. */
				esc_html( sprintf( __( 'You have %d sales locations. This form edits the first one.', 'titanworks-bazna-cijena' ), count( $locations ) ) ),
				esc_url( AdminMenu::url( LocationsPage::SLUG ) ),
				esc_html__( 'Manage locations', 'titanworks-bazna-cijena' )
			);
		}

		echo '</fieldset>';

		submit_button( __( 'Save and continue', 'titanworks-bazna-cijena' ), 'primary bazna-btn-busy', 'submit', false );
		echo '</form>';
	}

	/**
	 * Step 2: legacy-date category mapping.
	 *
	 * @param array<string,array<string,mixed>> $statuses Step statuses.
	 * @return void
	 */
	protected static function render_step_rules( array $statuses ) {
		$selected   = array_map( 'strval', (array) $statuses['rules']['slugs'] );
		$categories = Plugin::instance()->catalog()->get_categories();

		printf(
			'<p class="bazna-setup__facts">%1$s: <strong>%2$s</strong> &middot; %3$s: <strong>%4$s</strong></p>',
			esc_html__( 'General reference date', 'titanworks-bazna-cijena' ),
			esc_html( Dates::format_date_display( (string) $statuses['rules']['general_reference_date'] ) ),
			esc_html__( 'Legacy reference date', 'titanworks-bazna-cijena' ),
			esc_html( Dates::format_date_display( (string) $statuses['rules']['legacy_reference_date'] ) )
		);

		self::open_form( 'rules' );

		echo '<fieldset class="bazna-setup__group"><legend>' . esc_html__( 'Categories that use 2 May 2025', 'titanworks-bazna-cijena' ) . '</legend>';

		if ( empty( $categories ) ) {
			echo '<p><em>' . esc_html__( 'No catalog categories are available.', 'titanworks-bazna-cijena' ) . '</em></p>';
		} else {
			echo '<div class="bazna-setup__checks">';

			foreach ( $categories as $category ) {
				$slug = (string) $category['slug'];
				printf(
					'<label><input type="checkbox" name="legacy_category_slugs[]" value="%1$s"%2$s /> %3$s</label>',
					esc_attr( $slug ),
					checked( in_array( $slug, $selected, true ), true, false ),
					esc_html( (string) $category['name'] )
				);
			}

			echo '</div>';
		}

		printf(
			'<p><label><input type="checkbox" name="no_legacy" value="1"%1$s /> %2$s</label></p>',
			checked( ! empty( $statuses['rules']['no_legacy'] ), true, false ),
			esc_html__( 'I do not sell any of these product groups.', 'titanworks-bazna-cijena' )
		);
		echo '</fieldset>';

		submit_button( __( 'Save and continue', 'titanworks-bazna-cijena' ), 'primary bazna-btn-busy', 'submit', false );
		printf( ' <a class="button-link" href="%1$s">%2$s</a>', esc_url( AdminMenu::url( 'bazna-cijena-settings', array( 'tab' => 'legal' ) ) ), esc_html__( 'Open legal rules', 'titanworks-bazna-cijena' ) );
		echo '</form>';
	}

	/**
	 * Step 3: anchor prices.
	 *
	 * @param array<string,array<string,mixed>> $statuses Step statuses.
	 * @return void
	 */
	protected static function render_step_anchors( array $statuses ) {
		$total = (int) $statuses['anchors']['total'];
		$count = (int) $statuses['anchors']['count'];

		printf(
			'<p class="bazna-setup__facts">%1$s: <strong>%2$d</strong> &middot; %3$s: <strong>%4$d</strong></p>',
			esc_html__( 'Catalog items', 'titanworks-bazna-cijena' ),
			(int) $total,
			esc_html__( 'Anchors recorded', 'titanworks-bazna-cijena' ),
			(int) $count
		);

		echo '<ul class="bazna-setup__choices">';
		printf(
			'<li><a class="bazna-setup__choice" href="%1$s"><strong>%2$s</strong><span>%3$s</span></a></li>',
			esc_url( AdminMenu::url( 'bazna-cijena-anchors' ) ),
			esc_html__( 'Enter anchors', 'titanworks-bazna-cijena' ),
			esc_html__( 'Type prices in a table, a few products at a time.', 'titanworks-bazna-cijena' )
		);
		printf(
			'<li><a class="bazna-setup__choice" href="%1$s"><strong>%2$s</strong><span>%3$s</span></a></li>',
			esc_url( AdminMenu::url( 'bazna-cijena-import' ) ),
			esc_html__( 'Import CSV', 'titanworks-bazna-cijena' ),
			esc_html__( 'Upload a spreadsheet; you see a preview before anything is saved.', 'titanworks-bazna-cijena' )
		);
		echo '</ul>';

		printf( '<p><a class="button button-primary" href="%1$s">%2$s</a></p>', esc_url( self::step_url( 'services' ) ), esc_html__( 'Continue', 'titanworks-bazna-cijena' ) );
	}

	/**
	 * Badge of the services step.
	 *
	 * @param int  $count       Listed services.
	 * @param bool $none        Shop confirmed it charges for no services.
	 * @param bool $enabled     Services switched on.
	 * @return string
	 */
	protected static function services_badge( $count, $none, $enabled ) {
		if ( ! $enabled ) {
			return __( '(switched off)', 'titanworks-bazna-cijena' );
		}

		if ( $count > 0 ) {
			/* translators: %d: number of listed services. */
			return sprintf( __( '(done: %d listed)', 'titanworks-bazna-cijena' ), $count );
		}

		return $none ? __( '(no paid services)', 'titanworks-bazna-cijena' ) : __( '(not set up)', 'titanworks-bazna-cijena' );
	}

	/**
	 * Step 4: paid services such as delivery.
	 *
	 * @param array<string,array<string,mixed>> $statuses Step statuses.
	 * @return void
	 */
	protected static function render_step_services( array $statuses ) {
		$count = (int) $statuses['services']['count'];

		if ( $count > 0 ) {
			printf(
				'<p class="bazna-setup__facts">%1$s: <strong>%2$d</strong></p>',
				esc_html__( 'Services listed', 'titanworks-bazna-cijena' ),
				(int) $count
			);
		}

		self::open_form( 'services' );

		echo '<fieldset class="bazna-setup__group"><legend>' . esc_html__( 'Delivery from WooCommerce', 'titanworks-bazna-cijena' ) . '</legend>';

		if ( ServicesPage::render_shipping_choices() ) {
			echo '<p class="description">' . esc_html__( 'Paid methods are selected for you. Their prices keep following WooCommerce.', 'titanworks-bazna-cijena' ) . '</p>';
			echo '<p><label for="bazna-setup-service-date"><strong>' . esc_html__( 'Base price date', 'titanworks-bazna-cijena' ) . '</strong></label><br />';
			ServicesPage::render_base_date_field( 'bazna-setup-service-date' );
			echo '</p>';
		} else {
			echo '<p>' . esc_html__( 'No shipping method left to import.', 'titanworks-bazna-cijena' ) . '</p>';
		}

		echo '</fieldset>';

		if ( 0 === $count ) {
			printf(
				'<p><label><input type="checkbox" name="no_services" value="1"%1$s /> %2$s</label></p>',
				checked( ! empty( $statuses['services']['none'] ), true, false ),
				esc_html__( 'I do not charge consumers for delivery or any other service.', 'titanworks-bazna-cijena' )
			);
		}

		echo '<p class="bazna-setup__actions">';
		submit_button( __( 'Save and continue', 'titanworks-bazna-cijena' ), 'primary bazna-btn-busy', 'submit', false );
		printf( ' <a href="%1$s">%2$s</a>', esc_url( AdminMenu::url( ServicesPage::SLUG ) ), esc_html__( 'Add other services by hand', 'titanworks-bazna-cijena' ) );
		echo '</p></form>';
	}

	/**
	 * Step 4: storefront display, credit opt-in and first publication.
	 *
	 * @param array<string,array<string,mixed>> $statuses Step statuses.
	 * @return void
	 */
	protected static function render_step_lists( array $statuses ) {
		$label   = (string) Settings::get( 'anchor_label', '' );
		$presets = Settings::anchor_label_presets();
		$asked   = (bool) get_option( self::CREDIT_ASKED_OPTION, false );
		$credit  = $asked ? (bool) Settings::get( 'public_credit_link', false ) : true;

		self::open_form( 'lists' );

		echo '<fieldset class="bazna-setup__group"><legend>' . esc_html__( 'Storefront', 'titanworks-bazna-cijena' ) . '</legend>';
		printf(
			'<p><label><input type="checkbox" name="display_enabled" value="1"%1$s /> %2$s</label></p>',
			checked( (bool) Settings::get( 'display_enabled', true ), true, false ),
			esc_html__( 'Show the base price next to product prices', 'titanworks-bazna-cijena' )
		);

		echo '<p>' . esc_html__( 'Label', 'titanworks-bazna-cijena' ) . '</p><div class="bazna-setup__checks">';

		$matched = false;

		foreach ( $presets as $text ) {
			$is      = $label === $text;
			$matched = $matched || $is;
			printf(
				'<label><input type="radio" name="anchor_label" value="%1$s"%2$s /> %3$s</label>',
				esc_attr( $text ),
				checked( $is, true, false ),
				esc_html( $text )
			);
		}

		if ( ! $matched && '' !== $label ) {
			printf( '<label><input type="radio" name="anchor_label" value="%1$s" checked="checked" /> %2$s</label>', esc_attr( $label ), esc_html( $label ) );
		}

		echo '</div>';
		printf( '<p class="description">%1$s <a href="%2$s">%3$s</a></p>', esc_html__( 'Colours, size and position are in the settings.', 'titanworks-bazna-cijena' ), esc_url( AdminMenu::url( 'bazna-cijena-settings', array( 'tab' => 'styling' ) ) ), esc_html__( 'Open styling', 'titanworks-bazna-cijena' ) );
		echo '</fieldset>';

		echo '<fieldset class="bazna-setup__group"><legend>' . esc_html__( 'Support the author', 'titanworks-bazna-cijena' ) . '</legend>';
		printf(
			'<p><label><input type="checkbox" name="public_credit_link" value="1"%1$s /> %2$s</label></p>',
			checked( $credit, true, false ),
			esc_html__( 'Show a small "administraktor.com" credit link at the bottom of the public price-list pages', 'titanworks-bazna-cijena' )
		);
		echo '<p class="description">' . esc_html__( 'Optional. It appears only on the price-list pages, never on products, cart or checkout. Change it any time under Settings, Price lists.', 'titanworks-bazna-cijena' ) . '</p>';
		echo '</fieldset>';

		submit_button( __( 'Save', 'titanworks-bazna-cijena' ), 'primary bazna-btn-busy', 'submit', false );
		echo '</form>';

		echo '<div class="bazna-setup__group bazna-setup__publish">';
		echo '<h3>' . esc_html__( 'Publish the first price list', 'titanworks-bazna-cijena' ) . '</h3>';

		if ( empty( $statuses['locations']['oib'] ) ) {
			printf(
				'<p class="bazna-setup__error">%1$s <a href="%2$s">%3$s</a></p>',
				esc_html__( 'Enter a valid OIB first; generation stops without it.', 'titanworks-bazna-cijena' ),
				esc_url( self::step_url( 'locations' ) ),
				esc_html__( 'Go to step 1', 'titanworks-bazna-cijena' )
			);
		}

		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" class="bazna-busy-form bazna-setup__actions">';
		wp_nonce_field( PublicationsPage::ACTION );
		echo '<input type="hidden" name="action" value="' . esc_attr( PublicationsPage::ACTION ) . '" />';
		submit_button( __( 'Generate price list now', 'titanworks-bazna-cijena' ), 'secondary bazna-btn-busy', 'submit', false );
		printf( ' <a class="button-link" href="%1$s">%2$s</a>', esc_url( AdminMenu::url( 'bazna-cijena-publications' ) ), esc_html__( 'Open price lists', 'titanworks-bazna-cijena' ) );
		echo '</form></div>';
	}

	/**
	 * Step 5: compliance check.
	 *
	 * @param array<string,array<string,mixed>> $statuses Step statuses.
	 * @return void
	 */
	protected static function render_step_check( array $statuses ) {
		if ( null !== $statuses['check']['errors'] && $statuses['check']['errors'] > 0 ) {
			printf(
				'<p class="bazna-setup__error">%1$s</p>',
				/* translators: %d: number of ERROR findings. */
				esc_html( sprintf( __( 'The last check found %d errors. Open the report to see what to fix.', 'titanworks-bazna-cijena' ), (int) $statuses['check']['errors'] ) )
			);
		}

		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" class="bazna-busy-form bazna-setup__actions">';
		wp_nonce_field( CompliancePage::ACTION_RUN );
		echo '<input type="hidden" name="action" value="' . esc_attr( CompliancePage::ACTION_RUN ) . '" />';
		submit_button( __( 'Run compliance check', 'titanworks-bazna-cijena' ), 'primary bazna-btn-busy', 'submit', false );
		printf( ' <a class="button-link" href="%1$s">%2$s</a>', esc_url( AdminMenu::url( 'bazna-cijena-compliance' ) ), esc_html__( 'Open the report', 'titanworks-bazna-cijena' ) );
		echo '</form>';
	}

	/**
	 * Mark-complete or reopen form.
	 *
	 * @param bool $complete Whether setup is complete.
	 * @return void
	 */
	protected static function render_completion( $complete ) {
		echo '<div class="bazna-setup__finish">';

		if ( ! $complete ) {
			echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" class="bazna-busy-form">';
			wp_nonce_field( self::COMPLETE_ACTION );
			echo '<input type="hidden" name="action" value="' . esc_attr( self::COMPLETE_ACTION ) . '" />';
			submit_button( __( 'Mark setup complete', 'titanworks-bazna-cijena' ), 'secondary bazna-btn-busy', 'submit', false );
			echo '<p class="description">' . esc_html__( 'Marking setup complete hides the activation banner. You can return here or reopen the guide at any time.', 'titanworks-bazna-cijena' ) . '</p>';
			echo '</form>';
		} else {
			echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" class="bazna-busy-form">';
			wp_nonce_field( self::REOPEN_ACTION );
			echo '<input type="hidden" name="action" value="' . esc_attr( self::REOPEN_ACTION ) . '" />';
			submit_button( __( 'Reopen setup', 'titanworks-bazna-cijena' ), 'secondary bazna-btn-busy', 'submit', false );
			echo '<p class="description">' . esc_html__( 'Reopening setup restores the setup guide status and banner until marked complete again.', 'titanworks-bazna-cijena' ) . '</p>';
			echo '</form>';
		}

		printf(
			'<p><a href="%1$s"><span class="dashicons dashicons-book bazna-icon-inline"></span>%2$s</a></p>',
			esc_url( AdminMenu::url( DocumentationPage::SLUG ) ),
			esc_html__( 'Open documentation & guide', 'titanworks-bazna-cijena' )
		);

		echo '</div>';
	}

	/**
	 * Render the author project boxes.
	 *
	 * @return void
	 */
	protected static function render_projects() {
		echo '<div class="bazna-setup__projects"><p class="bazna-setup__projects-title">' . esc_html__( 'More from administrakt0r', 'titanworks-bazna-cijena' ) . '</p>';

		foreach ( WelcomeBanner::links() as $link ) {
			printf(
				'<div class="bazna-setup__project"><strong><a href="%1$s" target="_blank" rel="noopener">%2$s</a></strong><br />%3$s</div>',
				esc_url( $link['url'] ),
				esc_html( $link['title'] ),
				esc_html( $link['description'] )
			);
		}

		echo '</div>';
	}

	/**
	 * Redirect back to a wizard step with a notice.
	 *
	 * @param string $step Step key.
	 * @param string $type Notice type.
	 * @param string $text Notice text.
	 * @return void
	 */
	protected static function redirect( $step, $type, $text ) {
		wp_safe_redirect(
			add_query_arg(
				array(
					'step'                     => $step,
					'twbce_cijena_notice'      => $type,
					'twbce_cijena_notice_text' => rawurlencode( $text ),
				),
				AdminMenu::url( self::SLUG )
			)
		);
		exit;
	}

	/**
	 * Save one wizard step.
	 *
	 * @return void
	 */
	public static function handle_save() {
		if ( ! Capabilities::current_user_can() ) {
			wp_die( esc_html__( 'You do not have permission to perform this action.', 'titanworks-bazna-cijena' ) );
		}

		check_admin_referer( self::SAVE_ACTION );

		$step = isset( $_POST['step'] ) ? sanitize_key( wp_unslash( $_POST['step'] ) ) : '';

		switch ( $step ) {
			case 'locations':
				$error = self::save_locations();

				if ( '' !== $error ) {
					self::redirect( 'locations', 'error', $error );
				}

				self::redirect( 'rules', 'success', __( 'Business details saved.', 'titanworks-bazna-cijena' ) );
				break;
			case 'rules':
				$slugs = isset( $_POST['legacy_category_slugs'] ) ? array_values( array_filter( array_map( 'sanitize_title', (array) wp_unslash( $_POST['legacy_category_slugs'] ) ) ) ) : array();
				$none  = ! empty( $_POST['no_legacy'] );

				if ( empty( $slugs ) && ! $none ) {
					self::redirect( 'rules', 'error', __( 'Tick at least one category, or confirm that you do not sell these product groups.', 'titanworks-bazna-cijena' ) );
				}

				RuleConfig::update(
					$none ? array( 'legacy_category_slugs' => array() ) : array(
						'legacy_category_slugs' => $slugs,
						'legacy_enabled'        => true,
					),
					get_current_user_id(),
					__( 'Setup guide', 'titanworks-bazna-cijena' )
				);

				if ( $none ) {
					update_option( self::NO_LEGACY_OPTION, 1, false );
				} else {
					delete_option( self::NO_LEGACY_OPTION );
				}

				self::redirect( 'anchors', 'success', __( 'Category rules saved.', 'titanworks-bazna-cijena' ) );
				break;
			case 'services':
				$selected = isset( $_POST['shipping'] ) ? array_values( array_filter( array_map( 'absint', (array) wp_unslash( $_POST['shipping'] ) ) ) ) : array();
				$none     = ! empty( $_POST['no_services'] );
				$date     = isset( $_POST['base_date'] ) ? sanitize_text_field( wp_unslash( $_POST['base_date'] ) ) : '';

				if ( empty( $selected ) && ! $none && 0 === count( ServiceCatalog::posts() ) ) {
					self::redirect( 'services', 'error', __( 'Select the delivery methods you charge for, or confirm that you charge for no services.', 'titanworks-bazna-cijena' ) );
				}

				if ( ! empty( $selected ) ) {
					$summary = ServiceManager::import_shipping( $selected, $date );

					if ( ! empty( $summary['errors'] ) ) {
						self::redirect( 'services', 'error', implode( ' ', $summary['errors'] ) );
					}
				}

				if ( $none && empty( $selected ) ) {
					update_option( self::NO_SERVICES_OPTION, 1, false );
				} else {
					delete_option( self::NO_SERVICES_OPTION );
				}

				self::redirect( 'lists', 'success', __( 'Services saved.', 'titanworks-bazna-cijena' ) );
				break;
			case 'lists':
				$values = array(
					'display_enabled'    => ! empty( $_POST['display_enabled'] ),
					'public_credit_link' => ! empty( $_POST['public_credit_link'] ),
				);

				if ( isset( $_POST['anchor_label'] ) ) {
					$label = sanitize_text_field( wp_unslash( $_POST['anchor_label'] ) );

					if ( '' !== $label ) {
						$values['anchor_label'] = $label;
					}
				}

				Settings::update( $values, get_current_user_id() );
				update_option( self::CREDIT_ASKED_OPTION, 1, false );

				self::redirect( 'lists', 'success', __( 'Storefront settings saved. Now publish the first price list.', 'titanworks-bazna-cijena' ) );
				break;
			default:
				self::redirect( '', 'error', __( 'Unknown setup step.', 'titanworks-bazna-cijena' ) );
		}
	}

	/**
	 * Save step 1. Returns an error message, or '' on success.
	 *
	 * @return string
	 */
	protected static function save_locations() {
		// phpcs:disable WordPress.Security.NonceVerification.Missing -- Verified in handle_save().
		$oib     = isset( $_POST['merchant_oib'] ) ? preg_replace( '/[^0-9]/', '', sanitize_text_field( wp_unslash( $_POST['merchant_oib'] ) ) ) : '';
		$id_type = isset( $_POST['merchant_id_type'] ) && 'mbg' === $_POST['merchant_id_type'] ? 'mbg' : 'oib';
		$raw     = isset( $_POST['location'] ) && is_array( $_POST['location'] ) ? wp_unslash( $_POST['location'] ) : array(); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Each field is sanitized below.
		$loc_id  = isset( $_POST['location_id'] ) ? absint( $_POST['location_id'] ) : 0;
		// phpcs:enable WordPress.Security.NonceVerification.Missing

		if ( 'oib' === $id_type && ! FilenameGenerator::is_valid_oib( (string) $oib ) ) {
			return __( 'Enter a valid 11-digit OIB. Generation stops until a valid value is entered.', 'titanworks-bazna-cijena' );
		}

		if ( 'mbg' === $id_type && ! preg_match( '/^[0-9]{7,13}$/', (string) $oib ) ) {
			return __( 'Enter a registration number of 7 to 13 digits. Generation stops until a valid value is entered.', 'titanworks-bazna-cijena' );
		}

		Settings::update(
			array(
				'merchant_oib'     => (string) $oib,
				'merchant_id_type' => $id_type,
			),
			get_current_user_id()
		);

		$data = array();

		foreach ( array( 'type', 'name', 'address', 'city', 'identifier' ) as $key ) {
			$data[ $key ] = isset( $raw[ $key ] ) ? sanitize_text_field( (string) $raw[ $key ] ) : '';
		}

		if ( '' === $data['name'] || '' === $data['address'] || '' === $data['city'] || '' === $data['identifier'] ) {
			return __( 'Fill in the location name, street address, city and facility identifier.', 'titanworks-bazna-cijena' );
		}

		$repository = Plugin::instance()->locations();

		$identifier = strtoupper( $data['identifier'] );

		foreach ( $repository->all() as $other ) {
			if ( isset( $other['identifier'], $other['id'] ) && (int) $other['id'] !== $loc_id && strtoupper( (string) $other['identifier'] ) === $identifier ) {
				return __( 'Another location already uses this facility identifier.', 'titanworks-bazna-cijena' );
			}
		}

		try {
			if ( $loc_id > 0 && $repository->get( $loc_id ) ) {
				if ( ! $repository->update( $loc_id, $data ) ) {
					return __( 'The location could not be saved. Please try again.', 'titanworks-bazna-cijena' );
				}
			} elseif ( ! $repository->insert( $data + array( 'active' => 1 ) ) ) {
				return __( 'Another location already uses this facility identifier.', 'titanworks-bazna-cijena' );
			}
		} catch ( \InvalidArgumentException $e ) {
			return __( 'Fill in the location name, street address, city and facility identifier.', 'titanworks-bazna-cijena' );
		}

		return '';
	}

	/**
	 * Mark setup complete.
	 *
	 * @return void
	 */
	public static function handle_complete() {
		if ( ! Capabilities::current_user_can() ) {
			wp_die( esc_html__( 'You do not have permission to perform this action.', 'titanworks-bazna-cijena' ) );
		}

		check_admin_referer( self::COMPLETE_ACTION );

		update_option( self::COMPLETE_OPTION, 1, false );
		update_option( WelcomeBanner::DISMISSED_OPTION, 1, false );

		wp_safe_redirect(
			add_query_arg(
				array(
					'twbce_cijena_notice'      => 'success',
					'twbce_cijena_notice_text' => rawurlencode( __( 'Setup marked as complete.', 'titanworks-bazna-cijena' ) ),
				),
				AdminMenu::url( AdminMenu::PARENT )
			)
		);
		exit;
	}

	/**
	 * Reopen setup.
	 *
	 * @return void
	 */
	public static function handle_reopen() {
		if ( ! Capabilities::current_user_can() ) {
			wp_die( esc_html__( 'You do not have permission to perform this action.', 'titanworks-bazna-cijena' ) );
		}

		check_admin_referer( self::REOPEN_ACTION );

		delete_option( self::COMPLETE_OPTION );

		wp_safe_redirect(
			add_query_arg(
				array(
					'twbce_cijena_notice'      => 'success',
					'twbce_cijena_notice_text' => rawurlencode( __( 'Setup reopened.', 'titanworks-bazna-cijena' ) ),
				),
				AdminMenu::url( self::SLUG )
			)
		);
		exit;
	}
}
