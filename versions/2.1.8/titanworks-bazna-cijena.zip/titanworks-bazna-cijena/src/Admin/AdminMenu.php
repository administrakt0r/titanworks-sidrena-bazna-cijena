<?php
/**
 * Admin menu and asset registration.
 *
 * @package Titanworks\BaznaCijena\Admin
 */

namespace Titanworks\BaznaCijena\Admin;

use Titanworks\BaznaCijena\Catalog\StandalonePostType;

defined( 'ABSPATH' ) || exit;

/**
 * Registers the plugin admin screens.
 */
final class AdminMenu {

	/**
	 * Top-level menu slug.
	 */
	const PARENT = 'bazna-cijena';

	/**
	 * Register menus and submenus.
	 *
	 * The menu is always a dedicated top-level section for discoverability.
	 *
	 * @return void
	 */
	public static function register() {
		$capability = Capabilities::capability();
		add_menu_page(
			__( 'Bazna cijena', 'titanworks-bazna-cijena' ),
			__( 'Bazna cijena', 'titanworks-bazna-cijena' ),
			$capability,
			self::PARENT,
			array( DashboardPage::class, 'render' ),
			self::menu_icon(),
			56
		);

		foreach ( self::pages() as $slug => $page ) {
			$callback = array( $page[0], 'render' );

			add_submenu_page(
				self::PARENT,
				/* translators: %s: screen title. */
				sprintf( __( '%s - Bazna cijena', 'titanworks-bazna-cijena' ), $page[1] ),
				$page[1],
				$capability,
				$slug,
				is_callable( $callback ) ? $callback : ''
			);
		}
	}

	/**
	 * Registered pages: slug => [class, label].
	 *
	 * @return array<string,array{0:class-string,1:string}>
	 */
	public static function pages() {
		return array(
			self::PARENT                => array( DashboardPage::class, __( 'Dashboard', 'titanworks-bazna-cijena' ) ),
			SetupGuidePage::SLUG        => array( SetupGuidePage::class, __( 'Setup Guide', 'titanworks-bazna-cijena' ) ),
			'bazna-cijena-publications' => array( PublicationsPage::class, __( 'Price lists', 'titanworks-bazna-cijena' ) ),
			'bazna-cijena-anchors'      => array( BulkAnchorEntryPage::class, __( 'Anchor prices', 'titanworks-bazna-cijena' ) ),
			'bazna-cijena-import'       => array( ImportPage::class, __( 'Import', 'titanworks-bazna-cijena' ) ),
			'bazna-cijena-locations'    => array( LocationsPage::class, __( 'Sales locations', 'titanworks-bazna-cijena' ) ),
			ServicesPage::SLUG          => array( ServicesPage::class, __( 'Services', 'titanworks-bazna-cijena' ) ),
			'bazna-cijena-history'      => array( PriceHistoryPage::class, __( 'Price history', 'titanworks-bazna-cijena' ) ),
			'bazna-cijena-compliance'   => array( CompliancePage::class, __( 'Compliance check', 'titanworks-bazna-cijena' ) ),
			'bazna-cijena-settings'     => array( SettingsPage::class, __( 'Settings', 'titanworks-bazna-cijena' ) ),
			'bazna-cijena-logs'         => array( LogsPage::class, __( 'Logs', 'titanworks-bazna-cijena' ) ),
			'bazna-cijena-audit'        => array( AuditPage::class, __( 'Audit', 'titanworks-bazna-cijena' ) ),
			DocumentationPage::SLUG     => array( DocumentationPage::class, __( 'Documentation', 'titanworks-bazna-cijena' ) ),
		);
	}

	/**
	 * Related screens shown as tabs under one menu item: owner slug => member slugs.
	 *
	 * Members other than the owner are hidden from the admin menu but stay
	 * registered, so every existing URL keeps working.
	 *
	 * @return array<string,array<int,string>>
	 */
	public static function groups() {
		return array(
			'bazna-cijena-anchors'    => array( 'bazna-cijena-anchors', 'bazna-cijena-import', 'bazna-cijena-history' ),
			'bazna-cijena-compliance' => array( 'bazna-cijena-compliance', 'bazna-cijena-audit', 'bazna-cijena-logs' ),
			DocumentationPage::SLUG   => array( DocumentationPage::SLUG, SetupGuidePage::SLUG ),
		);
	}

	/**
	 * Menu item that owns a screen, or the screen itself when ungrouped.
	 *
	 * @param string $slug Screen slug.
	 * @return string
	 */
	public static function group_owner( $slug ) {
		foreach ( self::groups() as $owner => $members ) {
			if ( in_array( $slug, $members, true ) ) {
				return $owner;
			}
		}

		return $slug;
	}

	/**
	 * Slugs hidden from the admin menu.
	 *
	 * The setup guide stays visible until setup is marked complete.
	 *
	 * @param bool $setup_complete Whether setup is complete.
	 * @return array<int,string>
	 */
	public static function hidden_slugs( $setup_complete ) {
		$hidden = array();

		foreach ( self::groups() as $owner => $members ) {
			foreach ( $members as $member ) {
				if ( $member !== $owner && ( SetupGuidePage::SLUG !== $member || $setup_complete ) ) {
					$hidden[] = $member;
				}
			}
		}

		return $hidden;
	}

	/**
	 * Remove grouped screens from the visible submenu.
	 *
	 * Runs on `admin_head`, after WordPress has checked page access and
	 * built the page title from the full menu, and before menu-header.php
	 * prints the menu. Removing them earlier on `admin_menu` would make
	 * WordPress deny access to the hidden screens.
	 *
	 * @return void
	 */
	public static function hide_grouped_pages() {
		global $submenu;

		if ( empty( $submenu[ self::PARENT ] ) || ! is_array( $submenu[ self::PARENT ] ) ) {
			return;
		}

		$hidden = self::hidden_slugs( SetupGuidePage::is_complete() );

		foreach ( $submenu[ self::PARENT ] as $index => $item ) {
			if ( isset( $item[2] ) && in_array( $item[2], $hidden, true ) ) {
				unset( $submenu[ self::PARENT ][ $index ] );
			}
		}
	}

	/**
	 * Highlight the owning menu item while a grouped screen is open.
	 *
	 * @param string|null $submenu_file Current submenu file.
	 * @return string|null
	 */
	public static function submenu_file( $submenu_file ) {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only menu state.
		$current = isset( $_GET['page'] ) ? sanitize_key( wp_unslash( $_GET['page'] ) ) : '';

		if ( ! self::is_own_page( $current ) ) {
			return $submenu_file;
		}

		$owner = self::group_owner( $current );

		if ( $owner === $current && SetupGuidePage::SLUG === $current && ! SetupGuidePage::is_complete() ) {
			return $submenu_file;
		}

		return in_array( $current, self::hidden_slugs( SetupGuidePage::is_complete() ), true ) ? $owner : $submenu_file;
	}

	/**
	 * Print the tab bar for a grouped screen. Ungrouped screens print nothing.
	 *
	 * @param string $slug Current screen slug.
	 * @return void
	 */
	public static function render_tabs( $slug ) {
		$owner  = self::group_owner( $slug );
		$groups = self::groups();

		if ( ! isset( $groups[ $owner ] ) ) {
			return;
		}

		$pages = self::pages();

		echo '<nav class="nav-tab-wrapper bazna-group-tabs" aria-label="' . esc_attr__( 'Related screens', 'titanworks-bazna-cijena' ) . '">';

		foreach ( $groups[ $owner ] as $member ) {
			if ( ! isset( $pages[ $member ] ) ) {
				continue;
			}

			printf(
				'<a href="%1$s" class="nav-tab%2$s"%3$s>%4$s</a>',
				esc_url( self::url( $member ) ),
				$member === $slug ? ' nav-tab-active' : '',
				$member === $slug ? ' aria-current="page"' : '',
				esc_html( $pages[ $member ][1] )
			);
		}

		echo '</nav>';
	}

	/**
	 * URL of a plugin screen.
	 *
	 * @param string $slug Screen slug.
	 * @param array  $args Extra query arguments.
	 * @return string
	 */
	public static function url( $slug, array $args = array() ) {
		$url = menu_page_url( $slug, false );

		if ( ! $url ) {
			$url = admin_url( 'admin.php?page=' . rawurlencode( $slug ) );
		}

		return empty( $args ) ? $url : add_query_arg( $args, $url );
	}

	/**
	 * Whether a `page` query value is exactly one of this plugin's screens.
	 *
	 * Exact match on purpose: a prefix or substring test would also claim
	 * screens of unrelated plugins whose slug merely starts with ours.
	 *
	 * @param string $page Value of the `page` query argument.
	 * @return bool
	 */
	public static function is_own_page( $page ) {
		return '' !== $page && array_key_exists( $page, self::pages() );
	}

	/**
	 * Whether a screen ID or admin hook suffix belongs to one of this plugin's screens.
	 *
	 * Submenu hook suffixes are `<sanitized parent title>_page_<slug>`, so the
	 * check is `_page_` plus one of our exact slugs at the end of the value.
	 *
	 * @param string $id Screen ID or hook suffix.
	 * @return bool
	 */
	public static function is_own_screen_id( $id ) {
		foreach ( array_keys( self::pages() ) as $slug ) {
			$suffix = '_page_' . $slug;

			if ( 'toplevel_page_' . $slug === $id || ( strlen( $id ) > strlen( $suffix ) && substr( $id, -strlen( $suffix ) ) === $suffix ) ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Whether the current request is on a plugin or product screen.
	 *
	 * Scopes admin notices and styles strictly to plugin screens to comply
	 * with WordPress.org Guideline 11.
	 *
	 * @param bool $include_product Whether to include WooCommerce product edit screens.
	 * @return bool
	 */
	public static function is_plugin_screen( $include_product = false ) {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$page = isset( $_GET['page'] ) ? sanitize_key( wp_unslash( $_GET['page'] ) ) : '';

		if ( self::is_own_page( $page ) ) {
			return true;
		}

		if ( function_exists( 'get_current_screen' ) ) {
			$screen = get_current_screen();

			if ( $screen ) {
				if ( self::is_own_screen_id( (string) $screen->id ) || StandalonePostType::POST_TYPE === $screen->post_type ) {
					return true;
				}

				if ( $include_product && in_array( $screen->base, array( 'post', 'post-new' ), true ) && in_array( $screen->post_type, array( 'product', 'twbce_item' ), true ) ) {
					return true;
				}
			}
		}

		return false;
	}

	/**
	 * Enqueue admin assets on plugin screens.
	 *
	 * @param string $hook_suffix Current screen hook.
	 * @return void
	 */
	public static function enqueue_assets( $hook_suffix ) {
		$is_product_screen = false;
		if ( in_array( $hook_suffix, array( 'post.php', 'post-new.php' ), true ) ) {
			$screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
			if ( $screen && ( 'product' === $screen->post_type || 'twbce_item' === $screen->post_type ) ) {
				$is_product_screen = true;
			}
		}

		$is_plugin_screen = self::is_own_screen_id( (string) $hook_suffix );

		if ( ! $is_product_screen && ! $is_plugin_screen ) {
			return;
		}

		wp_enqueue_style(
			'bazna-cijena-admin',
			TWBCE_CIJENA_URL . 'assets/css/admin.css',
			array(),
			TWBCE_CIJENA_VERSION
		);

		if ( isset( $_GET['tab'] ) && 'styling' === sanitize_key( wp_unslash( $_GET['tab'] ) ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only asset selection.
			wp_enqueue_style( 'bazna-cijena-frontend', TWBCE_CIJENA_URL . 'assets/css/frontend.css', array(), TWBCE_CIJENA_VERSION );
		}

		wp_enqueue_script(
			'bazna-cijena-admin',
			TWBCE_CIJENA_URL . 'assets/js/admin.js',
			array( 'jquery', 'jquery-ui-datepicker' ),
			TWBCE_CIJENA_VERSION,
			true
		);

		wp_localize_script(
			'bazna-cijena-admin',
			'baznaDatepickerI18n',
			array(
				'closeText'       => __( 'Done', 'titanworks-bazna-cijena' ),
				'prevText'        => __( 'Prev', 'titanworks-bazna-cijena' ),
				'nextText'        => __( 'Next', 'titanworks-bazna-cijena' ),
				'currentText'     => __( 'Today', 'titanworks-bazna-cijena' ),
				'monthNames'      => array(
					__( 'January', 'titanworks-bazna-cijena' ),
					__( 'February', 'titanworks-bazna-cijena' ),
					__( 'March', 'titanworks-bazna-cijena' ),
					__( 'April', 'titanworks-bazna-cijena' ),
					__( 'May', 'titanworks-bazna-cijena' ),
					__( 'June', 'titanworks-bazna-cijena' ),
					__( 'July', 'titanworks-bazna-cijena' ),
					__( 'August', 'titanworks-bazna-cijena' ),
					__( 'September', 'titanworks-bazna-cijena' ),
					__( 'October', 'titanworks-bazna-cijena' ),
					__( 'November', 'titanworks-bazna-cijena' ),
					__( 'December', 'titanworks-bazna-cijena' ),
				),
				'monthNamesShort' => array(
					__( 'Jan', 'titanworks-bazna-cijena' ),
					__( 'Feb', 'titanworks-bazna-cijena' ),
					__( 'Mar', 'titanworks-bazna-cijena' ),
					__( 'Apr', 'titanworks-bazna-cijena' ),
					__( 'May', 'titanworks-bazna-cijena' ),
					__( 'Jun', 'titanworks-bazna-cijena' ),
					__( 'Jul', 'titanworks-bazna-cijena' ),
					__( 'Aug', 'titanworks-bazna-cijena' ),
					__( 'Sep', 'titanworks-bazna-cijena' ),
					__( 'Oct', 'titanworks-bazna-cijena' ),
					__( 'Nov', 'titanworks-bazna-cijena' ),
					__( 'Dec', 'titanworks-bazna-cijena' ),
				),
				'dayNames'        => array(
					__( 'Sunday', 'titanworks-bazna-cijena' ),
					__( 'Monday', 'titanworks-bazna-cijena' ),
					__( 'Tuesday', 'titanworks-bazna-cijena' ),
					__( 'Wednesday', 'titanworks-bazna-cijena' ),
					__( 'Thursday', 'titanworks-bazna-cijena' ),
					__( 'Friday', 'titanworks-bazna-cijena' ),
					__( 'Saturday', 'titanworks-bazna-cijena' ),
				),
				'dayNamesShort'   => array(
					__( 'Sun', 'titanworks-bazna-cijena' ),
					__( 'Mon', 'titanworks-bazna-cijena' ),
					__( 'Tue', 'titanworks-bazna-cijena' ),
					__( 'Wed', 'titanworks-bazna-cijena' ),
					__( 'Thu', 'titanworks-bazna-cijena' ),
					__( 'Fri', 'titanworks-bazna-cijena' ),
					__( 'Sat', 'titanworks-bazna-cijena' ),
				),
				'dayNamesMin'     => array(
					__( 'Su', 'titanworks-bazna-cijena' ),
					__( 'Mo', 'titanworks-bazna-cijena' ),
					__( 'Tu', 'titanworks-bazna-cijena' ),
					__( 'We', 'titanworks-bazna-cijena' ),
					__( 'Th', 'titanworks-bazna-cijena' ),
					__( 'Fr', 'titanworks-bazna-cijena' ),
					__( 'Sa', 'titanworks-bazna-cijena' ),
				),
				'dateFormat'      => 'dd.mm.yy.',
				'firstDay'        => 1,
			)
		);
	}

	/**
	 * An anchor glyph, since Dashicons has no anchor icon.
	 *
	 * @return string
	 */
	public static function menu_icon() {
		$svg = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><g fill="none" stroke="#fff" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="4" r="2"/><path d="M12 6v14m-5-9h10M4 15c0 4 3.6 6 8 6s8-2 8-6m-16 0 2.5 1.5M20 15l-2.5 1.5"/></g></svg>';

		return 'data:image/svg+xml;base64,' . base64_encode( $svg ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_encode -- WordPress admin menu recognizes SVG icons only in this encoded form.
	}
}
