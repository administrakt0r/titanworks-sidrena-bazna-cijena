<?php
/**
 * Catalog decorator that adds the plugin's own services.
 *
 * @package Titanworks\BaznaCijena\Catalog
 */

namespace Titanworks\BaznaCijena\Catalog;

use Titanworks\BaznaCijena\Services\ServiceCatalog;

defined( 'ABSPATH' ) || exit;

/**
 * Wraps the active catalog (WooCommerce or standalone) and appends services.
 *
 * Products keep coming from the wrapped provider unchanged; services are
 * added to iteration and counts, and resolved by ID, so price lists,
 * compliance checks, integrity scans and the price history see one catalog.
 */
class ServiceAwareCatalog implements CatalogProvider {

	/**
	 * Wrapped provider.
	 *
	 * @var CatalogProvider
	 */
	protected $inner;

	/**
	 * Services source (overridable in tests).
	 *
	 * @var callable(): CatalogItem[]
	 */
	protected $services;

	/**
	 * Single service lookup (overridable in tests).
	 *
	 * @var callable(int): (CatalogItem|null)
	 */
	protected $lookup;

	/**
	 * Constructor.
	 *
	 * @param CatalogProvider $inner    Wrapped provider.
	 * @param callable|null   $services Returns active service items.
	 * @param callable|null   $lookup   Returns one service item by ID or null.
	 */
	public function __construct( CatalogProvider $inner, $services = null, $lookup = null ) {
		$this->inner    = $inner;
		$this->services = is_callable( $services ) ? $services : array( ServiceCatalog::class, 'items' );
		$this->lookup   = is_callable( $lookup ) ? $lookup : array( ServiceCatalog::class, 'get' );
	}

	/**
	 * Wrapped provider.
	 *
	 * @return CatalogProvider
	 */
	public function inner() {
		return $this->inner;
	}

	/**
	 * {@inheritDoc}
	 */
	public function get_source() {
		return $this->inner->get_source();
	}

	/**
	 * {@inheritDoc}
	 */
	public function is_available() {
		return $this->inner->is_available();
	}

	/**
	 * {@inheritDoc}
	 *
	 * @param int $id Item ID.
	 */
	public function get_item( $id ) {
		$service = call_user_func( $this->lookup, (int) $id );

		if ( $service instanceof CatalogItem ) {
			return $service;
		}

		return $this->inner->get_item( $id );
	}

	/**
	 * {@inheritDoc}
	 *
	 * @param int $parent_id    Parent ID.
	 * @param int $variation_id Variation ID.
	 */
	public function get_variation( $parent_id, $variation_id ) {
		return $this->inner->get_variation( $parent_id, $variation_id );
	}

	/**
	 * {@inheritDoc}
	 *
	 * Services are returned only for an explicit `type => service` query;
	 * paged product queries are left to the wrapped provider untouched.
	 *
	 * @param array<string,mixed> $args Query args.
	 */
	public function get_items( array $args = array() ) {
		if ( ! $this->wants_services( $args ) || ! $this->only_services( $args ) ) {
			return $this->inner->get_items( $args );
		}

		$services = $this->services();
		$per_page = isset( $args['per_page'] ) ? max( 1, (int) $args['per_page'] ) : 20;
		$page     = isset( $args['page'] ) ? max( 1, (int) $args['page'] ) : 1;

		return array_merge(
			$this->inner->get_items( $args ),
			array_slice( $services, ( $page - 1 ) * $per_page, $per_page )
		);
	}

	/**
	 * {@inheritDoc}
	 *
	 * @param array<string,mixed> $args Query args.
	 */
	public function count_items( array $args = array() ) {
		$count = (int) $this->inner->count_items( $args );

		if ( $this->wants_services( $args ) ) {
			$count += count( $this->services() );
		}

		return $count;
	}

	/**
	 * {@inheritDoc}
	 *
	 * @param array<string,mixed> $args Query args.
	 */
	public function iterate( array $args = array() ) {
		foreach ( $this->inner->iterate( $args ) as $item ) {
			yield $item;
		}

		if ( ! $this->wants_services( $args ) ) {
			return;
		}

		foreach ( $this->services() as $service ) {
			yield $service;
		}
	}

	/**
	 * {@inheritDoc}
	 */
	public function get_categories() {
		return $this->inner->get_categories();
	}

	/**
	 * {@inheritDoc}
	 *
	 * @param int $id Item ID.
	 */
	public function get_item_categories( $id ) {
		if ( call_user_func( $this->lookup, (int) $id ) instanceof CatalogItem ) {
			return array();
		}

		return $this->inner->get_item_categories( $id );
	}

	/**
	 * Active services.
	 *
	 * @return CatalogItem[]
	 */
	protected function services() {
		$items = (array) call_user_func( $this->services );

		return array_values( array_filter( $items, array( $this, 'is_item' ) ) );
	}

	/**
	 * Whether a value is a catalog item.
	 *
	 * @param mixed $item Candidate.
	 * @return bool
	 */
	protected function is_item( $item ) {
		return $item instanceof CatalogItem;
	}

	/**
	 * Whether a query can include services.
	 *
	 * Queries scoped to specific products (IDs, parents, a search, a
	 * category) never include services.
	 *
	 * @param array<string,mixed> $args Query args.
	 * @return bool
	 */
	protected function wants_services( array $args ) {
		$type = isset( $args['type'] ) ? (string) $args['type'] : 'all';

		if ( ! in_array( $type, array( 'all', 'service' ), true ) ) {
			return false;
		}

		foreach ( array( 'include', 'ids', 'parent', 'product_id', 'search', 's', 'category' ) as $key ) {
			if ( ! empty( $args[ $key ] ) ) {
				return false;
			}
		}

		return true;
	}

	/**
	 * Whether a query asks for services only.
	 *
	 * @param array<string,mixed> $args Query args.
	 * @return bool
	 */
	protected function only_services( array $args ) {
		return isset( $args['type'] ) && 'service' === $args['type'];
	}
}
