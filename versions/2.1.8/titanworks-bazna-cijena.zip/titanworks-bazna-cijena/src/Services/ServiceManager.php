<?php
/**
 * Create, update and synchronise paid services.
 *
 * @package Titanworks\BaznaCijena\Services
 */

namespace Titanworks\BaznaCijena\Services;

use Titanworks\BaznaCijena\Catalog\CatalogItem;
use Titanworks\BaznaCijena\Compliance\RuleConfig;
use Titanworks\BaznaCijena\Cron\Scheduler;
use Titanworks\BaznaCijena\Logging\Logger;
use Titanworks\BaznaCijena\Plugin;
use Titanworks\BaznaCijena\Support\Currency;
use Titanworks\BaznaCijena\Support\Dates;
use Titanworks\BaznaCijena\Support\Settings;
use WP_Error;

defined( 'ABSPATH' ) || exit;

/**
 * Writes services and keeps delivery services in step with WooCommerce.
 *
 * Every price change is a new price-history row (the history is the legal
 * record), the base price goes through the anchor service, and services are
 * never deleted: a service that is no longer offered is switched off.
 */
final class ServiceManager {

	/**
	 * Register hooks.
	 *
	 * @return void
	 */
	public static function register() {
		add_action( 'init', array( ServiceCatalog::class, 'register' ) );
		add_action( 'updated_option', array( __CLASS__, 'on_option_updated' ), 10, 3 );
		add_action( 'woocommerce_shipping_zone_method_status_toggled', array( __CLASS__, 'on_method_toggled' ), 10, 4 );
		add_action( 'woocommerce_shipping_zone_method_deleted', array( __CLASS__, 'on_method_deleted' ), 10, 1 );
		add_action( 'added_option', array( __CLASS__, 'on_option_added' ), 10, 2 );
		// Tax rates change the consumer price of taxable shipping.
		add_action( 'woocommerce_tax_rate_added', array( __CLASS__, 'resync_all' ), 10, 0 );
		add_action( 'woocommerce_tax_rate_updated', array( __CLASS__, 'resync_all' ), 10, 0 );
		add_action( 'woocommerce_tax_rate_deleted', array( __CLASS__, 'resync_all' ), 10, 0 );
		// Safety net before the daily list: catch any change made outside these hooks.
		add_action( Scheduler::HOOK_DAILY, array( __CLASS__, 'resync_all' ), 5, 0 );
	}

	/**
	 * Global WooCommerce options that change the gross price of shipping.
	 *
	 * @return string[]
	 */
	public static function tax_options() {
		return array( 'woocommerce_calc_taxes', 'woocommerce_shipping_tax_class', 'woocommerce_default_country' );
	}

	/**
	 * Re-sync every linked service against the current WooCommerce shipping setup.
	 *
	 * @return void
	 */
	public static function resync_all() {
		self::sync_method( 0 );
	}

	/**
	 * Follow a WooCommerce option being created for the first time.
	 *
	 * @param string $option Option name.
	 * @param mixed  $value  Option value.
	 * @return void
	 */
	public static function on_option_added( $option, $value = null ) {
		self::on_option_updated( $option, null, $value );
	}

	/**
	 * Create or update a service.
	 *
	 * @param array<string,mixed> $data `name`, `price`, `active`, `base_price`, `base_date`, `base_reason`, `shipping`.
	 * @param int                 $id   Existing service ID, 0 to create.
	 * @param string              $source History source.
	 * @return int|WP_Error Service ID.
	 */
	public static function save( array $data, $id = 0, $source = 'service' ) {
		$id       = (int) $id;
		$existing = $id ? get_post( $id ) : null;

		if ( $id && ! ServiceCatalog::is_service_post( $existing ) ) {
			return new WP_Error( 'service_not_found', __( 'The service was not found.', 'titanworks-bazna-cijena' ) );
		}

		$name = isset( $data['name'] ) ? trim( sanitize_text_field( (string) $data['name'] ) ) : '';

		if ( '' === $name ) {
			return new WP_Error( 'service_name_required', __( 'Enter the service name.', 'titanworks-bazna-cijena' ) );
		}

		$linked = $existing ? absint( get_post_meta( $id, ServiceCatalog::META_SHIPPING, true ) ) : 0;

		if ( $linked && 'shipping_sync' !== $source ) {
			// WooCommerce owns the price of a linked shipping service; only the
			// shipping sync may change it, so the list never drifts from checkout.
			$price = self::stored_price( $id );
		} else {
			$price = self::amount( isset( $data['price'] ) ? $data['price'] : '' );
		}

		if ( null === $price || $price <= 0 ) {
			// A free service is not a paid consumer service and would block publication
			// (invalid retail price), so it is not listed.
			return new WP_Error( 'service_price_required', __( 'Enter the service price as a number greater than 0, for example 4,50. Free services are not listed.', 'titanworks-bazna-cijena' ) );
		}

		$base_raw   = isset( $data['base_price'] ) ? trim( (string) $data['base_price'] ) : '';
		$base_price = '' === $base_raw ? null : self::amount( $base_raw );

		if ( '' !== $base_raw && ( null === $base_price || $base_price <= 0 ) ) {
			return new WP_Error( 'service_base_invalid', __( 'Enter the base price as a number greater than 0, for example 4,50.', 'titanworks-bazna-cijena' ) );
		}

		$base_date = isset( $data['base_date'] ) ? trim( (string) $data['base_date'] ) : '';

		if ( null !== $base_price ) {
			if ( '' === $base_date ) {
				$base_date = self::default_base_date();
			}

			if ( ! Dates::is_valid_date( $base_date ) || $base_date > Dates::today() ) {
				return new WP_Error( 'service_base_date_invalid', __( 'The base price date must be a valid date that is not in the future.', 'titanworks-bazna-cijena' ) );
			}
		}

		if ( $existing && null !== $base_price && self::base_price_changes( $id, $base_price, $base_date ) && '' === trim( sanitize_text_field( isset( $data['base_reason'] ) ? (string) $data['base_reason'] : '' ) ) ) {
			// Refuse before anything is written, so a rejected correction leaves the service untouched.
			return new WP_Error( 'correction_reason_required', __( 'Changing an existing base price requires a correction reason.', 'titanworks-bazna-cijena' ) );
		}

		$status = ! isset( $data['active'] ) || ! empty( $data['active'] ) ? 'publish' : 'draft';

		if ( $existing ) {
			$old_price = self::stored_price( $id );
			$result    = wp_update_post(
				array(
					'ID'          => $id,
					'post_title'  => $name,
					'post_status' => $status,
				),
				true
			);
		} else {
			$old_price = null;
			$result    = wp_insert_post(
				array(
					'post_type'   => ServiceCatalog::POST_TYPE,
					'post_title'  => $name,
					'post_status' => $status,
				),
				true
			);
		}

		if ( is_wp_error( $result ) ) {
			return $result;
		}

		$id = (int) $result;

		if ( ! $existing ) {
			// A service entered with an earlier base-price date was already
			// offered then; otherwise it is first offered today.
			$first_seen = null !== $base_price && $base_date < Dates::today() ? $base_date : Dates::today();
			update_post_meta( $id, ServiceCatalog::META_FIRST_SEEN, $first_seen );
		}

		if ( isset( $data['shipping'] ) ) {
			$shipping = absint( $data['shipping'] );

			if ( $shipping ) {
				update_post_meta( $id, ServiceCatalog::META_SHIPPING, $shipping );
			} else {
				delete_post_meta( $id, ServiceCatalog::META_SHIPPING );
			}
		}

		if ( 'publish' === $status ) {
			delete_post_meta( $id, ServiceCatalog::META_AUTO_OFF );
		}

		if ( ! self::apply_price( $id, $old_price, $price, $source ) ) {
			if ( ! $existing ) {
				// Nothing was recorded for the new service yet, so remove it
				// rather than leave a listed service without a price.
				wp_delete_post( $id, true );
			}

			return new WP_Error( 'service_price_not_recorded', __( 'The price could not be recorded in the price history, so it was not changed. Try again or check the logs.', 'titanworks-bazna-cijena' ) );
		}

		if ( null !== $base_price ) {
			$anchored = self::apply_base_price( $id, $base_price, $base_date, isset( $data['base_reason'] ) ? (string) $data['base_reason'] : '' );

			if ( is_wp_error( $anchored ) ) {
				return $anchored;
			}
		}

		if ( ! $existing || $status !== $existing->post_status || $name !== $existing->post_title ) {
			// The name is exported (naziv_usluge), so a rename republishes too.
			self::queue_regeneration();
		}

		return $id;
	}

	/**
	 * Switch a service on or off.
	 *
	 * @param int  $id     Service ID.
	 * @param bool $active New state.
	 * @param bool $auto   Whether the plugin itself switches it (shipping sync).
	 * @return bool
	 */
	public static function set_active( $id, $active, $auto = false ) {
		$post = get_post( (int) $id );

		if ( ! ServiceCatalog::is_service_post( $post ) ) {
			return false;
		}

		$status = $active ? 'publish' : 'draft';

		if ( $active ) {
			delete_post_meta( $post->ID, ServiceCatalog::META_AUTO_OFF );
		} elseif ( $auto ) {
			// Only a listed service is switched off automatically; one the
			// merchant already stopped listing keeps its manual exclusion,
			// so re-enabling the shipping method does not relist it.
			if ( 'publish' === $post->post_status ) {
				update_post_meta( $post->ID, ServiceCatalog::META_AUTO_OFF, 1 );
			}
		} else {
			delete_post_meta( $post->ID, ServiceCatalog::META_AUTO_OFF );
		}

		if ( $status === $post->post_status ) {
			return true;
		}

		$result = wp_update_post(
			array(
				'ID'          => $post->ID,
				'post_status' => $status,
			),
			true
		);

		if ( is_wp_error( $result ) ) {
			return false;
		}

		self::queue_regeneration();

		return true;
	}

	/**
	 * Service linked to a shipping method instance.
	 *
	 * @param int $instance_id Shipping method instance ID.
	 * @return int Service ID or 0.
	 */
	public static function linked_service( $instance_id ) {
		$instance_id = absint( $instance_id );

		if ( ! $instance_id ) {
			return 0;
		}

		foreach ( ServiceCatalog::posts( false ) as $post ) {
			if ( (int) get_post_meta( $post->ID, ServiceCatalog::META_SHIPPING, true ) === $instance_id ) {
				return (int) $post->ID;
			}
		}

		return 0;
	}

	/**
	 * Create services from selected shipping methods.
	 *
	 * Methods already linked to a service and methods without a fixed
	 * price are skipped.
	 *
	 * @param int[]  $instance_ids Selected shipping method instances.
	 * @param string $base_date    Base price date for the new services.
	 * @return array{created:int,skipped:int,errors:string[]}
	 */
	public static function import_shipping( array $instance_ids, $base_date = '' ) {
		$summary    = array(
			'created' => 0,
			'skipped' => 0,
			'errors'  => array(),
		);
		$selected   = array_map( 'absint', $instance_ids );
		$candidates = ShippingMethods::candidates();

		foreach ( $candidates as $candidate ) {
			if ( ! in_array( (int) $candidate['instance_id'], $selected, true ) ) {
				continue;
			}

			if ( null === $candidate['price'] || $candidate['price'] <= 0 || self::linked_service( $candidate['instance_id'] ) ) {
				++$summary['skipped'];
				continue;
			}

			$result = self::save(
				array(
					'name'       => $candidate['name'],
					'price'      => $candidate['price'],
					'active'     => true,
					'base_price' => $candidate['price'],
					'base_date'  => $base_date,
					'shipping'   => $candidate['instance_id'],
				),
				0,
				'shipping_sync'
			);

			if ( is_wp_error( $result ) ) {
				$summary['errors'][] = $candidate['name'] . ': ' . $result->get_error_message();
				continue;
			}

			update_post_meta( (int) $result, ServiceCatalog::META_AUTO_NAME, $candidate['name'] );
			++$summary['created'];
		}

		return $summary;
	}

	/**
	 * Re-read a shipping method after WooCommerce saved its settings.
	 *
	 * @param mixed $option    Option name.
	 * @param mixed $old_value Previous value.
	 * @param mixed $value     New value.
	 * @return void
	 */
	public static function on_option_updated( $option, $old_value = null, $value = null ) {
		unset( $old_value, $value );

		if ( ! is_string( $option ) ) {
			return;
		}

		if ( in_array( $option, self::tax_options(), true ) ) {
			self::resync_all();
			return;
		}

		if ( ! preg_match( '/^woocommerce_[a-z0-9_]+_(\d+)_settings$/', $option, $match ) ) {
			return;
		}

		self::sync_method( (int) $match[1] );
	}

	/**
	 * Follow a shipping method being enabled or disabled.
	 *
	 * @param int    $instance_id Instance ID.
	 * @param string $method_id   Method type.
	 * @param int    $zone_id     Zone ID.
	 * @param bool   $is_enabled  New state.
	 * @return void
	 */
	public static function on_method_toggled( $instance_id, $method_id = '', $zone_id = 0, $is_enabled = true ) {
		unset( $method_id, $zone_id );

		$service = self::linked_service( $instance_id );

		if ( ! $service ) {
			return;
		}

		if ( $is_enabled ) {
			// The sync relists a service the plugin switched off, if its price is above 0.
			self::sync_method( (int) $instance_id );

			return;
		}

		self::set_active( $service, false, true );
	}

	/**
	 * Switch off the service of a deleted shipping method.
	 *
	 * @param int $instance_id Instance ID.
	 * @return void
	 */
	public static function on_method_deleted( $instance_id ) {
		$service = self::linked_service( $instance_id );

		if ( $service ) {
			self::set_active( $service, false, true );
			delete_post_meta( $service, ServiceCatalog::META_SHIPPING );
		}
	}

	/**
	 * Bring linked services up to date after a shipping method changed.
	 *
	 * Every linked service is re-read, not only the changed method: the
	 * generated name of a flat rate depends on the free-shipping minimum of its
	 * zone, and zone names can change too.
	 *
	 * @param int $instance_id Changed instance ID (kept for the hook signature).
	 * @return void
	 */
	public static function sync_method( $instance_id ) {
		unset( $instance_id );

		$candidates = array();

		foreach ( ShippingMethods::candidates() as $candidate ) {
			$candidates[ (int) $candidate['instance_id'] ] = $candidate;
		}

		foreach ( ServiceCatalog::posts( false ) as $post ) {
			$instance = absint( get_post_meta( $post->ID, ServiceCatalog::META_SHIPPING, true ) );

			// Disabled or deleted methods are handled by their own hooks.
			if ( $instance && isset( $candidates[ $instance ] ) ) {
				self::sync_service( $post, $candidates[ $instance ] );
			}
		}
	}

	/**
	 * Copy name, price and availability of one enabled shipping method.
	 *
	 * @param \WP_Post            $post      Linked service.
	 * @param array<string,mixed> $candidate Shipping candidate.
	 * @return void
	 */
	private static function sync_service( \WP_Post $post, array $candidate ) {
		$auto_name = (string) get_post_meta( $post->ID, ServiceCatalog::META_AUTO_NAME, true );

		// A name the merchant edited is kept; a generated one follows WooCommerce.
		if ( '' !== $auto_name && $post->post_title === $auto_name && $candidate['name'] !== $auto_name ) {
			$renamed = wp_update_post(
				array(
					'ID'         => $post->ID,
					'post_title' => $candidate['name'],
				),
				true
			);

			if ( ! is_wp_error( $renamed ) ) {
				update_post_meta( $post->ID, ServiceCatalog::META_AUTO_NAME, $candidate['name'] );
				self::queue_regeneration();
			}
		}

		if ( null === $candidate['price'] || $candidate['price'] <= 0 ) {
			// A cost formula has no single consumer price, so the last fixed
			// price must not stay listed; a free method is not a paid service
			// (and 0 would block publication). Relisted once a fixed paid
			// price returns.
			if ( 'publish' === $post->post_status ) {
				self::set_active( $post->ID, false, true );
			}

			return;
		}

		if ( ! self::apply_price( $post->ID, self::stored_price( $post->ID ), (float) $candidate['price'], 'shipping_sync' ) ) {
			return;
		}

		if ( 'publish' !== $post->post_status && get_post_meta( $post->ID, ServiceCatalog::META_AUTO_OFF, true ) ) {
			self::set_active( $post->ID, true );
		}
	}

	/**
	 * Default base-price date for a service the shop already offers.
	 *
	 * The statutory reference date once it has passed, otherwise today.
	 *
	 * @return string Y-m-d.
	 */
	public static function default_base_date() {
		$reference = (string) RuleConfig::get( 'general_reference_date', RuleConfig::DEFAULT_GENERAL_DATE );
		$today     = Dates::today();

		return Dates::is_valid_date( $reference ) && $reference <= $today ? $reference : $today;
	}

	/**
	 * Record a new price in the price history, then store it.
	 *
	 * The history row is the legal record, so the stored price only changes
	 * once that row exists.
	 *
	 * @param int        $id        Service ID.
	 * @param float|null $old_price Previous price.
	 * @param float      $price     New price.
	 * @param string     $source    History source.
	 * @return bool False when the history row could not be written.
	 */
	private static function apply_price( $id, $old_price, $price, $source ) {
		if ( null !== $old_price && abs( (float) $old_price - (float) $price ) < 0.0001 ) {
			return true;
		}

		$item = ServiceCatalog::get( $id );

		if ( ! $item ) {
			return false;
		}

		try {
			$row = Plugin::instance()->history()->insert(
				array(
					'product_id'    => (int) $id,
					'item_type'     => 'service',
					'sku'           => '',
					'price_type'    => 'regular',
					'price'         => (float) $price,
					'currency'      => $item->currency,
					'tax_inclusive' => true,
					'valid_from'    => Dates::now_site()->format( 'Y-m-d H:i:s' ),
					'source'        => $source,
					'created_by'    => get_current_user_id(),
				)
			);
		} catch ( \Throwable $error ) {
			$row = 0;
			Logger::error( 'service_price_record_failed', $error->getMessage(), array( 'service_id' => (int) $id ) );
		}

		if ( ! $row ) {
			return false;
		}

		update_post_meta( $id, ServiceCatalog::META_PRICE, Currency::format_decimal_xml( $price ) );

		/** This action is documented in src/Catalog/StandalonePostType.php */
		do_action( 'twbce_cijena_price_changed', (int) $id, 0, $old_price, (float) $price, $source );

		return true;
	}

	/**
	 * Record the base price, or correct it with a reason.
	 *
	 * @param int    $id     Service ID.
	 * @param float  $price  Base price.
	 * @param string $date   Reference date.
	 * @param string $reason Correction reason (required when one exists).
	 * @return true|WP_Error
	 */
	private static function apply_base_price( $id, $price, $date, $reason ) {
		$item = ServiceCatalog::get( $id );

		if ( ! $item instanceof CatalogItem ) {
			return new WP_Error( 'service_not_found', __( 'The service was not found.', 'titanworks-bazna-cijena' ) );
		}

		$plugin   = Plugin::instance();
		$existing = $plugin->history()->latest( $id, 0, 'anchor' );

		if ( $existing && abs( (float) $existing['price'] - (float) $price ) < 0.0001 && (string) $existing['reference_date'] === $date ) {
			return true;
		}

		$args = array(
			'reference_date' => $date,
			'source'         => 'service',
			'tax_inclusive'  => true,
		);

		if ( $existing ) {
			$reason = trim( sanitize_text_field( $reason ) );

			if ( '' === $reason ) {
				return new WP_Error( 'correction_reason_required', __( 'Changing an existing base price requires a correction reason.', 'titanworks-bazna-cijena' ) );
			}

			$args['correction_reason'] = $reason;
		}

		$result = $plugin->anchors()->record( $item, $price, $args );

		return is_wp_error( $result ) ? $result : true;
	}

	/**
	 * Whether a base price differs from the recorded one.
	 *
	 * @param int    $id    Service ID.
	 * @param float  $price Base price.
	 * @param string $date  Reference date.
	 * @return bool False when no base price is recorded yet.
	 */
	private static function base_price_changes( $id, $price, $date ) {
		$existing = Plugin::instance()->history()->latest( (int) $id, 0, 'anchor' );

		if ( ! $existing ) {
			return false;
		}

		return abs( (float) $existing['price'] - (float) $price ) >= 0.0001 || (string) $existing['reference_date'] !== (string) $date;
	}

	/**
	 * Stored price of a service.
	 *
	 * @param int $id Service ID.
	 * @return float|null
	 */
	private static function stored_price( $id ) {
		$value = get_post_meta( (int) $id, ServiceCatalog::META_PRICE, true );

		return '' === $value || null === $value ? null : (float) $value;
	}

	/**
	 * Parse a price typed in Croatian or English notation.
	 *
	 * @param mixed $value Raw value.
	 * @return float|null Non-negative amount or null.
	 */
	public static function amount( $value ) {
		$amount = Currency::to_storage( is_string( $value ) ? trim( $value ) : $value );

		return null === $amount || $amount < 0 ? null : (float) $amount;
	}

	/**
	 * Queue a price-list rebuild after a service enters or leaves the list.
	 *
	 * @return void
	 */
	private static function queue_regeneration() {
		if ( Settings::get( 'regenerate_on_change', true ) ) {
			Scheduler::queue_service_regeneration();
		}
	}
}
