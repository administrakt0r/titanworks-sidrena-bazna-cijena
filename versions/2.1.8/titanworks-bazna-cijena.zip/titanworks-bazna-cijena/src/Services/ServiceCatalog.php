<?php
/**
 * Paid services (delivery, assembly, calibration...) offered to consumers.
 *
 * @package Titanworks\BaznaCijena\Services
 */

namespace Titanworks\BaznaCijena\Services;

use Titanworks\BaznaCijena\Catalog\CatalogItem;
use Titanworks\BaznaCijena\Support\Settings;

defined( 'ABSPATH' ) || exit;

/**
 * Stores services as private posts and exposes them as catalog items.
 *
 * NN 132/2026-1584 čl. 3. st. 3. requires a separate services price list
 * (USLUGE). Webshops usually charge for delivery, and a WooCommerce shipping
 * method is not a product, so services live in their own small store. Each
 * service is a post, so its ID never collides with a product ID in the
 * append-only price history.
 */
final class ServiceCatalog {

	/**
	 * Post type.
	 */
	const POST_TYPE = 'twbce_service';

	/**
	 * Price including VAT.
	 */
	const META_PRICE = '_twbce_service_price';

	/**
	 * Linked WooCommerce shipping method instance ID.
	 */
	const META_SHIPPING = '_twbce_service_shipping';

	/**
	 * Set when the plugin switched a service off because its shipping method
	 * was disabled or deleted, so it is switched back on only in that case.
	 */
	const META_AUTO_OFF = '_twbce_service_auto_off';

	/**
	 * First day the service was offered (Y-m-d).
	 */
	const META_FIRST_SEEN = '_twbce_first_seen';

	/**
	 * Name generated from the shipping method at import. While the title
	 * still equals it, the title follows WooCommerce renames.
	 */
	const META_AUTO_NAME = '_twbce_service_auto_name';

	/**
	 * Register the private post type.
	 *
	 * @return void
	 */
	public static function register() {
		register_post_type(
			self::POST_TYPE,
			array(
				'labels'       => array(
					'name'          => __( 'Services', 'titanworks-bazna-cijena' ),
					'singular_name' => __( 'Service', 'titanworks-bazna-cijena' ),
				),
				'public'       => false,
				'show_ui'      => false,
				'show_in_menu' => false,
				'show_in_rest' => false,
				'rewrite'      => false,
				'query_var'    => false,
				'supports'     => array( 'title' ),
			)
		);
	}

	/**
	 * Whether services are included in the catalog.
	 *
	 * @return bool
	 */
	public static function enabled() {
		return (bool) Settings::get( 'services_enabled', true );
	}

	/**
	 * Service posts.
	 *
	 * @param bool $active_only Only services currently offered.
	 * @return \WP_Post[]
	 */
	public static function posts( $active_only = true ) {
		$posts = get_posts(
			array(
				'post_type'   => self::POST_TYPE,
				'post_status' => $active_only ? 'publish' : array( 'publish', 'draft' ),
				'numberposts' => -1,
				'orderby'     => 'title',
				'order'       => 'ASC',
			)
		);

		return array_values( array_filter( (array) $posts, array( __CLASS__, 'is_service_post' ) ) );
	}

	/**
	 * Active services as catalog items.
	 *
	 * @return CatalogItem[]
	 */
	public static function items() {
		if ( ! self::enabled() ) {
			return array();
		}

		return array_map( array( __CLASS__, 'build_item' ), self::posts() );
	}

	/**
	 * One service as a catalog item, active or not.
	 *
	 * @param int $id Post ID.
	 * @return CatalogItem|null
	 */
	public static function get( $id ) {
		$post = get_post( (int) $id );

		if ( ! self::is_service_post( $post ) ) {
			return null;
		}

		return self::build_item( $post );
	}

	/**
	 * Whether an ID belongs to a service.
	 *
	 * @param int $id Post ID.
	 * @return bool
	 */
	public static function is_service_id( $id ) {
		return (int) $id > 0 && self::POST_TYPE === get_post_type( (int) $id );
	}

	/**
	 * Whether a value is a service post.
	 *
	 * @param mixed $post Candidate.
	 * @return bool
	 */
	public static function is_service_post( $post ) {
		return $post instanceof \WP_Post && self::POST_TYPE === $post->post_type;
	}

	/**
	 * Build a catalog item from a service post.
	 *
	 * @param \WP_Post $post Service post.
	 * @return CatalogItem
	 */
	public static function build_item( \WP_Post $post ) {
		$price      = get_post_meta( $post->ID, self::META_PRICE, true );
		$price      = '' === $price || null === $price ? null : (float) $price;
		$first_seen = (string) get_post_meta( $post->ID, self::META_FIRST_SEEN, true );

		if ( '' === $first_seen ) {
			$first_seen = (string) get_the_date( 'Y-m-d', $post );
		}

		return new CatalogItem(
			array(
				'id'            => (int) $post->ID,
				'type'          => 'service',
				'name'          => (string) $post->post_title,
				'currency'      => function_exists( 'get_woocommerce_currency' ) ? (string) get_woocommerce_currency() : 'EUR',
				'availability'  => 'publish' === $post->post_status ? 'available' : 'unavailable',
				'regular_price' => $price,
				'current_price' => $price,
				// Consumer service prices are entered as the final price incl. VAT.
				'tax_inclusive' => true,
				'first_seen'    => '' !== $first_seen ? $first_seen : null,
				'source'        => 'service',
			)
		);
	}
}
