<?php
/**
 * WooCommerce shipping methods as service candidates.
 *
 * @package Titanworks\BaznaCijena\Services
 */

namespace Titanworks\BaznaCijena\Services;

use Titanworks\BaznaCijena\Support\Currency;

defined( 'ABSPATH' ) || exit;

/**
 * Reads WooCommerce shipping zones and turns each method into a service row.
 *
 * Delivery charged to consumers is a paid service. WooCommerce stores
 * shipping costs without VAT, so the consumer price adds the shipping tax
 * of the store's base location when taxes are enabled.
 */
final class ShippingMethods {

	/**
	 * Method types that have a fixed consumer price.
	 */
	const SUPPORTED = array( 'flat_rate', 'free_shipping', 'local_pickup', 'pickup_location' );

	/**
	 * Service candidates for every enabled shipping method.
	 *
	 * @param array<int,array<string,mixed>>|null $methods Normalised methods (tests), or null to read WooCommerce.
	 * @return array<int,array{instance_id:int,method:string,name:string,zone:string,price:float|null,paid:bool}>
	 */
	public static function candidates( $methods = null ) {
		if ( null === $methods ) {
			$methods = self::read();
		}

		$free_minimums = array();

		foreach ( $methods as $method ) {
			if ( 'free_shipping' === $method['method'] && ! empty( $method['enabled'] ) && null !== self::free_minimum( $method ) ) {
				$free_minimums[ $method['zone'] ] = self::free_minimum( $method );
			}
		}

		$zones = array_unique( array_column( $methods, 'zone' ) );

		$candidates = array();

		foreach ( $methods as $method ) {
			if ( empty( $method['enabled'] ) || ! in_array( $method['method'], self::SUPPORTED, true ) ) {
				continue;
			}

			$net   = self::net_cost( $method );
			$price = null === $net ? null : self::gross( $net, ! empty( $method['taxable'] ) );
			$name  = trim( (string) $method['title'] );

			if ( '' === $name ) {
				$name = (string) $method['method'];
			}

			if ( 'free_shipping' === $method['method'] && null !== self::free_minimum( $method ) ) {
				/* translators: %s: minimum order amount. */
				$name .= ' (' . sprintf( __( 'orders from %s', 'titanworks-bazna-cijena' ), Currency::format( self::free_minimum( $method ) ) ) . ')';
			} elseif ( 'flat_rate' === $method['method'] && isset( $free_minimums[ $method['zone'] ] ) ) {
				/* translators: %s: minimum order amount for free delivery. */
				$name .= ' (' . sprintf( __( 'orders under %s', 'titanworks-bazna-cijena' ), Currency::format( $free_minimums[ $method['zone'] ] ) ) . ')';
			}

			if ( count( $zones ) > 1 && '' !== (string) $method['zone'] ) {
				$name .= ' – ' . $method['zone'];
			}

			$candidates[] = array(
				'instance_id' => (int) $method['instance_id'],
				'method'      => (string) $method['method'],
				'name'        => $name,
				'zone'        => (string) $method['zone'],
				'price'       => $price,
				'paid'        => null !== $price && $price > 0,
			);
		}

		return $candidates;
	}

	/**
	 * Read shipping zones from WooCommerce.
	 *
	 * @return array<int,array<string,mixed>>
	 */
	public static function read() {
		if ( ! class_exists( '\WC_Shipping_Zones' ) ) {
			return array();
		}

		$zones = array();

		foreach ( \WC_Shipping_Zones::get_zones() as $zone ) {
			$zones[] = array(
				'name'    => isset( $zone['zone_name'] ) ? (string) $zone['zone_name'] : '',
				'methods' => isset( $zone['shipping_methods'] ) && is_array( $zone['shipping_methods'] ) ? $zone['shipping_methods'] : array(),
			);
		}

		$rest = \WC_Shipping_Zones::get_zone( 0 );

		if ( $rest ) {
			$zones[] = array(
				'name'    => (string) $rest->get_zone_name(),
				'methods' => $rest->get_shipping_methods(),
			);
		}

		$methods = array();

		foreach ( $zones as $zone ) {
			foreach ( $zone['methods'] as $method ) {
				if ( ! is_object( $method ) || empty( $method->instance_id ) ) {
					continue;
				}

				$methods[] = array(
					'instance_id' => (int) $method->instance_id,
					'method'      => (string) $method->id,
					'title'       => method_exists( $method, 'get_title' ) ? (string) $method->get_title() : '',
					'zone'        => $zone['name'],
					'enabled'     => method_exists( $method, 'is_enabled' ) ? (bool) $method->is_enabled() : true,
					'cost'        => (string) $method->get_option( 'cost', '' ),
					'class_costs' => self::class_costs( $method ),
					'min_amount'  => (string) $method->get_option( 'min_amount', '' ),
					'requires'    => (string) $method->get_option( 'requires', '' ),
					'taxable'     => 'taxable' === $method->get_option( 'tax_status', 'local_pickup' === $method->id ? 'none' : 'taxable' ),
				);
			}
		}

		return $methods;
	}

	/**
	 * Net cost of a method, or null when it is a formula.
	 *
	 * @param array<string,mixed> $method Normalised method.
	 * @return float|null
	 */
	private static function net_cost( array $method ) {
		if ( 'free_shipping' === $method['method'] ) {
			return 0.0;
		}

		// Shipping-class surcharges are added to the base cost per cart, so the
		// method has no single consumer price (WC_Shipping_Flat_Rate::calculate_shipping).
		if ( ! empty( $method['class_costs'] ) ) {
			return null;
		}

		$cost = trim( (string) $method['cost'] );

		if ( '' === $cost ) {
			return 0.0;
		}

		// Costs such as "5 + [qty] * 2" depend on the cart and have no single price.
		return ServiceManager::amount( $cost );
	}

	/**
	 * Non-empty shipping-class cost settings of a flat-rate method.
	 *
	 * @param object $method WooCommerce shipping method.
	 * @return bool
	 */
	private static function class_costs( $method ) {
		if ( 'flat_rate' !== $method->id ) {
			return false;
		}

		// get_option() has already loaded the instance settings.
		$settings = isset( $method->instance_settings ) && is_array( $method->instance_settings ) ? $method->instance_settings : array();

		foreach ( $settings as $key => $value ) {
			if ( ( 'no_class_cost' === $key || 0 === strpos( (string) $key, 'class_cost_' ) ) && '' !== trim( (string) $value ) ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Minimum order amount of a free-shipping method.
	 *
	 * @param array<string,mixed> $method Normalised method.
	 * @return float|null
	 */
	private static function free_minimum( array $method ) {
		if ( ! in_array( (string) $method['requires'], array( 'min_amount', 'either', 'both' ), true ) ) {
			return null;
		}

		$amount = ServiceManager::amount( (string) $method['min_amount'] );

		return null !== $amount && $amount > 0 ? $amount : null;
	}

	/**
	 * Consumer price including the base location's shipping tax.
	 *
	 * @param float $net     Net cost.
	 * @param bool  $taxable Whether the method is taxable.
	 * @return float
	 */
	private static function gross( $net, $taxable ) {
		$net = (float) $net;

		if ( $net <= 0 || ! $taxable || ! function_exists( 'wc_tax_enabled' ) || ! wc_tax_enabled() || ! class_exists( '\WC_Tax' ) || ! function_exists( 'WC' ) ) {
			return round( $net, 2 );
		}

		$class = (string) get_option( 'woocommerce_shipping_tax_class', 'inherit' );
		$class = 'inherit' === $class ? '' : $class;
		$base  = WC()->countries;
		$rates = \WC_Tax::find_shipping_rates(
			array(
				'country'   => $base->get_base_country(),
				'state'     => $base->get_base_state(),
				'postcode'  => $base->get_base_postcode(),
				'city'      => $base->get_base_city(),
				'tax_class' => $class,
			)
		);
		$taxes = \WC_Tax::calc_shipping_tax( $net, $rates );

		return round( $net + array_sum( $taxes ), 2 );
	}
}
