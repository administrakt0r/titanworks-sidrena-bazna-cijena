<?php
/**
 * Public HTML price list.
 *
 * Overridable from a theme as `bazna-cijena/public-price-list.php`.
 *
 * @package BaznaCijena
 *
 * @var array<int,array<mixed>> $rows        Goods rows (current page) with display values.
 * @var array<int,array<mixed>> $service_rows Service rows with display values (first page only).
 * @var array<mixed>            $meta        Build metadata.
 * @var array<mixed>|null       $location    Sales location.
 * @var string                  $q           Search term.
 * @var string                  $type        Type filter.
 * @var int                     $paged       Current page number.
 * @var int                     $per_page    Number of items per page.
 * @var int                     $total_items Total number of filtered items.
 * @var int                     $total_pages Total number of pages.
 * @var string                  $feed_xml    XML feed URL.
 * @var array<string,string>    $feed_services Services feed URLs by extension.
 * @var string                  $feed_csv    CSV feed URL.
 * @var string                  $archive_url Archive page URL.
 */

defined( 'ABSPATH' ) || exit;

$twbce_paged       = isset( $paged ) ? max( 1, (int) $paged ) : 1;
$twbce_per_page    = isset( $per_page ) ? max( 1, (int) $per_page ) : 50;
$twbce_total_items = isset( $total_items ) ? (int) $total_items : count( $rows );
$twbce_total_pages = isset( $total_pages ) ? (int) $total_pages : 1;
$twbce_services    = isset( $service_rows ) ? (array) $service_rows : array();
?>
<div class="bazna-cijena-cjenik">
	<?php if ( ! empty( $location ) ) : ?>
		<p class="bazna-cijena-cjenik__meta">
			<?php
			$twbce_generated_at = isset( $meta['generated_at'] ) ? \Titanworks\BaznaCijena\Support\Dates::format_datetime_display( (string) $meta['generated_at'] ) : '';
			printf(
				/* translators: 1: sales location name, 2: legal rule version, 3: generation timestamp. */
				esc_html__( 'Sales location: %1$s. Rule version: %2$s. Generated: %3$s.', 'titanworks-bazna-cijena' ),
				// One list for every location is filed as ZA_SVA_PRODAJNA_MJESTA; name it the same way.
				esc_html( \Titanworks\BaznaCijena\Export\GenerationService::single_list_mode() ? __( 'all sales locations', 'titanworks-bazna-cijena' ) : (string) $location['name'] ),
				esc_html( isset( $meta['rule_version'] ) ? (string) $meta['rule_version'] : '' ),
				esc_html( $twbce_generated_at )
			);
			?>
		</p>
	<?php endif; ?>

	<form method="get" class="bazna-cijena-cjenik__search">
		<label for="bazna-cijena-q"><?php esc_html_e( 'Search', 'titanworks-bazna-cijena' ); ?></label>
		<input type="search" id="bazna-cijena-q" name="q" value="<?php echo esc_attr( $q ); ?>" placeholder="<?php echo esc_attr__( 'Search catalog items', 'titanworks-bazna-cijena' ); ?>" autocomplete="off" />
		<label for="bazna-cijena-type"><?php esc_html_e( 'Type', 'titanworks-bazna-cijena' ); ?></label>
		<select name="type" id="bazna-cijena-type">
			<option value=""><?php esc_html_e( 'All', 'titanworks-bazna-cijena' ); ?></option>
			<option value="proizvod" <?php selected( $type, 'proizvod' ); ?>><?php esc_html_e( 'Products', 'titanworks-bazna-cijena' ); ?></option>
			<option value="usluga" <?php selected( $type, 'usluga' ); ?>><?php esc_html_e( 'Services', 'titanworks-bazna-cijena' ); ?></option>
		</select>
		<button type="submit"><?php esc_html_e( 'Filter', 'titanworks-bazna-cijena' ); ?></button>
		<?php if ( '' !== $q || '' !== $type ) : ?>
			<a href="<?php echo esc_url( remove_query_arg( array( 'q', 'type', 'paged' ) ) ); ?>" class="bazna-cijena-cjenik__clear"><?php esc_html_e( 'Clear filters', 'titanworks-bazna-cijena' ); ?></a>
		<?php endif; ?>
	</form>

	<p class="bazna-cijena-cjenik__count" aria-live="polite">
		<?php if ( $twbce_total_items > 0 ) : ?>
			<?php
			$twbce_from = ( ( $twbce_paged - 1 ) * $twbce_per_page ) + 1;
			$twbce_to   = min( $twbce_total_items, $twbce_from + count( $rows ) - 1 );
			?>
			<?php
			printf(
				/* translators: 1: start row index, 2: end row index, 3: total number of rows. */
				esc_html__( 'Showing %1$d–%2$d of %3$d items.', 'titanworks-bazna-cijena' ),
				(int) $twbce_from,
				(int) $twbce_to,
				(int) $twbce_total_items
			);
			?>
		<?php elseif ( ! empty( $twbce_services ) ) : ?>
			<?php
			printf(
				/* translators: 1: start row index, 2: end row index, 3: total number of rows. */
				esc_html__( 'Showing %1$d–%2$d of %3$d items.', 'titanworks-bazna-cijena' ),
				1,
				count( $twbce_services ),
				count( $twbce_services )
			);
			?>
		<?php elseif ( '' !== $q || '' !== $type ) : ?>
			<?php esc_html_e( 'No items match this filter.', 'titanworks-bazna-cijena' ); ?>
		<?php else : ?>
			<?php esc_html_e( 'No catalog items found.', 'titanworks-bazna-cijena' ); ?>
		<?php endif; ?>
	</p>

	<?php if ( ! empty( $rows ) ) : ?>
	<div class="bazna-cijena-table-container" role="region" tabindex="0" aria-label="<?php esc_attr_e( 'Price list with the base price', 'titanworks-bazna-cijena' ); ?>">
		<table class="bazna-cijena-table">
			<caption><?php esc_html_e( 'Price list with the base price', 'titanworks-bazna-cijena' ); ?></caption>
			<thead>
				<tr>
					<?php // Columns follow the statutory order of NN 132/2026-1584 čl. 3., as in the CSV and XML files. ?>
					<th scope="col"><?php esc_html_e( 'Product name', 'titanworks-bazna-cijena' ); ?></th>
					<th scope="col"><?php esc_html_e( 'SKU', 'titanworks-bazna-cijena' ); ?></th>
					<th scope="col"><?php esc_html_e( 'Brand', 'titanworks-bazna-cijena' ); ?></th>
					<th scope="col"><?php esc_html_e( 'Net quantity', 'titanworks-bazna-cijena' ); ?></th>
					<th scope="col"><?php esc_html_e( 'Unit of measure', 'titanworks-bazna-cijena' ); ?></th>
					<th scope="col"><?php esc_html_e( 'Retail price', 'titanworks-bazna-cijena' ); ?></th>
					<th scope="col"><?php esc_html_e( 'Special form of sale', 'titanworks-bazna-cijena' ); ?></th>
					<th scope="col"><?php esc_html_e( 'Price per unit of measure', 'titanworks-bazna-cijena' ); ?></th>
					<th scope="col"><?php esc_html_e( 'Barcode', 'titanworks-bazna-cijena' ); ?></th>
					<th scope="col"><?php esc_html_e( 'EAN barcode', 'titanworks-bazna-cijena' ); ?></th>
					<th scope="col"><?php esc_html_e( 'Base price', 'titanworks-bazna-cijena' ); ?></th>
					<?php // Not a price-list column: the 30-day low shown with a price reduction (ZZP čl. 13.a). ?>
					<th scope="col"><?php esc_html_e( 'Lowest price in the last 30 days', 'titanworks-bazna-cijena' ); ?></th>
				</tr>
			</thead>
			<tbody>
				<?php foreach ( $rows as $twbce_row ) : ?>
					<tr>
						<td><?php echo esc_html( (string) $twbce_row['naziv'] ); ?></td>
						<td><?php echo esc_html( (string) $twbce_row['sifra'] ); ?></td>
						<td><?php echo esc_html( (string) $twbce_row['marka'] ); ?></td>
						<td><?php echo esc_html( isset( $twbce_row['neto_kolicina'] ) ? (string) $twbce_row['neto_kolicina'] : '' ); ?></td>
						<td><?php echo esc_html( (string) $twbce_row['jedinica_mjere'] ); ?></td>
						<td><?php echo esc_html( (string) $twbce_row['retail_display'] ); ?></td>
						<td><?php echo esc_html( (string) $twbce_row['sale_display'] ); ?></td>
						<td><?php echo esc_html( (string) $twbce_row['unit_price_display'] ); ?></td>
						<td><?php echo esc_html( (string) $twbce_row['barkod'] ); ?></td>
						<td><?php echo esc_html( isset( $twbce_row['ean_barkod'] ) ? (string) $twbce_row['ean_barkod'] : '' ); ?></td>
						<td>
							<?php echo esc_html( (string) $twbce_row['anchor_display'] ); ?>
							<?php if ( '' !== (string) $twbce_row['anchor_display'] && ! empty( $twbce_row['reference_display'] ) ) : ?>
								<?php // Each item shows its own reference date (or first-offer day). ?>
								<span class="bazna-cijena-table__date"><?php echo esc_html( (string) $twbce_row['reference_display'] ); ?></span>
							<?php endif; ?>
						</td>
						<td><?php echo esc_html( (string) $twbce_row['lowest_30_day_display'] ); ?></td>
					</tr>
				<?php endforeach; ?>
			</tbody>
		</table>
	</div>
	<?php endif; ?>

	<?php if ( ! empty( $twbce_services ) ) : ?>
	<h2 class="bazna-cijena-cjenik__subtitle"><?php esc_html_e( 'Services', 'titanworks-bazna-cijena' ); ?></h2>
	<div class="bazna-cijena-table-container" role="region" tabindex="0" aria-label="<?php esc_attr_e( 'Services price list with the base price', 'titanworks-bazna-cijena' ); ?>">
		<table class="bazna-cijena-table bazna-cijena-table--services">
			<caption><?php esc_html_e( 'Services price list with the base price', 'titanworks-bazna-cijena' ); ?></caption>
			<thead>
				<tr>
					<?php // Statutory services columns (NN 132/2026-1584), as in the USLUGE CSV and XML files. ?>
					<th scope="col"><?php esc_html_e( 'Service name', 'titanworks-bazna-cijena' ); ?></th>
					<th scope="col"><?php esc_html_e( 'Retail price', 'titanworks-bazna-cijena' ); ?></th>
					<th scope="col"><?php esc_html_e( 'Special form of sale', 'titanworks-bazna-cijena' ); ?></th>
					<th scope="col"><?php esc_html_e( 'Base price', 'titanworks-bazna-cijena' ); ?></th>
				</tr>
			</thead>
			<tbody>
				<?php foreach ( $twbce_services as $twbce_row ) : ?>
					<tr>
						<td><?php echo esc_html( (string) $twbce_row['naziv'] ); ?></td>
						<td><?php echo esc_html( (string) $twbce_row['retail_display'] ); ?></td>
						<td><?php echo esc_html( (string) $twbce_row['sale_display'] ); ?></td>
						<td>
							<?php echo esc_html( (string) $twbce_row['anchor_display'] ); ?>
							<?php if ( '' !== (string) $twbce_row['anchor_display'] && ! empty( $twbce_row['reference_display'] ) ) : ?>
								<span class="bazna-cijena-table__date"><?php echo esc_html( (string) $twbce_row['reference_display'] ); ?></span>
							<?php endif; ?>
						</td>
					</tr>
				<?php endforeach; ?>
			</tbody>
		</table>
	</div>
	<?php endif; ?>

	<?php if ( $twbce_total_pages > 1 ) : ?>
		<nav class="bazna-cijena-pagination" aria-label="<?php esc_attr_e( 'Price list pagination', 'titanworks-bazna-cijena' ); ?>">
			<?php
			echo wp_kses_post(
				paginate_links(
					array(
						'base'               => add_query_arg( 'paged', '%#%' ),
						'format'             => '',
						'current'            => $twbce_paged,
						'total'              => $twbce_total_pages,
						'prev_text'          => '&laquo; ' . __( 'Previous', 'titanworks-bazna-cijena' ),
						'next_text'          => __( 'Next', 'titanworks-bazna-cijena' ) . ' &raquo;',
						'before_page_number' => '<span class="screen-reader-text">' . __( 'Page', 'titanworks-bazna-cijena' ) . ' </span>',
					)
				)
			);
			?>
		</nav>
	<?php endif; ?>

	<p class="bazna-cijena-cjenik__links">
		<a href="<?php echo esc_url( $feed_xml ); ?>"><?php esc_html_e( 'XML Feed', 'titanworks-bazna-cijena' ); ?></a>
		<a href="<?php echo esc_url( $feed_csv ); ?>"><?php esc_html_e( 'CSV Feed', 'titanworks-bazna-cijena' ); ?></a>
		<?php foreach ( ( isset( $feed_services ) ? (array) $feed_services : array() ) as $twbce_ext => $twbce_url ) : ?>
			<a href="<?php echo esc_url( (string) $twbce_url ); ?>"><?php echo esc_html( sprintf( /* translators: %s: file format (CSV or XML). */ __( 'Services %s Feed', 'titanworks-bazna-cijena' ), strtoupper( (string) $twbce_ext ) ) ); ?></a>
		<?php endforeach; ?>
		<a href="<?php echo esc_url( $archive_url ); ?>"><?php esc_html_e( 'Archive', 'titanworks-bazna-cijena' ); ?></a>
	</p>
	<?php \Titanworks\BaznaCijena\Api\PublicPage::render_credit(); ?>
</div>
