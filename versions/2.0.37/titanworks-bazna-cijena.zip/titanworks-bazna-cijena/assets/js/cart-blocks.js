( function () {
	if (
		! window.wc ||
		! window.wc.blocksCheckout ||
		typeof window.wc.blocksCheckout.registerCheckoutFilters !== 'function'
	) {
		return;
	}

	window.wc.blocksCheckout.registerCheckoutFilters( 'titanworks-bazna-cijena', {
		cartItemPrice: function ( defaultValue, extensions ) {
			var extension = extensions && (
				extensions[ 'titanworks-bazna-cijena' ] ||
				extensions[ 'titanworks-sidrena-bazna-cijena' ]
			);
			var reference = extension && extension.cartPriceSuffix;

			if ( typeof reference !== 'string' || reference === '' ) {
				return defaultValue;
			}

			return defaultValue + ' ' + reference;
		},
	} );
} )();
