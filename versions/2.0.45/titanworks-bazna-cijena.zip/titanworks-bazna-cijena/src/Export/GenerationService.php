<?php
/**
 * Price-list generation service.
 *
 * @package Titanworks\BaznaCijena\Export
 */

namespace Titanworks\BaznaCijena\Export;

use Titanworks\BaznaCijena\Catalog\CatalogItem;
use Titanworks\BaznaCijena\Catalog\CatalogProvider;
use Titanworks\BaznaCijena\Compliance\RemediationProposer;
use Titanworks\BaznaCijena\Database\LocationRepository;
use Titanworks\BaznaCijena\Database\PriceHistoryRepository;
use Titanworks\BaznaCijena\Database\PublicationRepository;
use Titanworks\BaznaCijena\Database\SpecialSaleRepository;
use Titanworks\BaznaCijena\Logging\Logger;
use Titanworks\BaznaCijena\Plugin;
use Titanworks\BaznaCijena\Support\Settings;

defined( 'ABSPATH' ) || exit;

/**
 * Builds and publishes the daily price lists per sales location and format.
 */
class GenerationService {

	/**
	 * Catalog provider.
	 *
	 * @var CatalogProvider
	 */
	protected $catalog;

	/**
	 * Location repository.
	 *
	 * @var LocationRepository
	 */
	protected $locations;

	/**
	 * Publication repository.
	 *
	 * @var PublicationRepository
	 */
	protected $publications;

	/**
	 * Price history repository.
	 *
	 * @var PriceHistoryRepository
	 */
	protected $history;

	/**
	 * Special sale repository.
	 *
	 * @var SpecialSaleRepository
	 */
	protected $sales;

	/**
	 * Constructor.
	 *
	 * @param CatalogProvider        $catalog      Catalog provider.
	 * @param LocationRepository     $locations    Location repository.
	 * @param PublicationRepository  $publications Publication repository.
	 * @param PriceHistoryRepository $history      Price history repository.
	 * @param SpecialSaleRepository  $sales        Special sale repository.
	 */
	public function __construct( CatalogProvider $catalog, LocationRepository $locations, PublicationRepository $publications, PriceHistoryRepository $history, SpecialSaleRepository $sales ) {
		$this->catalog      = $catalog;
		$this->locations    = $locations;
		$this->publications = $publications;
		$this->history      = $history;
		$this->sales        = $sales;
	}

	/**
	 * Generate price lists for every active location.
	 *
	 * @param array<mixed> $args Arguments: `source` (`scheduled|manual|cli`), `type`, `force`.
	 * @return array<mixed>
	 */
	public function generate_all( array $args = array() ) {
		if ( ! isset( $args['items'] ) ) {
			$args['items'] = $this->hydrate_catalog( $args );
		}

		$results = array();

		foreach ( $this->locations->all( true ) as $location ) {
			$results[ (int) $location['id'] ] = $this->generate_location( (int) $location['id'], $args );
		}

		return $results;
	}

	/**
	 * Generate all configured formats for one location.
	 *
	 * @param int          $location_id Location ID.
	 * @param array<mixed> $args        Arguments.
	 * @return array<mixed>|\WP_Error
	 */
	public function generate_location( $location_id, array $args = array() ) {
		$location = $this->locations->get( $location_id );

		if ( ! $location ) {
			return new \WP_Error( 'location_not_found', __( 'The sales location could not be found.', 'titanworks-bazna-cijena' ) );
		}

		if ( ! isset( $args['items'] ) ) {
			$args['items'] = $this->hydrate_catalog( $args );
		}

		if ( ! isset( $args['validation'] ) ) {
			$args['validation'] = $this->catalog_report( $location_id, $args['items'] );
		}

		if ( ! isset( $args['build'] ) ) {
			$args['build'] = $this->builder()->build( $location, $args );
		}

		$results = array();

		foreach ( $this->formats( $location ) as $format ) {
			$results[ $format ] = $this->generate( $location_id, $format, $args );
		}

		return $results;
	}

	/**
	 * Generate one price list.
	 *
	 * @param int          $location_id Location ID.
	 * @param string       $format      Format (`csv` or `xml`).
	 * @param array<mixed> $args        Arguments.
	 * @return array<mixed>|\WP_Error
	 */
	public function generate( $location_id, $format, array $args = array() ) {
		$location = $this->locations->get( $location_id );

		if ( ! $location ) {
			return new \WP_Error( 'location_not_found', __( 'The sales location could not be found.', 'titanworks-bazna-cijena' ) );
		}

		$format = strtolower( (string) $format );

		if ( ! in_array( $format, array( 'csv', 'xml' ), true ) ) {
			return new \WP_Error( 'invalid_format', __( 'The requested format is not supported.', 'titanworks-bazna-cijena' ) );
		}

		$source            = isset( $args['source'] ) ? (string) $args['source'] : 'manual';
		$event             = 'scheduled' === $source ? 'export_scheduled' : 'export_manual';
		$force             = ! empty( $args['force'] );
		$allow_with_errors = $force || (bool) Settings::get( 'allow_generation_with_errors', true );

		$identifier = isset( $location['identifier'] ) ? trim( (string) $location['identifier'] ) : '';
		$findings   = array();

		if ( '' === $identifier ) {
			$findings[] = array(
				'code'           => 'missing_store_identifier',
				'severity'       => 'ERROR',
				'message'        => __( 'The sales location has no facility identifier.', 'titanworks-bazna-cijena' ),
				'proposal'       => RemediationProposer::propose( 'missing_store_identifier', array( 'name' => $location['name'] ) ),
				'entity_type'    => 'location',
				'entity_id'      => (int) $location_id,
				'rule_reference' => 'FR-040',
			);

			if ( ! $force ) {
				$this->record_failure( $location_id, $format, $findings );

				return new \WP_Error( 'missing_store_identifier', $findings[0]['message'], array( 'findings' => $findings ) );
			}

			// Safe fallback identifier for filename and price list export when forced.
			$location['identifier'] = 'P1';
		}

		// Ensure address and city are populated for filename generation.
		if ( empty( $location['address'] ) ) {
			$wc_addr             = (string) get_option( 'woocommerce_store_address', '' );
			$location['address'] = '' !== $wc_addr ? $wc_addr : __( 'Online', 'titanworks-bazna-cijena' );
		}
		if ( empty( $location['city'] ) ) {
			$wc_city          = (string) get_option( 'woocommerce_store_city', '' );
			$location['city'] = '' !== $wc_city ? $wc_city : __( 'Hrvatska', 'titanworks-bazna-cijena' );
		}

		if ( ! isset( $args['items'] ) ) {
			$args['items'] = $this->hydrate_catalog( $args );
		}

		$validation   = isset( $args['validation'] ) && is_array( $args['validation'] )
			? $args['validation']
			: $this->catalog_report( $location_id, $args['items'] );
		$blockers     = self::publication_blockers( $validation['errors'] );
		$all_blockers = array_merge( $findings, $blockers );

		if ( ! empty( $all_blockers ) && ! $allow_with_errors ) {
			$this->record_failure( $location_id, $format, $all_blockers );

			return new \WP_Error( 'validation_failed', __( 'The price list failed compliance validation and was not published.', 'titanworks-bazna-cijena' ), array( 'findings' => $all_blockers ) );
		}

		$proposals = array();
		foreach ( $all_blockers as &$b_finding ) {
			if ( empty( $b_finding['proposal'] ) ) {
				$code = isset( $b_finding['code'] ) ? (string) $b_finding['code'] : '';
				$ctx  = isset( $b_finding['context'] ) && is_array( $b_finding['context'] ) ? $b_finding['context'] : array();

				$b_finding['proposal'] = RemediationProposer::propose( $code, $ctx );
			}
			if ( ! empty( $b_finding['proposal'] ) ) {
				$proposals[] = $b_finding['proposal'];
			}
		}
		unset( $b_finding );

		$build = isset( $args['build'] ) && is_array( $args['build'] )
			? $args['build']
			: $this->builder()->build( $location, $args );

		$items = $build['items'];
		$meta  = $build['meta'];

		$fingerprint = $this->builder()->fingerprint( $items, $location, $format, (string) $meta['rule_version'] );

		$content = 'xml' === $format
			? function ( $handle, $hash_ctx ) use ( $items, $location, $meta ) {
				return ( new XmlWriter() )->write_stream( $handle, $items, $location, $meta, $hash_ctx );
			}
			: function ( $handle, $hash_ctx ) use ( $items ) {
				return ( new CsvWriter() )->write_stream( $handle, $items, $hash_ctx );
			};

		$result = $this->publisher()->publish(
			$location,
			$format,
			$content,
			array(
				'fingerprint'        => $fingerprint,
				'item_count'         => count( $items ),
				'rule_version'       => (string) $meta['rule_version'],
				'validation_summary' => array(
					'errors'    => count( $all_blockers ),
					'warnings'  => (int) $validation['warnings'] + count( $validation['errors'] ) - count( $blockers ),
					'findings'  => $all_blockers,
					'proposals' => $proposals,
				),
				'force'              => $force,
			)
		);

		if ( is_wp_error( $result ) ) {
			$failure_findings = array(
				array(
					'code'           => (string) $result->get_error_code(),
					'severity'       => 'ERROR',
					'message'        => $result->get_error_message(),
					'proposal'       => __( 'Check directory permissions and disk space in the uploads folder.', 'titanworks-bazna-cijena' ),
					'entity_type'    => 'publication',
					'entity_id'      => (int) $location_id,
					'rule_reference' => 'FR-040',
				),
			);

			$this->record_failure( $location_id, $format, $failure_findings, 'The price list could not be published.' );

			return $result;
		}

		if ( ! empty( $all_blockers ) ) {
			Logger::warning(
				'export_warning',
				'Price list generated with compliance findings. Remediation proposed.',
				array(
					'location_id' => (int) $location_id,
					'format'      => $format,
					'filename'    => isset( $result['filename'] ) ? $result['filename'] : '',
					'items'       => count( $items ),
					'findings'    => count( $all_blockers ),
					'proposals'   => count( $proposals ),
				)
			);
		} else {
			Logger::info(
				$event,
				empty( $result['skipped'] ) ? 'Price list published.' : 'Price list unchanged; the current version was kept.',
				array(
					'location_id' => (int) $location_id,
					'format'      => $format,
					'filename'    => isset( $result['filename'] ) ? $result['filename'] : '',
					'items'       => count( $items ),
					'skipped'     => ! empty( $result['skipped'] ),
				)
			);
		}

		return array(
			'location_id' => (int) $location_id,
			'format'      => $format,
			'filename'    => isset( $result['filename'] ) ? $result['filename'] : '',
			'item_count'  => count( $items ),
			'skipped'     => ! empty( $result['skipped'] ),
			'publication' => isset( $result['publication'] ) ? $result['publication'] : null,
			'has_errors'  => ! empty( $all_blockers ),
			'findings'    => $all_blockers,
			'proposals'   => $proposals,
		);
	}

	/**
	 * Formats enabled for a location.
	 *
	 * @param array<mixed> $location Location row.
	 * @return string[]
	 */
	public function formats( array $location ) {
		$settings = (array) Settings::get( 'formats', array( 'csv', 'xml' ) );
		$config   = isset( $location['price_list_config'] ) && is_array( $location['price_list_config'] ) ? $location['price_list_config'] : array();

		if ( ! empty( $config['formats'] ) ) {
			$settings = array_intersect( $settings, (array) $config['formats'] );
		}

		$formats = array_values( array_intersect( array( 'csv', 'xml' ), $settings ) );

		return empty( $formats ) ? array( 'csv', 'xml' ) : $formats;
	}

	/**
	 * Catalog-level findings for a location, split by severity.
	 *
	 * @param int                                                   $location_id Location ID.
	 * @param array<int,CatalogItem>|\Traversable<CatalogItem>|null $items       Optional pre-hydrated catalog items.
	 * @return array{errors:array<mixed>,warnings:int}
	 */
	protected function catalog_report( $location_id, $items = null ) {
		$validator = Plugin::instance()->validator();

		$validate_args = array(
			'scope'       => 'catalog',
			'location_id' => (int) $location_id,
		);

		if ( is_array( $items ) || $items instanceof \Traversable ) {
			$validate_args['items'] = $items;
		}

		$report = $validator->validate( $validate_args );

		$errors   = array();
		$warnings = 0;

		foreach ( $report['findings'] as $finding ) {
			if ( 'ERROR' === $finding->severity ) {
				$errors[] = $finding->to_array();
				continue;
			}

			++$warnings;
		}

		return array(
			'errors'   => $errors,
			'warnings' => $warnings,
		);
	}

	/**
	 * Hydrate catalog items into an array once for reuse.
	 *
	 * @param array<mixed> $args Arguments.
	 * @return array<int,CatalogItem>
	 */
	protected function hydrate_catalog( array $args = array() ) {
		$type = isset( $args['type'] ) ? (string) $args['type'] : 'all';

		/** @var mixed $iter */
		$iter = $this->catalog->iterate(
			array(
				'type'               => $type,
				'include_variations' => true,
			)
		);

		if ( ! is_iterable( $iter ) ) {
			return array();
		}

		$items = array();

		foreach ( $iter as $item ) {
			if ( $item instanceof CatalogItem ) {
				$items[] = $item;
			}
		}

		return $items;
	}

	/**
	 * Missing retail/anchor evidence and unusable active-promotion references
	 * prevent a cjenik publication. Other findings remain warnings.
	 *
	 * @param array<mixed> $errors Error findings.
	 * @return array<mixed>
	 */
	public static function publication_blockers( array $errors ) {
		$required = array(
			'missing_anchor_price',
			'invalid_anchor_date',
			'invalid_retail_price',
			'missing_sale_type',
			'missing_30_day_price',
			'sale_price_not_below_reference',
		);

		return array_values(
			array_filter(
				$errors,
				static function ( $finding ) use ( $required ) {
					return isset( $finding['code'] ) && in_array( $finding['code'], $required, true );
				}
			)
		);
	}

	/**
	 * Store a failed publication row so the attempt stays auditable.
	 *
	 * @param int          $location_id Location ID.
	 * @param string       $format      Format.
	 * @param array<mixed> $findings    Findings.
	 * @param string       $message     Optional error log message.
	 * @return void
	 */
	protected function record_failure( $location_id, $format, array $findings, $message = '' ) {
		$id = $this->publications->insert(
			array(
				'location_id'        => (int) $location_id,
				'format'             => (string) $format,
				'status'             => 'failed',
				'rule_version'       => (string) \Titanworks\BaznaCijena\Compliance\RuleConfig::get( 'rule_version', '' ),
				'validation_summary' => $findings,
			)
		);

		Logger::error(
			'export_failed',
			'' !== $message ? $message : 'Price-list generation was blocked by validation.',
			array(
				'location_id' => (int) $location_id,
				'format'      => (string) $format,
				'findings'    => count( $findings ),
			)
		);

		/**
		 * Fires when a price-list publication fails.
		 *
		 * @param int          $location_id Location ID.
		 * @param string       $format      Format.
		 * @param array<mixed> $findings    Failure findings.
		 */
		do_action( 'twbce_cijena_publication_failed', $location_id, $format, $findings );
	}

	/**
	 * Row builder.
	 *
	 * @return PriceListBuilder
	 */
	protected function builder() {
		return new PriceListBuilder( $this->catalog, $this->history, $this->sales );
	}

	/**
	 * Publisher.
	 *
	 * @return Publisher
	 */
	protected function publisher() {
		return new Publisher( $this->locations, $this->publications, new FilenameGenerator() );
	}
}
