/**
 * Titanworks Bazna Cijena - variation anchor updates.
 *
 * Updates the anchor price shown on variable product pages when a variation
 * is selected. Uses WooCommerce's variation events when jQuery is present.
 */
( function () {
	'use strict';

	function isElementForProduct( element, root, productId ) {
		if ( ! element ) {
			return false;
		}

		// When data-product-id is present on the block wrapper, require it to match this product.
		var wrapper = element.closest ? element.closest( '.bazna-cijena' ) : null;
		if ( wrapper && productId ) {
			var wrapperPid = wrapper.getAttribute( 'data-product-id' );
			if ( wrapperPid && String( wrapperPid ) !== String( productId ) ) {
				return false;
			}
		}

		// Exclude elements inside nested related or upsell product cards.
		if ( element.closest && root ) {
			var nestedSection = element.closest( '.related, .upsells, .up-sells, .cross-sells' );
			if ( nestedSection && root.contains( nestedSection ) ) {
				return false;
			}
			var closestProduct = element.closest( '.product' );
			if ( closestProduct && closestProduct !== root && root.contains( closestProduct ) ) {
				return false;
			}
		}

		return true;
	}

	function update( data, root, productId ) {
		if ( ! root || ! root.querySelectorAll ) {
			return;
		}

		var nodes = root.querySelectorAll( '[data-bazna-cijena-anchor]' );
		var display = data && data.twbce_cijena_anchor ? data.twbce_cijena_anchor : '';
		var date = data && data.twbce_cijena_reference_date_display ? data.twbce_cijena_reference_date_display : '';
		var isoDate = data && data.twbce_cijena_reference_date ? data.twbce_cijena_reference_date : '';

		for ( var i = 0; i < nodes.length; i++ ) {
			if ( ! isElementForProduct( nodes[ i ], root, productId ) ) {
				continue;
			}
			nodes[ i ].textContent = display;
			if ( ! nodes[ i ].hasAttribute( 'aria-live' ) ) {
				nodes[ i ].setAttribute( 'aria-live', 'polite' );
			}
		}

		var dateNodes = root.querySelectorAll( '[data-bazna-cijena-reference-date]' );
		for ( var j = 0; j < dateNodes.length; j++ ) {
			if ( ! isElementForProduct( dateNodes[ j ], root, productId ) ) {
				continue;
			}
			var template = '';
			var wrapper = dateNodes[ j ].closest
				? dateNodes[ j ].closest( '[data-bazna-cijena-date-template]' )
				: null;

			if ( wrapper ) {
				template = wrapper.getAttribute( 'data-bazna-cijena-date-template' ) || '';
			}

			if ( date ) {
				dateNodes[ j ].textContent = template ? template.replace( '%s', date ) : date;
				dateNodes[ j ].removeAttribute( 'hidden' );
				dateNodes[ j ].style.display = '';
			} else {
				dateNodes[ j ].textContent = '';
				dateNodes[ j ].setAttribute( 'hidden', 'hidden' );
				dateNodes[ j ].style.display = 'none';
			}
		}

		var labelNodes = root.querySelectorAll( '[data-bazna-cijena-label]' );
		for ( var k = 0; k < labelNodes.length; k++ ) {
			if ( ! isElementForProduct( labelNodes[ k ], root, productId ) ) {
				continue;
			}
			var labelWrapper = labelNodes[ k ].closest
				? labelNodes[ k ].closest( '[data-bazna-cijena-label-template]' )
				: null;

			if ( labelWrapper ) {
				var labelTemplate = labelWrapper.getAttribute( 'data-bazna-cijena-label-template' ) || '';
				if ( labelTemplate ) {
					var replaced = labelTemplate
						.replace( /\{datum\}|\{date\}/g, date )
						.replace( /\{datum_iso\}/g, isoDate );
					if ( ! date && ! isoDate ) {
						replaced = replaced.replace( /\s+/g, ' ' ).replace( /^[\s:()]+|[\s:()]+$/g, '' );
					}
					labelNodes[ k ].textContent = replaced;
				}
			}
		}

		var anchorBlocks = root.querySelectorAll( '.bazna-cijena__anchor' );
		for ( var a = 0; a < anchorBlocks.length; a++ ) {
			if ( ! isElementForProduct( anchorBlocks[ a ], root, productId ) ) {
				continue;
			}
			anchorBlocks[ a ].style.display = display ? '' : 'none';
		}

		var thirtyDayNodes = root.querySelectorAll( '[data-bazna-cijena-30-day]' );
		var display30 = data && data.twbce_cijena_30_day ? data.twbce_cijena_30_day : '';
		for ( var t = 0; t < thirtyDayNodes.length; t++ ) {
			if ( ! isElementForProduct( thirtyDayNodes[ t ], root, productId ) ) {
				continue;
			}
			thirtyDayNodes[ t ].textContent = display30;
			var wrap30 = thirtyDayNodes[ t ].closest ? thirtyDayNodes[ t ].closest( '.bazna-cijena--30-day' ) : null;
			if ( wrap30 ) {
				wrap30.style.display = display30 ? '' : 'none';
			}
		}

		// Support themes with custom selected price summaries (e.g. GrowShop.hr .growshophr-selected-price).
		var customPriceWrappers = root.querySelectorAll( '.growshophr-selected-price, .selected-variation-price, [data-selected-variation-price]' );
		if ( ( ! customPriceWrappers || ! customPriceWrappers.length ) && document ) {
			customPriceWrappers = document.querySelectorAll( '.growshophr-selected-price, .selected-variation-price' );
		}
		for ( var cp = 0; cp < customPriceWrappers.length; cp++ ) {
			var customWrap = customPriceWrappers[ cp ];
			var existing = customWrap.querySelectorAll( '.bazna-cijena' );
			for ( var e = 0; e < existing.length; e++ ) {
				existing[ e ].parentNode.removeChild( existing[ e ] );
			}
			if ( data && data.price_html && data.price_html.indexOf( 'bazna-cijena' ) !== -1 ) {
				var tempDiv = document.createElement( 'div' );
				tempDiv.innerHTML = data.price_html;
				var baznaNodes = tempDiv.querySelectorAll( '.bazna-cijena' );
				for ( var bn = 0; bn < baznaNodes.length; bn++ ) {
					customWrap.appendChild( baznaNodes[ bn ] );
				}
			}
		}
	}

	function repositionTooltip( popup ) {
		if ( ! popup || ! popup.getBoundingClientRect ) {
			return;
		}

		var wrap = popup.closest ? popup.closest( '.bazna-cijena__tooltip-wrap' ) : popup.parentNode;

		popup.classList.remove( 'bazna-cijena__tooltip-popup--flipped-down' );
		if ( wrap && wrap.classList ) {
			wrap.classList.remove( 'has-flipped-down' );
		}
		popup.style.left = '';
		popup.style.removeProperty( '--bazna-arrow-left' );

		var rect = popup.getBoundingClientRect();
		var viewportWidth = window.innerWidth || document.documentElement.clientWidth;

		if ( rect.top < 10 ) {
			popup.classList.add( 'bazna-cijena__tooltip-popup--flipped-down' );
			if ( wrap && wrap.classList ) {
				wrap.classList.add( 'has-flipped-down' );
			}
			rect = popup.getBoundingClientRect();
		}

		if ( rect.left < 8 ) {
			var shiftLeft = 8 - rect.left;
			popup.style.left = 'calc(50% + ' + Math.round( shiftLeft ) + 'px)';
			popup.style.setProperty( '--bazna-arrow-left', 'calc(50% - ' + Math.round( shiftLeft ) + 'px)' );
		} else if ( rect.right > viewportWidth - 8 ) {
			var shiftRight = rect.right - ( viewportWidth - 8 );
			popup.style.left = 'calc(50% - ' + Math.round( shiftRight ) + 'px)';
			popup.style.setProperty( '--bazna-arrow-left', 'calc(50% + ' + Math.round( shiftRight ) + 'px)' );
		}
	}

	function closeAllTooltips() {
		var activePopups = document.querySelectorAll( '.bazna-cijena__tooltip-popup.is-active' );
		for ( var k = 0; k < activePopups.length; k++ ) {
			activePopups[ k ].classList.remove( 'is-active' );
			activePopups[ k ].classList.remove( 'bazna-cijena__tooltip-popup--flipped-down' );
			activePopups[ k ].style.left = '';
			activePopups[ k ].style.removeProperty( '--bazna-arrow-left' );
			activePopups[ k ].setAttribute( 'aria-hidden', 'true' );
		}
		var activeWraps = document.querySelectorAll( '.bazna-cijena__tooltip-wrap.has-flipped-down' );
		for ( var m = 0; m < activeWraps.length; m++ ) {
			activeWraps[ m ].classList.remove( 'has-flipped-down' );
		}
		var activeTriggers = document.querySelectorAll( '[data-bazna-cijena-tooltip-trigger][aria-expanded="true"]' );
		for ( var l = 0; l < activeTriggers.length; l++ ) {
			activeTriggers[ l ].setAttribute( 'aria-expanded', 'false' );
		}
		// CSS also shows the popup on :hover and :focus-within. A wrap closed while
		// still hovered or focused stays hidden until the pointer or focus leaves.
		var wraps = document.querySelectorAll( '.bazna-cijena__tooltip-wrap' );
		for ( var n = 0; n < wraps.length; n++ ) {
			if ( wraps[ n ].matches && wraps[ n ].matches( ':hover, :focus-within' ) ) {
				wraps[ n ].classList.add( 'is-dismissed' );
			}
		}
	}

	function clearDismissed( event ) {
		var wrap = event.target && event.target.closest ? event.target.closest( '.bazna-cijena__tooltip-wrap' ) : null;
		if ( wrap && ! wrap.contains( event.relatedTarget ) ) {
			wrap.classList.remove( 'is-dismissed' );
		}
	}

	function toggleTooltip( trigger, event ) {
		if ( event ) {
			event.preventDefault();
			event.stopPropagation();
		}

		var wrap = trigger.closest ? trigger.closest( '.bazna-cijena__tooltip-wrap' ) : trigger.parentNode;
		if ( ! wrap ) {
			return;
		}

		var popup = wrap.querySelector( '[data-bazna-cijena-tooltip-popup]' );
		if ( ! popup ) {
			return;
		}

		var isOpen = popup.classList.contains( 'is-active' );
		closeAllTooltips();

		if ( ! isOpen ) {
			wrap.classList.remove( 'is-dismissed' );
			popup.classList.add( 'is-active' );
			popup.setAttribute( 'aria-hidden', 'false' );
			trigger.setAttribute( 'aria-expanded', 'true' );
			repositionTooltip( popup );
		}
	}

	function bindTooltipEvents() {
		var emptyTexts = document.querySelectorAll( '.bazna-cijena__tooltip-text[data-tooltip-text]' );
		for ( var et = 0; et < emptyTexts.length; et++ ) {
			if ( ! emptyTexts[ et ].textContent ) {
				emptyTexts[ et ].textContent = emptyTexts[ et ].getAttribute( 'data-tooltip-text' ) || '';
			}
		}

		document.addEventListener( 'mouseenter', function ( event ) {
			var trigger = event.target && event.target.closest
				? event.target.closest( '[data-bazna-cijena-tooltip-trigger]' )
				: null;
			if ( trigger ) {
				var wrap = trigger.closest ? trigger.closest( '.bazna-cijena__tooltip-wrap' ) : trigger.parentNode;
				var popup = wrap ? wrap.querySelector( '[data-bazna-cijena-tooltip-popup]' ) : null;
				if ( popup ) {
					repositionTooltip( popup );
				}
			}
		}, true );

		document.addEventListener( 'focusin', function ( event ) {
			var trigger = event.target && event.target.closest
				? event.target.closest( '[data-bazna-cijena-tooltip-trigger]' )
				: null;
			if ( trigger ) {
				var wrap = trigger.closest ? trigger.closest( '.bazna-cijena__tooltip-wrap' ) : trigger.parentNode;
				var popup = wrap ? wrap.querySelector( '[data-bazna-cijena-tooltip-popup]' ) : null;
				if ( popup ) {
					repositionTooltip( popup );
				}
			}
		} );

		document.addEventListener( 'mouseout', clearDismissed );
		document.addEventListener( 'focusout', clearDismissed );

		window.addEventListener( 'resize', function () {
			var popups = document.querySelectorAll( '.bazna-cijena__tooltip-popup' );
			for ( var i = 0; i < popups.length; i++ ) {
				if ( window.getComputedStyle( popups[ i ] ).display !== 'none' ) {
					repositionTooltip( popups[ i ] );
				}
			}
		} );

		document.addEventListener( 'click', function ( event ) {
			var trigger = event.target && event.target.closest
				? event.target.closest( '[data-bazna-cijena-tooltip-trigger]' )
				: null;

			if ( trigger ) {
				toggleTooltip( trigger, event );
			} else if ( ! ( event.target && event.target.closest && event.target.closest( '.bazna-cijena__tooltip-popup' ) ) ) {
				closeAllTooltips();
			}
		} );

		document.addEventListener( 'keydown', function ( event ) {
			if ( 'Escape' === event.key || 'Esc' === event.key ) {
				closeAllTooltips();
			} else if ( ( 'Enter' === event.key || ' ' === event.key ) && event.target && event.target.hasAttribute && event.target.hasAttribute( 'data-bazna-cijena-tooltip-trigger' ) ) {
				toggleTooltip( event.target, event );
			}
		} );
	}

	function syncCustomPriceWrappers() {
		var customPriceWrappers = document.querySelectorAll( '.growshophr-selected-price, .selected-variation-price' );
		for ( var cp = 0; cp < customPriceWrappers.length; cp++ ) {
			var wrap = customPriceWrappers[ cp ];
			if ( wrap.querySelector( '.bazna-cijena' ) ) {
				continue;
			}
			var form = wrap.closest ? ( wrap.closest( 'form.variations_form' ) || ( wrap.closest( '.product' ) && wrap.closest( '.product' ).querySelector( 'form.variations_form' ) ) ) : null;
			if ( ! form && document ) {
				form = document.querySelector( 'form.variations_form' );
			}
			if ( form && window.jQuery ) {
				var $form = window.jQuery( form );
				var variations = $form.data( 'product_variations' );
				var currentId = $form.find( 'input[name="variation_id"]' ).val();
				if ( variations && currentId ) {
					for ( var v = 0; v < variations.length; v++ ) {
						if ( String( variations[ v ].variation_id ) === String( currentId ) ) {
							if ( variations[ v ].price_html && variations[ v ].price_html.indexOf( 'bazna-cijena' ) !== -1 ) {
								var tempDiv = document.createElement( 'div' );
								tempDiv.innerHTML = variations[ v ].price_html;
								var baznaNode = tempDiv.querySelector( '.bazna-cijena' );
								if ( baznaNode ) {
									wrap.appendChild( baznaNode );
								}
							}
							break;
						}
					}
				}
			}
		}
	}

	function setupCustomPriceObserver() {
		syncCustomPriceWrappers();
		if ( ! window.MutationObserver ) {
			return;
		}

		var target = document.body || document.documentElement;
		if ( target ) {
			var observer = new MutationObserver( function () {
				syncCustomPriceWrappers();
			} );
			observer.observe( target, { childList: true, subtree: true } );
		}
	}

	function bind() {
		bindTooltipEvents();
		setupCustomPriceObserver();

		if ( window.jQuery ) {
			window.jQuery( document ).on( 'found_variation', function ( event, variation ) {
				var form = event.target && event.target.closest ? event.target.closest( 'form.variations_form' ) : event.target;
				var productId = form && form.getAttribute ? ( form.getAttribute( 'data-product_id' ) || form.getAttribute( 'data-product-id' ) ) : '';
				var root = ( event.target.closest && event.target.closest( '.product' ) ) || event.target;
				update( variation, root, productId );
			} );

			window.jQuery( document ).on( 'reset_data', function ( event ) {
				var form = event.target && event.target.closest ? event.target.closest( 'form.variations_form' ) : event.target;
				var productId = form && form.getAttribute ? ( form.getAttribute( 'data-product_id' ) || form.getAttribute( 'data-product-id' ) ) : '';
				var root = ( event.target.closest && event.target.closest( '.product' ) ) || event.target;
				update( null, root, productId );
			} );
		}
	}

	if ( document.readyState === 'loading' ) {
		document.addEventListener( 'DOMContentLoaded', bind );
	} else {
		bind();
	}
} )();
