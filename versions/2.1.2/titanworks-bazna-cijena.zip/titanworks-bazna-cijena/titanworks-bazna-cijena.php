<?php
/**
 * Plugin Name:       Titanworks Bazna Cijena
 * Plugin URI:        https://sidrenacijena.eu/
 * Description:       Records, displays, validates and publishes the Croatian anchor price ("sidrena cijena"), base price, daily machine-readable price list and the 30-day lowest price for special forms of sale. A technical compliance aid, not legal advice.
 * Version:           2.1.2
 * Requires at least: 6.8
 * Requires PHP:      7.4
 * Author:            titanworks
 * License:           GPL-2.0-or-later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       titanworks-bazna-cijena
 * Domain Path:       /languages
 *
 * @package TitanworksBaznaCijena
 */

defined( 'ABSPATH' ) || exit;

defined( 'TWBCE_CIJENA_VERSION' ) || define( 'TWBCE_CIJENA_VERSION', '2.1.2' );
defined( 'TWBCE_CIJENA_FILE' ) || define( 'TWBCE_CIJENA_FILE', __FILE__ );
defined( 'TWBCE_CIJENA_DIR' ) || define( 'TWBCE_CIJENA_DIR', plugin_dir_path( __FILE__ ) );
defined( 'TWBCE_CIJENA_URL' ) || define( 'TWBCE_CIJENA_URL', plugin_dir_url( __FILE__ ) );
defined( 'TWBCE_CIJENA_BASENAME' ) || define( 'TWBCE_CIJENA_BASENAME', plugin_basename( __FILE__ ) );

require_once TWBCE_CIJENA_DIR . 'src/Support/Autoloader.php';
require_once TWBCE_CIJENA_DIR . 'src/Api/functions.php';
require_once TWBCE_CIJENA_DIR . 'src/Api/global-functions.php';
\Titanworks\BaznaCijena\Support\Autoloader::register();

register_activation_hook( __FILE__, array( 'Titanworks\BaznaCijena\Support\Install', 'activate' ) );
register_deactivation_hook( __FILE__, array( 'Titanworks\BaznaCijena\Support\Deactivator', 'deactivate' ) );

/**
 * Load the plugin translations.
 *
 * Loads the bundled Croatian translation catalogue for Croatian locales,
 * and falls back to standard WordPress textdomain resolution for other
 * locales. Supports filtering to allow forcing or skipping Croatian catalog.
 *
 * @return void
 */
function titanworks_bazna_cijena_load_textdomain() {
	if ( function_exists( 'is_textdomain_loaded' ) && is_textdomain_loaded( 'titanworks-bazna-cijena' ) ) {
		return;
	}

	$locale = function_exists( 'determine_locale' ) ? determine_locale() : ( function_exists( 'get_locale' ) ? get_locale() : 'hr_HR' );

	/**
	 * Filters whether to load the bundled Croatian translation catalog.
	 *
	 * Defaults to true for Croatian locales (hr, hr_HR, hr_BA), false otherwise.
	 *
	 * @param bool   $load   Whether to load the Croatian catalog.
	 * @param string $locale Active locale.
	 */
	$load_croatian = apply_filters( 'twbce_cijena_load_croatian_catalog', 0 === strpos( (string) $locale, 'hr' ), $locale );

	$candidates = array(
		TWBCE_CIJENA_DIR . 'languages/titanworks-bazna-cijena-hr.mo',
		TWBCE_CIJENA_DIR . 'languages/titanworks-bazna-cijena-hr_HR.mo',
	);

	if ( $load_croatian || 0 === strpos( (string) $locale, 'hr' ) ) {
		foreach ( $candidates as $bundled_mo ) {
			if ( file_exists( $bundled_mo ) ) {
				load_textdomain( 'titanworks-bazna-cijena', $bundled_mo );
				break;
			}
		}
	}
}
add_action( 'init', 'titanworks_bazna_cijena_load_textdomain', 1 );

/**
 * Declare WooCommerce compatibility before WooCommerce loads its features.
 *
 * The plugin keeps its own tables and never reads or writes orders, so High
 * Performance Order Storage changes nothing for it. Declaring it explicitly
 * keeps WooCommerce from flagging the plugin as untested/incompatible.
 *
 * @return void
 */
function titanworks_bazna_cijena_declare_woocommerce_compatibility() {
	if ( ! class_exists( '\Automattic\WooCommerce\Utilities\FeaturesUtil' ) ) {
		return;
	}

	\Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility( 'custom_order_tables', TWBCE_CIJENA_FILE, true );
}

add_action( 'before_woocommerce_init', 'titanworks_bazna_cijena_declare_woocommerce_compatibility' );

add_action( 'plugins_loaded', array( 'Titanworks\BaznaCijena\Plugin', 'boot' ), 20 );
