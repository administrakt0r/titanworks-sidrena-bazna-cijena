=== Titanworks Bazna Cijena ===
Contributors: titanworks
Tags: croatia, price, compliance, woocommerce, price list
Requires at least: 6.8
Tested up to: 7.1
Requires PHP: 7.4
Stable tag: 2.1.2
License: GPL-2.0-or-later
License URI: https://www.gnu.org/licenses/gpl-2.0.html
Donate link: https://sidrenacijena.eu/

Croatian anchor prices, 30-day sale-price history and daily CSV/XML price lists for WooCommerce or a standalone catalog.

== Description ==

This plugin is a technical compliance aid for Croatian merchants who must
display the base price ("bazna cijena", NN 132/2026-1583) next to the current
retail price, publish a machine-readable price list (NN 132/2026-1584), and show
the lowest price of the previous 30 days during special forms of sale.

**It is not legal advice.** Merchants remain responsible for their own legal
compliance and should obtain professional legal or accounting advice.

Main features:

* Immutable anchor price records with reference dates, sources and a full audit trail.
* Frontend display of the current price and the anchor price, clearly labelled ("Bazna cijena").
* Separate 30-day lowest-price engine for special forms of sale (akcija, sniženje, sezonsko sniženje, rasprodaja).
* CSV and XML goods and services price lists in the NN 132/2026-1584 column order and filename format, republished after every price change before 11:00, with replaced lists archived for 15 days.
* Public, unauthenticated machine-readable price endpoint (`/wp-json/bazna-cijena/v1/prices`).
* Compliance dashboard, validator with severity levels, CSV import with preview and rollback, price-history audit screen, structured logs and WP-CLI commands.
* WooCommerce is optional: the compliance workflow also works with the built-in standalone catalog.

== Installation ==

1. Install **Titanworks Bazna Cijena** from **Plugins → Add New Plugin**, or upload the plugin ZIP.
2. Activate the plugin through the *Plugins* screen.
3. Open *Sidrena cijena → Postavke* and review the reference dates and display settings.
4. Record or import anchor prices for your catalog.
5. Generate the price lists and confirm the public endpoints.

== Frequently Asked Questions ==

= Is this legal advice? =

No. It is a technical aid that implements documented obligations; consult a
legal or accounting professional for your specific situation.

= Does it require WooCommerce? =

No. WooCommerce integration is enabled automatically when WooCommerce is
active; otherwise the standalone catalog is used.

= Which reference dates are used? =

The general reference date is 10 September 2026. Legacy categories (food,
beverages, cosmetics, cleaning products, toiletries, household products) use
2 May 2025. Both are configurable under *Sidrena cijena → Postavke → Pravna
pravila*, and every change is recorded in the audit trail. Map your actual legacy
category slugs there before publishing; the plugin does not guess categories.

= Are the Croatian rules final? =

Yes. Since 17 November 2026 the plugin implements the pravilnici NN 132/2026-1583 (base price) and NN 132/2026-1584 (price lists), which replace the September Government decisions. Version 2.1.0 migrates the label, deadline, retention, columns and filenames. Set the merchant OIB under Settings before generating.

= Does the plugin invent historical prices? =

Never. Newly created offers witnessed at publication can receive their actual
first-offer price and observed date automatically. Existing catalog gaps and
imports require evidenced historical prices. Merchants must verify the price,
date, product identity and applicable sale classification before publishing.

== External services ==

The plugin sends no catalog data or telemetry to an external service. Price
history, validation and file generation run on your WordPress installation.
WordPress itself may contact WordPress.org for standard plugin updates.

== Privacy ==

The plugin stores catalog prices, historical evidence, shop addresses, publication
records and operational logs in your WordPress database and uploads directory.
Audit records include the acting WordPress user's ID and reasons supplied for
corrections. Do not put customer details or unnecessary personal data in these
fields. This plugin does not add tracking cookies or collect customer orders.

Published catalog fields, sales-location addresses and generated price lists are
public by design, including the REST feed and retained archive. Restrict catalog
content to information intended for publication. Deactivation and ordinary
uninstall retain data. Optional uninstall cleanup removes operational data and
files but preserves anchor and 30-day evidence, including their audit attribution.
Review retained records with your data-protection and legal advisers.

== Screenshots ==

1. Public price-list page with search, item types and downloads.
2. Administrative compliance dashboard with anchor price coverage, validator findings and publication status.
3. Price history and immutable audit log of statutory reference dates.
4. Plugin settings and legal rules configuration.

== Changelog ==

= 2.1.2 =
* Fix: product cards no longer show the base price twice when Display position is "Separate block below the price" and the theme fires several card hooks. The block now renders once per card, below the price.

= 2.1.1 =
* Fix: the public price-list archive page no longer runs out of memory on large catalogs. Listing publications now reads only the error and warning counts instead of every stored compliance finding.

= 2.1.0 =
* Compliance: price lists follow NN 132/2026-1584. They use the new goods column order (adds neto_kolicina and ean_barkod; drops vrsta, datum_sidrene_cijene and dostupnost), and services go in a separate list.
* Compliance: filenames start with the merchant OIB and include ROBA/USLUGE, YYYYMMDD, and ZA_SVA_PRODAJNA_MJESTA when one list covers all locations. A missing OIB blocks generation.
* Compliance: the 11:00 deadline applies, any price change republishes within minutes, and replaced lists stay public for 15 days after replacement.
* Compliance: the label defaults to "Bazna cijena" and legacy labels and tooltip are migrated. Variable products show the base-price range before a variation is chosen. Sale prices are never captured as the base price.
* Fix: SKUs are no longer copied into the barcode column, and WooCommerce's GTIN field is read. Missing prices export as empty instead of 0,00.
* Fix: the public feeds disable LiteSpeed/CDN page caching and are purged after each publication.
* Fix: the base-price range on variable products no longer disappears on page load or after a variation is cleared.
* Fix: settings migrate on cron and WP-CLI too, so the first scheduled run after updating already uses the new rules. XML records always carry every field in the statutory order.
* Import: the plugin's own NN 132/2026 goods list can be re-imported. A file without a reference-date column keeps each item's existing base-price date; new items need a date. Standalone and WooCommerce products get a net quantity field.
* Fix: an identical list republishes after it was superseded or when the OIB or list scope changes, and other locations' lists are retired only after the shared list publishes.

= 2.0.51 =
* Layout & Flexbox: added flex-wrap protection and flex-shrink safeguards (.woocommerce-Price-amount, ins, del) for flex price containers in themes, preventing 100% width reference lines from compressing the main product price into a narrow column on single product pages.

= 2.0.50 =
* Theme Compatibility: templates now use semantic HTML5 root <span> elements with display: block instead of <div>, preventing browser DOM splitting inside <p class="price"> and <span class="price"> wrappers.
* Variations: added MutationObserver and variation handler in frontend.js for themes with custom selected price summaries (e.g. .growshophr-selected-price), dynamically syncing anchor prices and 30-day lowest prices on card/pill selection.
* Tooltips: stored legal tooltip text in data-tooltip-text to prevent server-side tag stripping (e.g. search indexes, RSS feeds, recently viewed widgets) from concatenating legal explanation paragraphs into plain-text prices, with seamless CSS/JS hydration.
* Layout: standardized full-width flexbox wrapping (.price > .bazna-cijena) in modern catalog product grids to prevent staggered card heights and button misalignment.
* Tooltip Clipping: un-clipped tooltip popups on hover and active states (.product-card:has(...)) to prevent overflow: hidden card bounds from cropping tooltips.
* Mobile & Checkout: hidden compliance badges on 48px mobile sticky purchase bars to protect touch targets; added responsive wrapping for reference pricing in classic checkout order review tables.
* Extensibility: added filterable archive hooks (twbce_cijena_archive_hooks) supporting custom theme loop hooks such as growshophr_product_card_content.

= 2.0.49 =
* Accessibility: the public price table can now receive keyboard focus and scroll with the arrow keys, with a visible focus outline.
* Performance: public price-list pages format only the visible rows after pagination, reducing work on large catalogs without changing the output.
* Admin: an empty Audit operational log now distinguishes no entries from no results for a selected filter.
* Cleanup: removed unused cart unit-label CSS. No change to legal price calculations or stored history.

Older releases (2.0.48 and earlier) are listed in CHANGELOG.md and on the [GitHub releases page](https://github.com/administrakt0r/titanworks-sidrena-bazna-cijena/releases).
