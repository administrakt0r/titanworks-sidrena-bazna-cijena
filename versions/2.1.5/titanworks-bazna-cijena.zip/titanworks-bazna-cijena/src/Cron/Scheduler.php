<?php
/**
 * Scheduling abstraction.
 *
 * WP-Cron is used for the daily run and cleanup; Action Scheduler (bundled
 * with WooCommerce) is preferred for queued service regeneration when
 * available. Production documentation recommends a real system cron entry.
 *
 * @package Titanworks\BaznaCijena\Cron
 */

namespace Titanworks\BaznaCijena\Cron;

use Titanworks\BaznaCijena\Admin\Capabilities;
use Titanworks\BaznaCijena\Admin\AdminMenu;
use Titanworks\BaznaCijena\Admin\PublicationsPage;
use Titanworks\BaznaCijena\Compliance\RuleConfig;
use Titanworks\BaznaCijena\Export\FilenameGenerator;
use Titanworks\BaznaCijena\Export\GenerationService;
use Titanworks\BaznaCijena\Plugin;
use Titanworks\BaznaCijena\Support\Dates;
use Titanworks\BaznaCijena\Support\Settings;

defined( 'ABSPATH' ) || exit;

/**
 * Registers and manages plugin cron events.
 */
final class Scheduler {

	/**
	 * Daily generation hook.
	 */
	const HOOK_DAILY = 'twbce_cijena_daily_generation';

	/**
	 * Queued service regeneration hook.
	 */
	const HOOK_SERVICE = 'twbce_cijena_service_regeneration';

	/**
	 * Throttle for the outdated-list check (transient name).
	 */
	const OUTDATED_LOCK = 'twbce_cijena_outdated_check';

	/**
	 * Settings that change the published file name or content.
	 */
	const REPUBLISH_SETTINGS = array( 'merchant_oib', 'merchant_id_type', 'price_list_scope', 'formats' );

	/**
	 * Daily cleanup hook.
	 */
	const HOOK_CLEANUP = 'twbce_cijena_daily_cleanup';

	/**
	 * Queued catch-up generation hook.
	 */
	const HOOK_CATCHUP = 'twbce_cijena_catchup_generation';

	/**
	 * Action Scheduler group.
	 */
	const AS_GROUP = 'bazna-cijena';

	/**
	 * Action Scheduler group used before 2.0.44.
	 */
	const LEGACY_AS_GROUP = 'sidrena-cijena';

	/**
	 * Dismiss failure action.
	 */
	const DISMISS_FAILURE_ACTION = 'twbce_cijena_dismiss_generation_failure';

	/**
	 * Catch-up transient lock.
	 */
	const CATCHUP_LOCK = 'twbce_cijena_catchup_lock';

	/**
	 * Register cron callbacks.
	 *
	 * @return void
	 */
	public static function register() {
		add_action( self::HOOK_DAILY, array( DailyGeneration::class, 'run_scheduled' ) );
		add_action( self::HOOK_SERVICE, array( DailyGeneration::class, 'run_service_regeneration' ) );
		add_action( self::HOOK_CATCHUP, array( __CLASS__, 'handle_catchup_event' ) );
		add_action( self::HOOK_CLEANUP, array( CleanupJob::class, 'run' ) );
		add_action( 'admin_notices', array( __CLASS__, 'maybe_notice' ) );
		add_action( 'admin_notices', array( __CLASS__, 'merchant_id_notice' ) );
		add_action( 'admin_post_' . self::DISMISS_FAILURE_ACTION, array( __CLASS__, 'handle_dismiss_failure' ) );
		add_action( 'init', array( __CLASS__, 'maybe_catchup' ) );
		add_action( 'init', array( __CLASS__, 'maybe_refresh_outdated' ), 20 );
		add_action( 'update_option_' . Settings::OPTION, array( __CLASS__, 'settings_changed' ), 20, 2 );
		add_action( 'update_option_timezone_string', array( __CLASS__, 'reschedule_daily' ) );
		add_action( 'update_option_gmt_offset', array( __CLASS__, 'reschedule_daily' ) );
	}

	/**
	 * Schedule all recurring events.
	 *
	 * @return void
	 */
	public static function schedule_all() {
		self::schedule_daily();
		self::schedule_cleanup();
	}

	/**
	 * Schedule daily generation with a 15-minute buffer before the configured deadline.
	 *
	 * @param bool $allow_prompt Whether a run may be queued within the buffer window.
	 * @return void
	 */
	public static function schedule_daily( $allow_prompt = true ) {
		if ( wp_next_scheduled( self::HOOK_DAILY ) ) {
			return;
		}

		$deadline = (string) Settings::get( 'deadline', Settings::LEGAL_DEADLINE );
		$parsed   = \DateTimeImmutable::createFromFormat( '!H:i', $deadline, Dates::timezone() );
		$run_time = $parsed ? $parsed->modify( '-15 minutes' )->format( 'H:i' ) : '07:45';
		$now      = Dates::now_site();
		$run_at   = $now->setTime( (int) substr( $run_time, 0, 2 ), (int) substr( $run_time, 3, 2 ) );
		$due_by   = $now->setTime( (int) substr( $deadline, 0, 2 ), (int) substr( $deadline, 3, 2 ) );

		// If activated/re-scheduled after the buffer but before the deadline, run promptly rather than missing today's list.
		$timestamp = $allow_prompt && $now >= $run_at && $now < $due_by
			? time() + 30
			: Dates::next_occurrence( $run_time, false );

		wp_schedule_event( $timestamp, 'daily', self::HOOK_DAILY );
	}

	/**
	 * Schedule the daily cleanup event.
	 *
	 * @return void
	 */
	public static function schedule_cleanup() {
		if ( wp_next_scheduled( self::HOOK_CLEANUP ) ) {
			return;
		}

		wp_schedule_event( Dates::next_occurrence( '03:30', false ), 'daily', self::HOOK_CLEANUP );
	}

	/**
	 * Unschedule every plugin event.
	 *
	 * @return void
	 */
	public static function unschedule_all() {
		wp_clear_scheduled_hook( self::HOOK_DAILY );
		wp_clear_scheduled_hook( self::HOOK_SERVICE );
		wp_clear_scheduled_hook( self::HOOK_CATCHUP );
		wp_clear_scheduled_hook( self::HOOK_CLEANUP );

		if ( function_exists( 'as_unschedule_all_actions' ) ) {
			foreach ( array( self::AS_GROUP, self::LEGACY_AS_GROUP ) as $group ) {
				as_unschedule_all_actions( self::HOOK_SERVICE, array(), $group );
				as_unschedule_all_actions( self::HOOK_CATCHUP, array(), $group );
			}
		}
	}

	/**
	 * Queue catch-up generation in Action Scheduler or WP-Cron.
	 *
	 * @return void
	 */
	public static function queue_catchup() {
		if ( function_exists( 'as_schedule_single_action' ) && apply_filters( 'twbce_cijena_use_action_scheduler', true ) ) {
			as_schedule_single_action( time(), self::HOOK_CATCHUP, array(), self::AS_GROUP );

			return;
		}

		wp_schedule_single_event( time(), self::HOOK_CATCHUP );

		if ( function_exists( 'spawn_cron' ) ) {
			spawn_cron();
		}
	}

	/**
	 * Handle queued catch-up cron event.
	 *
	 * @return void
	 */
	public static function handle_catchup_event() {
		DailyGeneration::run_catchup();
	}

	/**
	 * Delay before a goods price change rebuilds the price lists.
	 */
	const CHANGE_DEBOUNCE = 300;

	/**
	 * Queue one rebuild after goods price changes, unless one is already pending.
	 *
	 * @return void
	 */
	public static function queue_change_regeneration() {
		$delay    = (int) apply_filters( 'twbce_cijena_change_regeneration_delay', self::CHANGE_DEBOUNCE );
		$now      = Dates::now_site();
		$deadline = (string) Settings::get( 'deadline', Settings::LEGAL_DEADLINE );
		$due_by   = $now->setTime( (int) substr( $deadline, 0, 2 ), (int) substr( $deadline, 3, 2 ) );

		// Queue immediately when batching edits would delay today's publication past its deadline.
		if ( $now->getTimestamp() + $delay >= $due_by->getTimestamp() ) {
			$delay = 0;
		}

		if ( function_exists( 'as_next_scheduled_action' ) && apply_filters( 'twbce_cijena_use_action_scheduler', true ) ) {
			// Only a pending run covers this change. A run that is already in
			// progress may have read the catalog before the change was saved,
			// so a follow-up run is still needed (as_next_scheduled_action()
			// also returns true for in-progress actions).
			if ( self::has_pending_action( self::HOOK_SERVICE ) ) {
				return;
			}
		} elseif ( false !== wp_next_scheduled( self::HOOK_SERVICE ) ) {
			return;
		}

		self::queue_service_regeneration( array(), $delay );
	}

	/**
	 * Whether an Action Scheduler action is pending (not running) for a hook.
	 *
	 * @param string $hook Hook name.
	 * @return bool
	 */
	protected static function has_pending_action( $hook ) {
		if ( function_exists( 'as_get_scheduled_actions' ) ) {
			$ids = as_get_scheduled_actions(
				array(
					'hook'     => $hook,
					'args'     => array(),
					'group'    => self::AS_GROUP,
					'status'   => 'pending',
					'per_page' => 1,
				),
				'ids'
			);

			return ! empty( $ids );
		}

		$next = as_next_scheduled_action( $hook, array(), self::AS_GROUP );

		// `true` means in progress, which does not cover a later change.
		return is_int( $next );
	}

	/**
	 * Queue a service regeneration run.
	 *
	 * @param array<mixed> $args  Arguments passed to the handler.
	 * @param int          $delay Seconds to wait before running.
	 * @return void
	 */
	public static function queue_service_regeneration( array $args = array(), $delay = 0 ) {
		// Cron handlers receive scheduled arguments as positional callback
		// arguments, so the request array has to be wrapped to stay one argument.
		$event_args = empty( $args ) ? array() : array( $args );

		if ( function_exists( 'as_schedule_single_action' ) && apply_filters( 'twbce_cijena_use_action_scheduler', true ) ) {
			as_schedule_single_action( time() + max( 0, (int) $delay ), self::HOOK_SERVICE, $event_args, self::AS_GROUP );

			return;
		}

		wp_schedule_single_event( time() + max( 0, (int) $delay ), self::HOOK_SERVICE, $event_args );
	}

	/**
	 * Timestamp of the next daily run.
	 *
	 * @return int|false
	 */
	public static function next_run() {
		return wp_next_scheduled( self::HOOK_DAILY );
	}

	/**
	 * Whether the daily event is scheduled and not overdue.
	 *
	 * WP-Cron runs on the next request, so an event whose timestamp has just
	 * passed is normal; only an event that stayed due beyond the grace period
	 * means generation is actually falling behind.
	 *
	 * @return bool
	 */
	public static function is_healthy() {
		$next = wp_next_scheduled( self::HOOK_DAILY );

		return false !== $next && (int) $next >= time() - HOUR_IN_SECONDS;
	}

	/**
	 * Warn administrators on every admin screen when the merchant OIB is missing.
	 *
	 * @return void
	 */
	public static function merchant_id_notice() {
		if ( ! is_admin() || ! Capabilities::current_user_can() ) {
			return;
		}

		if ( '' !== FilenameGenerator::merchant_id() ) {
			return;
		}

		// Shown on every admin screen: without the OIB no price list can be
		// published (NN 132/2026-1584 čl. 6.), and the last published list
		// stops being updated.
		printf(
			'<div class="notice notice-error"><p><strong>%1$s</strong> %2$s <a href="%3$s">%4$s</a></p></div>',
			esc_html__( 'Bazna cijena: price lists are not being published.', 'titanworks-bazna-cijena' ),
			esc_html__( 'NN 132/2026-1584 requires the merchant OIB (or registration number) in every price-list filename. Until it is entered, no new price list is generated and the public list is no longer updated.', 'titanworks-bazna-cijena' ),
			esc_url( AdminMenu::url( 'bazna-cijena-settings', array( 'tab' => 'operations' ) ) ),
			esc_html__( 'Enter the OIB', 'titanworks-bazna-cijena' )
		);
	}

	/**
	 * Warn administrators when daily generation failed, is missed, or is overdue.
	 *
	 * @return void
	 */
	public static function maybe_notice() {
		if ( ! is_admin() || ! Capabilities::current_user_can() ) {
			return;
		}

		if ( ! AdminMenu::is_plugin_screen() ) {
			return;
		}

		$failure   = get_option( DailyGeneration::FAILURE_OPTION, null );
		$dismissed = (bool) get_option( DailyGeneration::DISMISS_OPTION, false );

		if ( $failure && ! $dismissed && is_array( $failure ) ) {
			$dismiss_url  = wp_nonce_url(
				add_query_arg( array( 'action' => self::DISMISS_FAILURE_ACTION ), admin_url( 'admin-post.php' ) ),
				self::DISMISS_FAILURE_ACTION
			);
			$pub_url      = admin_url( 'admin.php?page=' . PublicationsPage::SLUG );
			$failed_count = isset( $failure['summary']['failed'] ) ? (int) $failure['summary']['failed'] : 1;
			$details      = ! empty( $failure['errors'] ) ? implode( '; ', (array) $failure['errors'] ) : '';
			$message      = sprintf(
				/* translators: %d: count of failed price lists */
				_n( '%d price list failed to publish.', '%d price lists failed to publish.', $failed_count, 'titanworks-bazna-cijena' ),
				$failed_count
			);

			printf(
				'<div class="notice notice-error"><p><strong>%1$s</strong> %2$s %3$s <a href="%4$s">%5$s</a> | <a href="%6$s">%7$s</a></p></div>',
				esc_html__( 'Sidrena cijena: daily price-list generation failed.', 'titanworks-bazna-cijena' ),
				esc_html( $message ),
				$details ? esc_html( '(' . $details . ')' ) : '',
				esc_url( $pub_url ),
				esc_html__( 'Open the price lists screen', 'titanworks-bazna-cijena' ),
				esc_url( $dismiss_url ),
				esc_html__( 'Dismiss', 'titanworks-bazna-cijena' )
			);

			return;
		}

		if ( self::is_missed_run_today() ) {
			$deadline = (string) Settings::get( 'deadline', Settings::LEGAL_DEADLINE );
			$url      = admin_url( 'admin.php?page=' . PublicationsPage::SLUG );

			printf(
				'<div class="notice notice-warning"><p>%s <a href="%s">%s</a></p></div>',
				sprintf(
					/* translators: %s: deadline time */
					esc_html__( 'Sidrena cijena: today\'s %s deadline passed without a successful price-list publication. Catch-up generation is pending.', 'titanworks-bazna-cijena' ),
					esc_html( $deadline )
				),
				esc_url( $url ),
				esc_html__( 'Open the price lists screen', 'titanworks-bazna-cijena' )
			);

			return;
		}

		$next = self::next_run();

		if ( $next && (int) $next >= time() ) {
			return;
		}

		$url = admin_url( 'admin.php?page=' . PublicationsPage::SLUG );

		printf(
			'<div class="notice notice-warning"><p>%s <a href="%s">%s</a></p></div>',
			esc_html__( 'Sidrena cijena: daily price-list generation is not scheduled or is overdue. Publications may become stale.', 'titanworks-bazna-cijena' ),
			esc_url( $url ),
			esc_html__( 'Open the price lists screen', 'titanworks-bazna-cijena' )
		);
	}

	/**
	 * Dismiss the generation failure notice.
	 *
	 * @return void
	 */
	public static function handle_dismiss_failure() {
		if ( ! Capabilities::current_user_can() ) {
			wp_die( esc_html__( 'You do not have permission to perform this action.', 'titanworks-bazna-cijena' ) );
		}

		check_admin_referer( self::DISMISS_FAILURE_ACTION );

		update_option( DailyGeneration::DISMISS_OPTION, 1, false );

		$back = wp_get_referer();

		if ( ! $back ) {
			$back = admin_url( 'admin.php?page=' . PublicationsPage::SLUG );
		}

		wp_safe_redirect( $back );
		exit;
	}

	/**
	 * Check if today's scheduled run was missed.
	 *
	 * A run is missed when today is a working day, current site time is past
	 * the deadline, and any active location is missing today's publication.
	 *
	 * @return bool
	 */
	public static function is_missed_run_today() {
		$today = Dates::today();

		if ( ! Dates::is_working_day( $today ) ) {
			return false;
		}

		$deadline = (string) Settings::get( 'deadline', Settings::LEGAL_DEADLINE );
		$now      = Dates::now_site();
		$due      = Dates::parse_site( $today . ' ' . $deadline );

		if ( ! $due || $now < $due ) {
			return false;
		}

		$missed = self::missed_locations_today();

		return ! empty( $missed );
	}

	/**
	 * Active locations that are missing today's publication.
	 *
	 * @return array<int,array<string,mixed>>
	 */
	public static function missed_locations_today() {
		$locations = GenerationService::publishing_locations( Plugin::instance()->locations()->all( true ) );
		$pubs      = Plugin::instance()->publications();
		$today     = Dates::today();
		$missed    = array();

		foreach ( $locations as $location ) {
			$loc_id = (int) $location['id'];
			if ( ! $pubs->has_published_on_date( $loc_id, $today ) ) {
				$missed[] = $location;
			}
		}

		return $missed;
	}

	/**
	 * Run catch-up generation if a run was missed today.
	 *
	 * Front-end requests skip this check to save per-pageview DB queries.
	 * In admin requests, catch-up is offloaded to the background queue so
	 * visitors/administrators are not blocked by full generation inline.
	 *
	 * @return void
	 */
	public static function maybe_catchup() {
		if ( ( function_exists( 'wp_doing_ajax' ) && wp_doing_ajax() ) || ( defined( 'WP_CLI' ) && WP_CLI ) ) {
			return;
		}

		// Ordinary front-end requests skip catch-up checks to save per-pageview queries.
		if ( ! is_admin() && ! ( function_exists( 'wp_doing_cron' ) && wp_doing_cron() ) ) {
			return;
		}

		// Fail fast if a catch-up run is locked or recently attempted before querying database.
		if ( get_transient( self::CATCHUP_LOCK ) ) {
			return;
		}

		if ( ! self::is_missed_run_today() ) {
			return;
		}

		set_transient( self::CATCHUP_LOCK, 1, 300 );

		if ( function_exists( 'wp_doing_cron' ) && wp_doing_cron() ) {
			DailyGeneration::run_catchup();
		} else {
			self::queue_catchup();
		}
	}

	/**
	 * Republish when the live lists were built under an older rule version.
	 *
	 * After an upgrade (for example to the NN 132/2026 pravilnici) the lists
	 * published by the previous version stay online until something triggers a
	 * run. Prices may not change for days, so the plugin queues a run as soon as
	 * it notices the mismatch instead of waiting for the next daily run.
	 *
	 * @return void
	 */
	public static function maybe_refresh_outdated() {
		if ( ! is_admin() && ! ( function_exists( 'wp_doing_cron' ) && wp_doing_cron() ) ) {
			return;
		}

		if ( ( function_exists( 'wp_doing_ajax' ) && wp_doing_ajax() ) || get_transient( self::OUTDATED_LOCK ) ) {
			return;
		}

		set_transient( self::OUTDATED_LOCK, 1, HOUR_IN_SECONDS );

		if ( '' === FilenameGenerator::merchant_id() ) {
			return;
		}

		$current  = (string) RuleConfig::get( 'rule_version', RuleConfig::DEFAULT_RULE_VERSION );
		$versions = Plugin::instance()->publications()->published_rule_versions();

		if ( empty( $versions ) || array( $current ) === $versions ) {
			return;
		}

		self::queue_change_regeneration();
	}

	/**
	 * Republish when a setting that shapes the file name or content changed.
	 *
	 * @param mixed $old_value Previous settings.
	 * @param mixed $new_value New settings.
	 * @return void
	 */
	public static function settings_changed( $old_value, $new_value ) {
		$old_value = is_array( $old_value ) ? $old_value : array();
		$new_value = is_array( $new_value ) ? $new_value : array();

		foreach ( self::REPUBLISH_SETTINGS as $key ) {
			$before = isset( $old_value[ $key ] ) ? $old_value[ $key ] : null;
			$after  = isset( $new_value[ $key ] ) ? $new_value[ $key ] : null;

			if ( $before !== $after ) {
				if ( '' !== FilenameGenerator::merchant_id() ) {
					self::queue_change_regeneration();
				}

				return;
			}
		}
	}

	/**
	 * Re-schedule the daily event when the deadline setting changed.
	 *
	 * @param bool $allow_prompt Whether a run may be queued within the buffer window.
	 * @return void
	 */
	public static function reschedule_daily( $allow_prompt = true ) {
		wp_clear_scheduled_hook( self::HOOK_DAILY );
		self::schedule_daily( $allow_prompt );
	}
}
