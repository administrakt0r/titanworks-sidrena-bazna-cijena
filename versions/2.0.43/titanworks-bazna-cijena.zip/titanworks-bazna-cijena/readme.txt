=== Titanworks Bazna Cijena ===
Contributors: titanworks
Tags: croatia, price, compliance, woocommerce, price list
Requires at least: 6.8
Tested up to: 7.1
Requires PHP: 7.4
Stable tag: 2.0.43
License: GPL-2.0-or-later
License URI: https://www.gnu.org/licenses/gpl-2.0.html
Donate link: https://sidrenacijena.eu/

Croatian anchor prices, 30-day sale-price history and daily CSV/XML price lists for WooCommerce or a standalone catalog.

== Description ==

This plugin is a technical compliance aid for Croatian merchants who must
display an additional reference price ("sidrena cijena") next to the current
retail price, publish a daily machine-readable price list, and show the lowest
price of the previous 30 days during special forms of sale.

**It is not legal advice.** Merchants remain responsible for their own legal
compliance and should obtain professional legal or accounting advice.

Main features:

* Immutable anchor price records with reference dates, sources and a full audit trail.
* Frontend display of the current price and the anchor price, clearly labelled ("Sidrena cijena").
* Separate 30-day lowest-price engine for special forms of sale (akcija, sniženje, sezonsko sniženje, rasprodaja).
* Daily CSV and XML price-list generation per sales location, with a documented filename profile and at least 30-day retention.
* Public, unauthenticated machine-readable price endpoint (`/wp-json/sidrena-cijena/v1/prices`).
* Compliance dashboard, validator with severity levels, CSV import with preview and rollback, price-history audit screen, structured logs and WP-CLI commands.
* WooCommerce is optional: the compliance workflow also works with the built-in standalone catalog.

== Installation ==

1. Install **Titanworks Bazna Cijena** from **Plugins → Add New Plugin**, or upload the plugin ZIP.
2. Activate the plugin through the *Plugins* screen.
3. Open *Sidrena cijena → Postavke* and review the reference dates and display settings.
4. Record or import anchor prices for your catalog.
5. Generate the price lists and confirm the public endpoints.

== Frequently Asked Questions ==

= Is this legal advice? =

No. It is a technical aid that implements documented obligations; consult a
legal or accounting professional for your specific situation.

= Does it require WooCommerce? =

No. WooCommerce integration is enabled automatically when WooCommerce is
active; otherwise the standalone catalog is used.

= Which reference dates are used? =

The general reference date is 10 September 2026. Legacy categories (food,
beverages, cosmetics, cleaning products, toiletries, household products) use
2 May 2025. Both are configurable under *Sidrena cijena → Postavke → Pravna
pravila*, and every change is recorded in the audit trail. Map your actual legacy
category slugs there before publishing; the plugin does not guess categories.

= Are the Croatian rules final? =

The obligation applies from 17 November 2026 under the Government decisions NN 101/2026 as postponed by NN 110/2026. The Ministry of Economy has drafted pravilnici on the base price and on publishing price lists, which may refine details such as exemptions. The plugin follows the decisions in force and does not implement draft rules. Check Narodne novine and your adviser for the final texts.

= Does the plugin invent historical prices? =

Never. Newly created offers witnessed at publication can receive their actual
first-offer price and observed date automatically. Existing catalog gaps and
imports require evidenced historical prices. Merchants must verify the price,
date, product identity and applicable sale classification before publishing.

== External services ==

The plugin sends no catalog data or telemetry to an external service. Price
history, validation and file generation run on your WordPress installation.
WordPress itself may contact WordPress.org for standard plugin updates.

== Privacy ==

The plugin stores catalog prices, historical evidence, shop addresses, publication
records and operational logs in your WordPress database and uploads directory.
Audit records include the acting WordPress user's ID and reasons supplied for
corrections. Do not put customer details or unnecessary personal data in these
fields. This plugin does not add tracking cookies or collect customer orders.

Published catalog fields, sales-location addresses and generated price lists are
public by design, including the REST feed and retained archive. Restrict catalog
content to information intended for publication. Deactivation and ordinary
uninstall retain data. Optional uninstall cleanup removes operational data and
files but preserves anchor and 30-day evidence, including their audit attribution.
Review retained records with your data-protection and legal advisers.

== Screenshots ==

1. Public price-list page with search, item types and downloads.
2. Administrative compliance dashboard with anchor price coverage, validator findings and publication status.
3. Price history and immutable audit log of statutory reference dates.
4. Plugin settings and legal rules configuration.

== Changelog ==

= 2.0.43 =
* Fix: readme Changelog section trimmed below the WordPress.org 5,000-character limit; older entries are on the GitHub releases page.
* Dev: live local Plugin Check (0 errors, 0 warnings) is now a mandatory gate in verify, release builds and CI.

= 2.0.42 =
* Fix: admin assets, notices and the welcome redirect now load only on this plugin's own screens (exact slug match).
* Fix: Croatian plural forms in admin messages; the catalog now supports three plural forms.
* Change: compliance findings show a translated label instead of the raw code (CSV and JSON exports keep the codes).
* Change: Bulk anchor entry keeps your input and shows per-row errors when rows fail, and returns to a valid page after saving.
* Change: documentation and label-preset help texts are now translatable.

= 2.0.41 =
* New: "Cart and checkout" display setting. The reference lines in the cart, mini-cart and checkout are now off by default and can be enabled in Display settings.
* Change: when enabled, cart and checkout lines use the label configured in settings (including date tokens) instead of a fixed "Bazna cijena".
* Upgrade note: existing installs no longer show cart and checkout reference lines until the setting is enabled.

= 2.0.40 =
* Fix: the sale classification label (e.g. Akcija) now follows the display size setting.
* Fix: the Cart block no longer causes horizontal scrolling on narrow (360px) screens.
* Fix: the Subtle label style now meets the 4.5:1 text contrast ratio.
* Cart and Checkout blocks: reference line updates are batched for smoother refreshes.

= 2.0.39 =
* Legal status update: statutory enforcement date documented as 17 November 2026 (NN 110/2026); added NN 105/2026 and the pending base price and price list pravilnici (draft status as of 13 November 2026).
* New FAQ entry explaining that the Croatian rules are not yet final and how the plugin tracks them.
* Packaging: development files excluded from archives; documentation and agent tooling consolidated with no duplicate guides.
* No changes to storefront rendering, price history or export behaviour.

= 2.0.38 =
* Cart and Checkout Block styling & layout: added clean divider line and structured badge presentation for reference prices on /cart and /checkout.
* React VDOM text node preservation: preserved React-owned text node in WooCommerce Block Cart/Checkout ProductPrice component, collapsing raw text visually while maintaining characterData observer for dynamic recalculations (e.g., tax and shipping changes).
* Accessibility & screen reader optimization: marked structured badge presentation with aria-hidden="true", ensuring assistive technologies read clean semantic text without duplication.
* Dynamic lifecycle cleanup: automated badge removal when Store API refreshes cart items and reference suffixes disappear (e.g., promo expiration).
* Responsive slider typography: replaced fixed pixel sizing with responsive clamp scaling honoring --sidrena-size user settings.
* Quality gates: 804 unit tests (3,119 assertions) passing 100%; Croatian translation catalog 100% complete (931 translated / 0 untranslated strings); PHPCS and PHPStan Level 6 clean (0 errors).

Older releases (2.0.37 and earlier) are listed on the [GitHub releases page](https://github.com/administrakt0r/titanworks-sidrena-bazna-cijena/releases).
