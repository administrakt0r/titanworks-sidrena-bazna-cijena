<?php
/**
 * Administrator documentation and reference guide.
 *
 * @package Titanworks\SidrenaCijena\Admin
 */

namespace Titanworks\SidrenaCijena\Admin;

use Titanworks\SidrenaCijena\Compliance\RuleConfig;
use Titanworks\SidrenaCijena\Plugin;
use Titanworks\SidrenaCijena\Support\Dates;

defined( 'ABSPATH' ) || exit;

/**
 * Renders the in-dashboard Croatian documentation and operational reference.
 */
class DocumentationPage {

	const SLUG = 'sidrena-cijena-docs';

	/**
	 * Render the documentation screen.
	 *
	 * @return void
	 */
	public static function render() {
		if ( ! Capabilities::current_user_can() ) {
			wp_die( esc_html__( 'You do not have permission to access this page.', 'titanworks-bazna-cijena' ) );
		}

		$rule = RuleConfig::all();

		$general_date = isset( $rule['general_reference_date'] ) ? (string) $rule['general_reference_date'] : '2026-09-10';
		$legacy_date  = isset( $rule['legacy_reference_date'] ) ? (string) $rule['legacy_reference_date'] : '2025-05-02';

		echo '<div class="wrap sidrena-docs-wrap">';
		echo '<h1>' . esc_html__( 'Sidrena cijena: Documentation and user guide', 'titanworks-bazna-cijena' ) . '</h1>';
		echo '<p class="description sidrena-docs-description">' . esc_html__( 'A complete handbook for working with the plugin: legal rules, automation, bulk price setting, WP-CLI commands and developer hooks.', 'titanworks-bazna-cijena' ) . '</p>';

		// Quick navigation cards.
		echo '<div class="sidrena-docs-nav">';
		echo '<a href="#zakonski-okvir" class="button">' . esc_html__( '1. Legal framework and rules', 'titanworks-bazna-cijena' ) . '</a>';
		echo '<a href="#skupno-postavljanje" class="button">' . esc_html__( '2. Bulk price setting', 'titanworks-bazna-cijena' ) . '</a>';
		echo '<a href="#prikaz-trgovina" class="button">' . esc_html__( '3. Storefront display', 'titanworks-bazna-cijena' ) . '</a>';
		echo '<a href="#dnevni-cjenik" class="button">' . esc_html__( '4. Daily price list and public feeds', 'titanworks-bazna-cijena' ) . '</a>';
		echo '<a href="#cron-automatizacija" class="button">' . esc_html__( '5. Cron and automation (08:00)', 'titanworks-bazna-cijena' ) . '</a>';
		echo '<a href="#wp-cli" class="button">' . esc_html__( '6. WP-CLI commands', 'titanworks-bazna-cijena' ) . '</a>';
		echo '<a href="#razvojne-kuke" class="button">' . esc_html__( '7. Developer hooks', 'titanworks-bazna-cijena' ) . '</a>';
		echo '</div>';

		// Section 1: Zakonski okvir.
		echo '<div class="card sidrena-docs-card" id="zakonski-okvir">';
		echo '<h2>' . esc_html__( '1. Legal framework and prescribed reference dates', 'titanworks-bazna-cijena' ) . '</h2>';
		echo '<p>' . esc_html__( 'The law requires retailers to display the price that applied on the prescribed reference dates, as well as the lowest price in the last 30 days when running special forms of sale.', 'titanworks-bazna-cijena' ) . '</p>';
		echo '<table class="widefat striped sidrena-docs-table">';
		echo '<caption class="screen-reader-text">' . esc_html__( 'Reference dates by category', 'titanworks-bazna-cijena' ) . '</caption>';
		echo '<thead><tr><th scope="col">' . esc_html__( 'Category / Type', 'titanworks-bazna-cijena' ) . '</th><th scope="col">' . esc_html__( 'Reference date', 'titanworks-bazna-cijena' ) . '</th><th scope="col">' . esc_html__( 'Description and use', 'titanworks-bazna-cijena' ) . '</th></tr></thead>';
		echo '<tbody>';
		echo '<tr><td><strong>' . esc_html__( 'General products and services', 'titanworks-bazna-cijena' ) . '</strong></td><td><code>' . esc_html( Dates::format_date_display( $general_date ) ) . '</code></td><td>' . esc_html__( 'The standard reference date for all categories that do not belong to special or sensitive groups.', 'titanworks-bazna-cijena' ) . '</td></tr>';
		echo '<tr><td><strong>' . esc_html__( 'Special (legacy) categories', 'titanworks-bazna-cijena' ) . '</strong></td><td><code>' . esc_html( Dates::format_date_display( $legacy_date ) ) . '</code></td><td>' . esc_html__( 'Food, drink, cosmetics, hygiene products, cleaning products and household goods. Be sure to map the slugs of these categories under Settings → Legal rules.', 'titanworks-bazna-cijena' ) . '</td></tr>';
		echo '<tr><td><strong>' . esc_html__( 'New products (first offer)', 'titanworks-bazna-cijena' ) . '</strong></td><td><em>' . esc_html__( 'Publication date', 'titanworks-bazna-cijena' ) . '</em></td><td>' . esc_html__( 'Products published for the first time while the plugin is active automatically record the first-offer price and that date as their anchor price.', 'titanworks-bazna-cijena' ) . '</td></tr>';
		echo '</tbody></table>';
		echo '<p><strong>' . esc_html__( 'Important legal note on the immutability of evidence:', 'titanworks-bazna-cijena' ) . '</strong> ' . esc_html__( 'Anchor price records and the price change history are legal evidence. Every change is recorded as a correction with a mandatory reason and a user trail (audit trail). Original values are never deleted silently.', 'titanworks-bazna-cijena' ) . '</p>';
		echo '</div>';

		// Section 2: Skupno postavljanje.
		echo '<div class="card sidrena-docs-card" id="skupno-postavljanje">';
		echo '<h2>' . esc_html__( '2. Bulk setting of anchor prices (bulk entry and tools)', 'titanworks-bazna-cijena' ) . '</h2>';
		echo '<p>' . esc_html__( 'So that you do not have to enter an anchor price for each product by hand, quick bulk tools are available on the Sidrena cijena → Anchor prices page:', 'titanworks-bazna-cijena' ) . '</p>';
		echo '<ul class="sidrena-docs-list">';
		echo '<li><strong>' . esc_html__( 'Set for all products at once:', 'titanworks-bazna-cijena' ) . '</strong> ' . esc_html__( 'At the top of the page there is a card that lets you set the anchor price from the current catalog price for all products and variations with one click. You can apply it only to products with a missing anchor price or to the whole range.', 'titanworks-bazna-cijena' ) . '</li>';
		echo '<li><strong>' . esc_html__( 'Quick selection on the page:', 'titanworks-bazna-cijena' ) . '</strong> ' . esc_html__( 'Using the “Select all on this page” and “Deselect all” buttons, or the checkbox in the table header, you can select all displayed products in a second and save the suggested values.', 'titanworks-bazna-cijena' ) . '</li>';
		echo '<li><strong>' . esc_html__( 'Import via CSV file:', 'titanworks-bazna-cijena' ) . '</strong> ' . esc_html__( 'On the Import page you can upload a CSV file with the columns sku/product_id, reference_date, anchor_price and variation_id. A dry run is available to check safely before writing permanently.', 'titanworks-bazna-cijena' ) . '</li>';
		echo '</ul>';
		echo '<p><a class="button button-primary" href="' . esc_url( AdminMenu::url( BulkAnchorEntryPage::SLUG ) ) . '">' . esc_html__( 'Open anchor price entry', 'titanworks-bazna-cijena' ) . '</a></p>';
		echo '</div>';

		// Section 3: Prikaz na trgovini.
		echo '<div class="card sidrena-docs-card" id="prikaz-trgovina">';
		echo '<h2>' . esc_html__( '3. Display of the anchor price and the lowest 30-day price in the shop', 'titanworks-bazna-cijena' ) . '</h2>';
		echo '<p>' . esc_html__( 'The plugin automatically displays the prescribed legal prices next to the regular product price on single product pages and in shop catalogs:', 'titanworks-bazna-cijena' ) . '</p>';
		echo '<ul class="sidrena-docs-list">';
		echo '<li><strong>' . esc_html__( 'Anchor price:', 'titanworks-bazna-cijena' ) . '</strong> ' . esc_html__( 'Shown as the text “Cijena na dan DD.MM.GGGG: X,XX €” (e.g. 10.09.2026 or 02.05.2025, depending on the category). You can set where it appears under Settings → Display (below the price, on the same line or in a separate block).', 'titanworks-bazna-cijena' ) . '</li>';
		echo '<li><strong>' . esc_html__( 'Styles and interactive tooltip:', 'titanworks-bazna-cijena' ) . '</strong> ' . esc_html__( 'Predefined styles are available: interactive tooltip with an (?) icon, minimalist, badge, card, border, soft background, monochrome, pill, tag, accent bar and subtle. In the settings you can also choose how the date is shown (tooltip, inline, subtext or hidden) and the font weight.', 'titanworks-bazna-cijena' ) . '</li>';
		echo '<li><strong>' . esc_html__( 'Lowest price in the last 30 days:', 'titanworks-bazna-cijena' ) . '</strong> ' . esc_html__( 'Shown automatically when a product is on sale or discounted (a special form of sale). The window is calculated from exactly 30 days before the start of the sale up to the day before the start (the start day is legally excluded).', 'titanworks-bazna-cijena' ) . '</li>';
		echo '<li><strong>' . esc_html__( 'Theme and page builder compatibility:', 'titanworks-bazna-cijena' ) . '</strong> ' . esc_html__( 'Classic themes, modern block themes (Full Site Editing - FSE) and popular page builders (Elementor, Divi, Beaver Builder) are supported.', 'titanworks-bazna-cijena' ) . '</li>';
		echo '</ul>';
		echo '</div>';

		// Section 4: Dnevni cjenik.
		echo '<div class="card sidrena-docs-card" id="dnevni-cjenik">';
		echo '<h2>' . esc_html__( '4. Daily price list, file name format and public feeds', 'titanworks-bazna-cijena' ) . '</h2>';
		echo '<p>' . esc_html__( 'The regulation requires a price list to be generated every day for each point of sale in the prescribed format:', 'titanworks-bazna-cijena' ) . '</p>';
		echo '<div class="sidrena-docs-callout">';
		echo '<strong>' . esc_html__( 'File name structure:', 'titanworks-bazna-cijena' ) . '</strong><br />';
		echo '<code>{OBLIK_OBJEKTA}_{ADRESA}_{OZNAKA_OBJEKTA}_{REDNI_BROJ}_{DDMMGGGG}_{HHMM}.{csv|xml}</code><br />';
		echo '<small>' . esc_html__( 'Example: PRODAVAONICA_ILICA-1_POSL-01_1_26092026_0800.csv', 'titanworks-bazna-cijena' ) . '</small>';
		echo '</div>';
		echo '<p><strong>' . esc_html__( 'Public URLs available to customers and inspectors:', 'titanworks-bazna-cijena' ) . '</strong></p>';
		echo '<ul class="sidrena-docs-list">';
		echo '<li><code>' . esc_html( home_url( '/sidrena-cijena.csv' ) ) . '</code> — ' . esc_html__( 'Public CSV feed of the current price list.', 'titanworks-bazna-cijena' ) . '</li>';
		echo '<li><code>' . esc_html( home_url( '/sidrena-cijena.xml' ) ) . '</code> — ' . esc_html__( 'Public XML feed of the current price list.', 'titanworks-bazna-cijena' ) . '</li>';
		echo '<li><code>' . esc_html( home_url( '/sidrena-cjenik/' ) ) . '</code> — ' . esc_html__( 'Overview HTML page with the item price list.', 'titanworks-bazna-cijena' ) . '</li>';
		echo '<li><code>' . esc_html( home_url( '/arhiva-sidrene-cijene/' ) ) . '</code> — ' . esc_html__( 'Public archive of all generated price lists (kept for at least 30 days).', 'titanworks-bazna-cijena' ) . '</li>';
		echo '</ul>';
		echo '</div>';

		// Section 5: Cron i automatizacija.
		echo '<div class="card sidrena-docs-card" id="cron-automatizacija">';
		echo '<h2>' . esc_html__( '5. Cron jobs, the 08:00 deadline and automatic catch-up', 'titanworks-bazna-cijena' ) . '</h2>';
		echo '<p>' . esc_html__( 'Price lists must be published before 08:00 every day:', 'titanworks-bazna-cijena' ) . '</p>';
		echo '<ul class="sidrena-docs-list">';
		echo '<li><strong>' . esc_html__( 'Daily cron job:', 'titanworks-bazna-cijena' ) . '</strong> ' . esc_html__( 'The twbce_cijena_daily_event hook is scheduled in the Europe/Zagreb time zone so that it generates and publishes the price list before 08:00 in the morning.', 'titanworks-bazna-cijena' ) . '</li>';
		echo '<li><strong>' . esc_html__( 'Automatic catch-up:', 'titanworks-bazna-cijena' ) . '</strong> ' . esc_html__( 'If WordPress cron does not run on time (e.g. because the site had no visits), the plugin detects the missed deadline, automatically starts an urgent catch-up generation and shows a visible warning in the admin.', 'titanworks-bazna-cijena' ) . '</li>';
		echo '<li><strong>' . esc_html__( 'Immediate regeneration for services:', 'titanworks-bazna-cijena' ) . '</strong> ' . esc_html__( 'When the price of a service changes (_twbce_item_type=service), the price list must be updated without delay by law, so the plugin automatically starts asynchronous regeneration.', 'titanworks-bazna-cijena' ) . '</li>';
		echo '</ul>';
		echo '</div>';

		// Section 6: WP-CLI.
		echo '<div class="card sidrena-docs-card" id="wp-cli">';
		echo '<h2>' . esc_html__( '6. WP-CLI commands for administrators', 'titanworks-bazna-cijena' ) . '</h2>';
		echo '<p>' . esc_html__( 'For advanced server management and automation through the system crontab, the following commands are available:', 'titanworks-bazna-cijena' ) . '</p>';
		echo '<table class="widefat striped sidrena-docs-table">';
		echo '<caption class="screen-reader-text">' . esc_html__( 'WP-CLI commands', 'titanworks-bazna-cijena' ) . '</caption>';
		echo '<thead><tr><th scope="col">' . esc_html__( 'Command', 'titanworks-bazna-cijena' ) . '</th><th scope="col">' . esc_html__( 'What it does', 'titanworks-bazna-cijena' ) . '</th></tr></thead>';
		echo '<tbody>';
		echo '<tr><td><code>wp sidrena-cijena generate [--force]</code></td><td>' . esc_html__( 'Generates and publishes a new daily price list for all active points of sale.', 'titanworks-bazna-cijena' ) . '</td></tr>';
		echo '<tr><td><code>wp sidrena-cijena check [--export=&lt;putanja&gt;]</code></td><td>' . esc_html__( 'Runs the compliance check and prints the ERRORS and WARNINGS found.', 'titanworks-bazna-cijena' ) . '</td></tr>';
		echo '<tr><td><code>wp sidrena-cijena status</code></td><td>' . esc_html__( 'Prints the plugin status: number of items, anchor prices, locations and the last publication.', 'titanworks-bazna-cijena' ) . '</td></tr>';
		echo '<tr><td><code>wp sidrena-cijena anchors set &lt;id&gt; &lt;cijena&gt;</code></td><td>' . esc_html__( 'Sets the anchor price for a given product with the optional --date and --reason parameters.', 'titanworks-bazna-cijena' ) . '</td></tr>';
		echo '<tr><td><code>wp sidrena-cijena seed-test-data --scenario=sale</code></td><td>' . esc_html__( 'Creates test price history data for checking the lowest 30-day price calculation.', 'titanworks-bazna-cijena' ) . '</td></tr>';
		echo '</tbody></table>';
		echo '</div>';

		// Section 7: Hooks.
		echo '<div class="card sidrena-docs-card" id="razvojne-kuke">';
		echo '<h2>' . esc_html__( '7. Developer hooks (Filters & Actions)', 'titanworks-bazna-cijena' ) . '</h2>';
		echo '<p>' . esc_html__( 'Developers can customize the plugin\'s behavior through standard WordPress filters and actions:', 'titanworks-bazna-cijena' ) . '</p>';
		echo '<table class="widefat striped sidrena-docs-table">';
		echo '<caption class="screen-reader-text">' . esc_html__( 'Developer hooks', 'titanworks-bazna-cijena' ) . '</caption>';
		echo '<thead><tr><th scope="col">' . esc_html__( 'Hook', 'titanworks-bazna-cijena' ) . '</th><th scope="col">' . esc_html__( 'Type', 'titanworks-bazna-cijena' ) . '</th><th scope="col">' . esc_html__( 'What it does', 'titanworks-bazna-cijena' ) . '</th></tr></thead>';
		echo '<tbody>';
		echo '<tr><td><code>twbce_cijena_display_anchor</code></td><td>' . esc_html__( 'Filter hook', 'titanworks-bazna-cijena' ) . '</td><td>' . esc_html__( 'Allows programmatic control over whether the anchor price is shown on a given product or page.', 'titanworks-bazna-cijena' ) . '</td></tr>';
		echo '<tr><td><code>twbce_cijena_thirty_day_label</code></td><td>' . esc_html__( 'Filter hook', 'titanworks-bazna-cijena' ) . '</td><td>' . esc_html__( 'Adjusts the text of the lowest 30-day price label per item and display context.', 'titanworks-bazna-cijena' ) . '</td></tr>';
		echo '<tr><td><code>twbce_cijena_footer_link_text</code></td><td>' . esc_html__( 'Filter hook', 'titanworks-bazna-cijena' ) . '</td><td>' . esc_html__( 'Adjusts the text of the price list archive link in the page footer.', 'titanworks-bazna-cijena' ) . '</td></tr>';
		echo '<tr><td><code>twbce_cijena_anchor_recorded</code></td><td>' . esc_html__( 'Action hook', 'titanworks-bazna-cijena' ) . '</td><td>' . esc_html__( 'Fires after a new anchor price has been recorded successfully.', 'titanworks-bazna-cijena' ) . '</td></tr>';
		echo '<tr><td><code>twbce_cijena_publication_published</code></td><td>' . esc_html__( 'Action hook', 'titanworks-bazna-cijena' ) . '</td><td>' . esc_html__( 'Fires after a new price list has been generated and published on the server.', 'titanworks-bazna-cijena' ) . '</td></tr>';
		echo '<tr><td><code>twbce_cijena_special_sale_changed</code></td><td>' . esc_html__( 'Action hook', 'titanworks-bazna-cijena' ) . '</td><td>' . esc_html__( 'Fires when a special form of sale is changed or recalculated.', 'titanworks-bazna-cijena' ) . '</td></tr>';
		echo '<tr><td><code>twbce_cijena_enable_standalone_catalog</code></td><td>' . esc_html__( 'Filter hook', 'titanworks-bazna-cijena' ) . '</td><td>' . esc_html__( 'Allows registering the standalone catalog (CPT) even if WooCommerce is active.', 'titanworks-bazna-cijena' ) . '</td></tr>';
		echo '</tbody></table>';
		echo '</div>';

		echo '</div>';
	}
}
